# STATE — NIDO (fuente de verdad)

## Identidad
- Proyecto: **NIDO**
- Propósito: PWA iPhone “modo app nativa” para reducir carga mental y dar claridad diaria.
- Usuarios:
  - **Carlos** = Admin (configura, ve todo, gestiona sensibles: Bancos, Preferencias, Notificaciones).
  - **Davinia** = User (uso diario, no edita estructura; por la noche usa oscuro).

## URLs
- Producción: https://familia-app-5cm.vercel.app/
- Rutas clave:
  - `/` Inicio
  - `/today` Hoy
  - `/calendar` Semana
  - `/commands` Añadir
  - `/familia` Familia
  - `/comida` Comida
  - `/medicacion` Medicación
  - `/docs` Docs
  - `/finance` Finanzas
  - `/electricidad` Electricidad
  - `/settings` Cuenta / Preferencias
  - `/lab` Laboratorio (5 estilos Home)

## Stack (cerrado)
- Front: Next.js App Router (`/app`) + TypeScript + Tailwind
- Deploy: Vercel
- Backend: Supabase (Auth + DB + Storage)
- Auth:
  - Solo email+password
  - Solo por invitación
  - Signups desactivados
  - Recovery existe en `/auth/reset` (debe funcionar)
- Mobile-first: iPhone + PWA es prioridad absoluta

## Navegación (cerrado)
- Bottom nav móvil (5 iconos): Inicio / Hoy / Añadir / Semana / Familia
- iOS topbar en móvil: título + flecha back estilo iPhone cuando procede

## Estado actual (últimos hitos)
- Identidad:
  - Universo aves/pollitos + dodo 🦤
  - Aves con SVG locales en `public/birds/` para splash y vacíos (offline-friendly)
- B02.1 Microcopy:
  - Añadir: copy calmado + confirmación visible al guardar
  - Docs: vacíos + placeholders + “Manuales / Instrucciones” (antes Garantías)
  - Finanzas: feedback más claro al importar CSV (incluye caso “0 filas”)

- Comida (V1):
  - Plantillas rápidas (píldoras)
  - Copiar día → día (hoy→mañana por defecto)
  - Comedor Monzón 3: tarjeta con “Ver menú (PDF)” + watcher que detecta el PDF desde la web

- Auth (PWA):
  - Sesión persistente en refresh/restart (Supabase auth flags)
  - `Protected` espera `INITIAL_SESSION` para evitar redirecciones fantasma
  - Login recuerda último email + soporta `return_to`

## Datos / almacenamiento (V1)
- Si Supabase NO está configurado: localStorage (modo demo)
- Si Supabase está configurado: Auth y tablas (según schema actual)

## Variables de entorno (Vercel)
- Supabase:
  - `NEXT_PUBLIC_SUPABASE_URL`
  - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- Admin:
  - `NEXT_PUBLIC_ADMIN_EMAIL` (email de Carlos para visibilidad de “Bancos” cuando lo implementemos en B04)

- Comedor Monzón 3 (opcional):
  - `MONZON_COMEDOR_URL` (si cambia la URL fuente del cole)

## Problemas conocidos
- Cache iPhone PWA: a veces tarda en reflejar deploy (si no se ven cambios: borrar PWA y reinstalar desde Safari).
- `.obsidian` no debe versionarse (ignorar).
- Finanzas: soporte de CSV depende de columnas del banco (ahora avisa mejor).

## Próximo foco (prioridad)
1) Rutinas 2.0 (remates si quedara algo)
2) “Más” hub (B03)
3) Docs V1 (tiles por persona + Bancos solo admin) (B04)
4) Inspiración seed (B05)
5) Finanzas drag&drop + progreso (B06)
6) Notificaciones + sync serio (B07)
