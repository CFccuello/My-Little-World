-- FamiliaCM schema (Supabase)
-- Execute in Supabase SQL Editor.

create extension if not exists "uuid-ossp";

-- SETTINGS
create table if not exists public.settings (
  id uuid primary key references auth.users(id) on delete cascade,
  tz text not null default 'Europe/Madrid',
  work_min_hours numeric not null default 8,
  dogs_minutes int not null default 60,
  gym_minutes int not null default 60,
  meal_minutes int not null default 30,
  family_start_evening text not null default '17:30',
  dogs_start text not null default '06:00',
  sleep_start text not null default '22:00',
  sleep_end text not null default '05:00',
  updated_at timestamptz not null default now()
);

alter table public.settings enable row level security;

create policy "settings_select_own"
on public.settings for select
using (auth.uid() = id);

create policy "settings_upsert_own"
on public.settings for insert
with check (auth.uid() = id);

create policy "settings_update_own"
on public.settings for update
using (auth.uid() = id);

-- ROUTINE LOGS
create table if not exists public.routine_logs (
  user_id uuid not null references auth.users(id) on delete cascade,
  log_date date not null,
  routine_type text not null check (routine_type in ('morning','night')),
  item_key text not null,
  done boolean not null default false,
  updated_at timestamptz not null default now(),
  primary key (user_id, log_date, routine_type, item_key)
);

alter table public.routine_logs enable row level security;

create policy "routine_select_own"
on public.routine_logs for select
using (auth.uid() = user_id);

create policy "routine_upsert_own"
on public.routine_logs for insert
with check (auth.uid() = user_id);

create policy "routine_update_own"
on public.routine_logs for update
using (auth.uid() = user_id);

-- MED LOGS
create table if not exists public.med_logs (
  user_id uuid not null references auth.users(id) on delete cascade,
  log_date date not null,
  med_key text not null check (med_key in ('loniten','dutasteride')),
  done boolean not null default false,
  updated_at timestamptz not null default now(),
  primary key (user_id, log_date, med_key)
);

alter table public.med_logs enable row level security;

create policy "med_select_own"
on public.med_logs for select
using (auth.uid() = user_id);

create policy "med_upsert_own"
on public.med_logs for insert
with check (auth.uid() = user_id);

create policy "med_update_own"
on public.med_logs for update
using (auth.uid() = user_id);

-- TASKS
create table if not exists public.tasks (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  window_start date not null,
  window_end date not null,
  duration_min int not null default 30,
  priority text not null check (priority in ('Alta','Media','Baja')) default 'Media',
  energy text not null check (energy in ('Baja','Media','Alta')) default 'Media',
  done boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.tasks enable row level security;

create policy "tasks_select_own"
on public.tasks for select
using (auth.uid() = user_id);

create policy "tasks_insert_own"
on public.tasks for insert
with check (auth.uid() = user_id);

create policy "tasks_update_own"
on public.tasks for update
using (auth.uid() = user_id);

create policy "tasks_delete_own"
on public.tasks for delete
using (auth.uid() = user_id);

-- DOCS (metadata + OneDrive link)
create table if not exists public.docs (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references auth.users(id) on delete cascade,
  doc_date date not null,
  category text not null check (category in ('Bancos','Médicos','Facturas','Colegio','Seguros','Otros')),
  entity text not null,
  concept text not null,
  amount numeric null,
  onedrive_url text not null,
  status text not null check (status in ('INBOX','Pendiente','Archivado')) default 'INBOX',
  created_at timestamptz not null default now()
);

alter table public.docs enable row level security;

create policy "docs_select_own"
on public.docs for select
using (auth.uid() = user_id);

create policy "docs_insert_own"
on public.docs for insert
with check (auth.uid() = user_id);

create policy "docs_update_own"
on public.docs for update
using (auth.uid() = user_id);

create policy "docs_delete_own"
on public.docs for delete
using (auth.uid() = user_id);

-- TRANSACTIONS (simple MVP)
create table if not exists public.transactions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references auth.users(id) on delete cascade,
  tx_date date not null,
  description text not null,
  amount numeric not null,
  created_at timestamptz not null default now()
);

create unique index if not exists transactions_dedupe
on public.transactions(user_id, tx_date, description, amount);

alter table public.transactions enable row level security;

create policy "tx_select_own"
on public.transactions for select
using (auth.uid() = user_id);

create policy "tx_insert_own"
on public.transactions for insert
with check (auth.uid() = user_id);

create policy "tx_update_own"
on public.transactions for update
using (auth.uid() = user_id);

create policy "tx_delete_own"
on public.transactions for delete
using (auth.uid() = user_id);

-- CALENDAR EVENTS (Familia)
create table if not exists public.calendar_events (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  start_ts timestamptz not null,
  end_ts timestamptz not null,
  created_at timestamptz not null default now()
);

alter table public.calendar_events enable row level security;

create policy "events_select_own"
on public.calendar_events for select
using (auth.uid() = user_id);

create policy "events_insert_own"
on public.calendar_events for insert
with check (auth.uid() = user_id);

create policy "events_update_own"
on public.calendar_events for update
using (auth.uid() = user_id);

create policy "events_delete_own"
on public.calendar_events for delete
using (auth.uid() = user_id);

-- CHECKLIST ITEMS (per day)
create table if not exists public.checklist_items (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references auth.users(id) on delete cascade,
  item_date date not null,
  list_key text not null check (list_key in ('work','carlos','home_family')),
  text text not null,
  done boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists checklist_items_lookup
on public.checklist_items(user_id, item_date, list_key);

alter table public.checklist_items enable row level security;

create policy "checklist_select_own"
on public.checklist_items for select
using (auth.uid() = user_id);

create policy "checklist_insert_own"
on public.checklist_items for insert
with check (auth.uid() = user_id);

create policy "checklist_update_own"
on public.checklist_items for update
using (auth.uid() = user_id);

create policy "checklist_delete_own"
on public.checklist_items for delete
using (auth.uid() = user_id);
