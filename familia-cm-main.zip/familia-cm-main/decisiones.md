# DECISIONES — NIDO

> Decisiones cerradas. Si algo cambia, se añade una nueva decisión (no se reescribe la historia).

## D01 — iPhone PWA primero
- Estado: CERRADA
- Decisión: priorizamos iPhone + PWA por encima de desktop.

## D02 — Roles simples
- Estado: CERRADA
- Decisión: solo 2 roles: Admin (Carlos) y User (Davinia).

## D03 — Auth por invitación
- Estado: CERRADA
- Decisión: email+password, signups desactivados, reset funcional.

## D04 — Home se entiende en 5 segundos
- Estado: CERRADA
- Decisión: Home = claim + tarjeta Hoy dominante + Temas por tarjetas.
- Anti-objetivo: no Notion / no tabla cargada.

## D05 — Bottom nav fijo 5 iconos
- Estado: CERRADA
- Decisión: Inicio / Hoy / Añadir / Semana / Familia.

## D06 — “Hoy” es solo casa/familia
- Estado: CERRADA
- Decisión: Hoy NO muestra trabajo.

## D07 — Comida es prioritaria
- Estado: CERRADA
- Decisión: Comida va primero en Home.

## D08 — Pull-to-refresh global
- Estado: CERRADA
- Decisión: en iPhone todas las pantallas permiten “tirar para refrescar”.

## D09 — iOS back explícito
- Estado: CERRADA
- Decisión: en móvil hay flecha back estilo iPhone.

## D10 — “Preferencias” y “Guardar” por seguridad psicológica
- Estado: CERRADA

## D11 — Universo “aves/pollitos”
- Estado: CERRADA
- Decisión: microcopy y vacíos con aves; el dodo 🦤 como humor amable.

## D12 — Secundarios van a “Más”
- Estado: ABIERTA (a implementar)
- Decisión propuesta: crear “Más” hub para módulos no diarios (Docs, Finanzas, Inspiración, Lavavajillas, Jugar, Pareja).

## D13 — Ilustraciones locales (SVG)
- Estado: CERRADA
- Decisión: las ilustraciones del universo NIDO se sirven localmente desde `public/birds/*.svg` (PWA/offline-friendly).
- Implicación: si falta SVG, se usa emoji como fallback.

## D14 — Auth PWA: sesión persistente y sin “ghost redirects”
- Estado: CERRADA
- Decisión: activamos persistencia de sesión en Supabase y hacemos que `Protected` espere `INITIAL_SESSION`.
- Motivo: evitar redirecciones fantasma en refresh / reinicio de la PWA.

## D15 — Comedor: lectura de PDF vía API interna (anti-CORS)
- Estado: CERRADA
- Decisión: detectar enlaces a PDF del comedor desde una ruta `/api/...` en el servidor.
- Motivo: en iOS/PWA CORS y cache son impredecibles; el servidor puede leer HTML y devolver enlaces limpios.

## D16 — Pantallas Auth sin chrome
- Estado: CERRADA
- Decisión: `/login` y `/auth/*` no muestran topbar/nav inferior.
- Motivo: reducir ruido y evitar “entrar y ver botones que no funcionan todavía”.
