# BACKLOG — NIDO

> Ordenado por impacto en Davinia + riesgo técnico. Cada item debe tener definición de hecho.

## NOW — V1.2 (subir a 10/10 en iPhone)

### B01 — Rutinas 2.0 (V1 local)
- Secciones: Lun–Vie / Sáb–Dom / Semanales.
- Semanales con contador (días restantes hasta domingo).
- Hecho por + asignación simple (multi-select → Asignar a Carlos/Davinia).
- Diferenciación visual: chip C/D + ave 🦅/🕊️ + acento suave.

**DoD**
- Se puede asignar y marcar sin scroll raro.
- “Hecho por quién” se ve y se entiende.

### B02 — Microcopy 100% aves
- Vacíos, tooltips, ayudas y menús con tono ave/pollito.
- Humor del dodo 🦤 recurrente y ligero (1 guiño por pantalla como máximo).

**B02.1 (HECHO)** — Barrido “pantallas clave”
- Añadir: copy calmado + confirmación visible al guardar.
- Docs: vacíos + placeholders + renombre “Garantías” → “Manuales / Instrucciones” (migración suave).
- Finanzas: feedback más humano al importar CSV + vacíos + mensajes claros.

### B03 — “Más” hub
- Nuevo tab o acceso dentro de la navegación (sin romper 5 iconos).
- Grid bonito: Jugar, Pareja, Inspiración, Docs, Finanzas, Lavavajillas, etc.

### B04 — Docs V1 (tiles por persona)
- Carpetas por integrante:
  - Greta / Máximo / Roma / Davinia / Carlos / Tere
- Carpeta “Familia” (solo admin): Bancos
- “Garantías” → “Manuales / Instrucciones”
- Visual: tiles grandes (no tabla).

### B05 — Inspiración V1 (seed visible)
- Mostrar ejemplos de perfiles/posts.
- Añadir por pegar enlace + nota.
- UI para activar/desactivar campos.

### B06 — Finanzas V1 (UX)
- Fix: seleccionar CSV debe mostrar feedback y vista (mejorado en B02.1).
- Dropzone drag&drop + progreso/estado.

## NEXT — V1.3 (bloque técnico serio)

### B07 — Notificaciones + sincronizado (tipo Calendar)
- Avisos: 1 día antes / 15 min antes.
- Solo pedir permisos después de acción del usuario.
- Sync multiusuario.
- Requiere: SW + Web Push + backend/cron (hacer bien).

## LATER — V2

### B08 — Jugar
- 150 juegos ilustrados.
- Filtro por quién juega (edad) + ficha de juego.
- Añadir juego (foto + descripción corta).

### B09 — Pareja
- Check-in semanal
- Ideas de cita
- Detalle del día
- Lista deseos

## Tech debt (siempre)
- TD01: ignorar `.obsidian`
- TD02: cache PWA (estrategia de invalidación)
- TD03: normalizar line endings (opcional: .gitattributes)

## INBOX — Implementaciones capturadas (sin prioridad aún)

### I01 — Comida: PDF calendario mensual comedor
- Fuente comedor:
  - Colegio Monzon 3 = Greta y Máximo
  - Guarderia La Alegria = Roma

**I01.1 (HECHO V1)** — Monzón 3: detectar PDF + botón “Ver el menú”
- API: `GET /api/comedor/monzon` (evita CORS)
- Tarjeta en `/comida` con:
  - Ver el menú (PDF)
  - Comprobar ahora
- Watcher en background (open / visibility / pull-to-refresh)

**I01.2 (PENDIENTE)** — Roma: PDF 4 semanas rotacional
- Selector “semana actual 1–4” + rotación automática
- Override manual + “recalcular”

**I01.3 (PENDIENTE)** — Integración diaria
- Aplicar automáticamente el comedor en los slots (entre Almuerzo y Merienda)

### I02 — Medicación: V1 seguridad + registro
- Niños base:
  - Greta 20/06/2019
  - Máximo 13/09/2021
  - Roma 15/12/2023
- Reglas:
  - No estimar peso automáticamente.
  - Cálculo solo con reglas definidas (seguridad).
  - Registro: dosis + hora + hechoPor.

### I03 (HECHO) — Auth: recordar sesión PWA
- Mantener sesión en refresh / PWA restart (persistSession + autoRefreshToken).
- `Protected` espera `INITIAL_SESSION` para evitar “ghost redirects”.
- Login:
  - recuerda último email
  - respeta `return_to` tras entrar

### I04 (HECHO V1) — Electricidad: lecturas kWh
- Nueva pantalla `/electricidad` (localStorage V1).
- Acceso desde `/familia` + navegación desktop + título iOS.
