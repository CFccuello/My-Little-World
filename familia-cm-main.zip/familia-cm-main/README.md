# FamiliaCM — MVP (PWA + Supabase + OneDrive)

Este MVP te permite:
- Agenda **por colores** (sin solapes) + totales por labor.
- Rutinas mañana/noche (checklist).
- Medicación (Loniten diario + Dutasteride alterno).
- Documentación: metadatos + **link OneDrive** (archivos fuera de Supabase).
- Finanzas (MVP): importar CSV del banco, preview y totales; guardar en Supabase opcional.

---

## 0) Requisitos
- Windows 11
- Node.js instalado
- Cuenta Supabase (Free)
- (Opcional) Vercel para desplegar y abrir en iPhone como PWA

---

## 1) OneDrive (archivos)
En tu OneDrive (cuenta Outlook "de casa") crea:

FamiliaCM/
- 00_INBOX
- 01_Bancos
- 02_Médicos
- 03_Facturas
- 04_Colegio
- 05_Seguros
- 99_Archivado

Comparte la carpeta **FamiliaCM** con Davinia con permiso **Editar** y enlace restringido a **Personas específicas**.

---

## 2) Supabase (base de datos)
1) Crea un proyecto (plan Free).
2) En el proyecto: **SQL Editor** → ejecuta `supabase/schema.sql`.
3) **Auth**
   - Authentication → Providers → Email: habilita Email (password).
   - Recomendación: crea 2 cuentas (tú + Davinia) y luego desactiva el registro abierto:
     Authentication → Settings → (desactivar) Allow new users to sign up.

4) Copia las claves:
   - Project Settings → API → `Project URL`
   - Project Settings → API → `anon public key`

---

## 3) Configurar la app (local)
1) En la carpeta del proyecto, crea `.env.local`:

NEXT_PUBLIC_SUPABASE_URL=TU_PROJECT_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY=TU_ANON_PUBLIC_KEY

2) Instala dependencias y arranca:

npm install
npm run dev

3) Abre:
http://localhost:3000

Login:
- Primero crea cuenta (Sign up) con tu email y contraseña
- Entra (Login)

---

## 4) Desplegar en Vercel (para iPhone / PWA)
1) Sube este proyecto a GitHub (repo privado).
2) En Vercel: New Project → Import repo.
3) En Vercel añade env vars:
   - NEXT_PUBLIC_SUPABASE_URL
   - NEXT_PUBLIC_SUPABASE_ANON_KEY
4) Deploy → tendrás una URL `https://xxxx.vercel.app`

5) En Supabase:
Authentication → URL Configuration:
- Site URL: `https://xxxx.vercel.app`
- Additional Redirect URLs: añade esa misma URL (y `http://localhost:3000` si sigues usando local)

6) En iPhone:
Safari → abrir URL → Compartir → “Añadir a pantalla de inicio”.

---

## 5) Qué ajusta tus reglas (Carlos)
En /Ajustes puedes cambiar:
- Trabajo mínimo (horas)
- Perros (min)
- Gym (min)
- Comida (min)
- Hora de subida con familia (ej. 17:30)
- Horarios sueño (inicio/fin)
- Hora inicio perros

Nota: la agenda de /Hoy es plantilla. La siguiente iteración usa los ajustes guardados para recalcular automáticamente.

---

## 6) Seguridad práctica (mínimo)
- En Supabase: una vez tengáis las 2 cuentas creadas, desactiva “Allow new users to sign up”.
- Usa 2FA en la cuenta Outlook “de casa” y en Supabase.
