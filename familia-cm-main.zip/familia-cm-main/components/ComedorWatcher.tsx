"use client";

import { useEffect } from "react";
import { checkComedorMonzon, loadComedorMonzonState } from "@/lib/comedorMonzon3";
import { onNidoRefresh } from "@/lib/refreshBus";

const MIN_CHECK_MS = 12 * 60 * 60 * 1000; // 12h

function shouldCheck(lastCheckISO?: string) {
  if (!lastCheckISO) return true;
  const t = Date.parse(lastCheckISO);
  if (Number.isNaN(t)) return true;
  return Date.now() - t > MIN_CHECK_MS;
}

export default function ComedorWatcher({ enabled = true }: { enabled?: boolean }) {
  useEffect(() => {
    if (!enabled) return;

    const maybeCheck = async () => {
      const st = loadComedorMonzonState();
      if (!shouldCheck(st.lastCheckISO)) return;
      try {
        await checkComedorMonzon();
      } catch {
        // ignore
      }
    };

    // First load
    void maybeCheck();

    // Pull-to-refresh
    const off = onNidoRefresh(() => {
      void checkComedorMonzon();
    });

    // When coming back to the app
    const onVis = () => {
      if (document.visibilityState === "visible") void maybeCheck();
    };
    document.addEventListener("visibilitychange", onVis);

    return () => {
      off();
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [enabled]);

  return null;
}
