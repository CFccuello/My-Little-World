"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import type { CalendarEvent } from "@/lib/types";
import { getEventsLocal } from "@/lib/eventsStore";
import { format, startOfWeek, endOfWeek, addWeeks, parseISO, isWithinInterval } from "date-fns";

function filterWeek(events: CalendarEvent[], cursor: Date): CalendarEvent[] {
  const start = startOfWeek(cursor, { weekStartsOn: 1 });
  const end = endOfWeek(cursor, { weekStartsOn: 1 });
  return events
    .filter((e) => {
      const s = parseISO(e.startISO);
      return isWithinInterval(s, { start, end });
    })
    .sort((a, b) => parseISO(a.startISO).getTime() - parseISO(b.startISO).getTime());
}

export default function WeekEventsWidget() {
  const [cursor, setCursor] = useState<Date>(new Date());
  const [events, setEvents] = useState<CalendarEvent[]>(() => getEventsLocal());

  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === "familiaCM:events") {
        setEvents(getEventsLocal());
      }
    };
    window.addEventListener("storage", onStorage);
    // also refresh when returning to the tab
    const onFocus = () => setEvents(getEventsLocal());
    window.addEventListener("focus", onFocus);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("focus", onFocus);
    };
  }, []);

  const start = useMemo(() => startOfWeek(cursor, { weekStartsOn: 1 }), [cursor]);
  const end = useMemo(() => endOfWeek(cursor, { weekStartsOn: 1 }), [cursor]);
  const weekEvents = useMemo(() => filterWeek(events, cursor), [events, cursor]);

  return (
    <div className="card p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="font-semibold">Semana (eventos)</div>
        <div className="flex items-center gap-2">
          <button className="notion-btn" onClick={() => setCursor(new Date())}>Esta semana</button>
          <button className="notion-btn" onClick={() => setCursor(addWeeks(cursor, 1))}>Semana que viene</button>
          <Link className="notion-btn" href="/calendar">Mes</Link>
        </div>
      </div>
      <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">
        {format(start, "dd MMM")} – {format(end, "dd MMM")}
      </div>

      <div className="mt-3 space-y-2">
        {weekEvents.length ? (
          weekEvents.map((e) => (
            <div key={e.id} className="nido-card tone-familia p-3 text-sm">
              <div className="font-mono text-xs text-[hsl(var(--muted-foreground))]">
                {format(parseISO(e.startISO), "EEE dd · HH:mm")}–{format(parseISO(e.endISO), "HH:mm")}
              </div>
              <div className="font-medium text-[hsl(var(--foreground))]">{e.title}</div>
            </div>
          ))
        ) : (
          <div className="text-sm text-[hsl(var(--muted-foreground))]">Semana tranquila. Los pollitos no tienen citas.</div>
        )}
      </div>

      <div className="mt-3 text-xs text-[hsl(var(--muted-foreground))]">
        Tip: añade eventos en <Link className="underline" href="/calendar">Calendario</Link>.
      </div>
    </div>
  );
}
