import React from "react";
import type { LucideIcon } from "lucide-react";
import { NidoMark } from "./NidoMark";

type AppIconProps = {
  Icon: LucideIcon;
  active?: boolean;
  size?: number;
  className?: string;
};

export function AppIcon({ Icon, active = false, size = 24, className }: AppIconProps) {
  return (
    <span
      className={["relative inline-flex items-center justify-center", className].filter(Boolean).join(" ")}
      style={{ width: size, height: size }}
      aria-hidden="true"
    >
      <Icon size={size} strokeWidth={2} />
      {active ? (
        <span className="absolute -bottom-1 -right-1">
          <NidoMark size={10} />
        </span>
      ) : null}
    </span>
  );
}
