import React from "react";

export function NidoMark({ size = 10 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 12 12"
      fill="none"
      aria-hidden="true"
    >
      {/* “pájaro en vuelo” minimalista */}
      <path
        d="M1.2 7.2C2.6 5.8 4.2 5.8 5.6 7.2"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M5.6 7.2C7.0 5.8 8.6 5.8 10.0 7.2"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
