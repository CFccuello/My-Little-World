"use client";

import { useMemo, useState } from "react";
import type { CalendarEvent } from "@/lib/types";
import { format, addDays, startOfWeek, endOfWeek, startOfMonth, endOfMonth, startOfDay, endOfDay, isSameDay, isWithinInterval, parseISO, addMonths, subMonths, subWeeks, addWeeks } from "date-fns";
import { getEventsLocal, upsertEventLocal, deleteEventLocal } from "@/lib/eventsStore";

type ViewMode = "week" | "month";

function clampISO(d: Date): string {
  return d.toISOString();
}

function eventsInRange(events: CalendarEvent[], start: Date, end: Date): CalendarEvent[] {
  return events
    .filter((e) => {
      const s = parseISO(e.startISO);
      return isWithinInterval(s, { start, end });
    })
    .sort((a, b) => parseISO(a.startISO).getTime() - parseISO(b.startISO).getTime());
}

export default function CalendarView({ initialDate }: { initialDate?: Date }) {
  const [mode, setMode] = useState<ViewMode>("week");
  const [cursor, setCursor] = useState<Date>(initialDate ?? new Date());
  const [events, setEvents] = useState<CalendarEvent[]>(() => getEventsLocal());

  const range = useMemo(() => {
    if (mode === "week") {
      const start = startOfWeek(cursor, { weekStartsOn: 1 });
      const end = endOfWeek(cursor, { weekStartsOn: 1 });
      return { start, end };
    }
    const start = startOfWeek(startOfMonth(cursor), { weekStartsOn: 1 });
    const end = endOfWeek(endOfMonth(cursor), { weekStartsOn: 1 });
    return { start, end };
  }, [cursor, mode]);

  const visibleEvents = useMemo(() => eventsInRange(events, range.start, range.end), [events, range]);

  const [formOpen, setFormOpen] = useState(false);
  const [form, setForm] = useState({ title: "", date: format(new Date(), "yyyy-MM-dd"), start: "10:00", end: "10:30" });

  const goPrev = () => {
    setCursor((d) => (mode === "week" ? subWeeks(d, 1) : subMonths(d, 1)));
  };
  const goNext = () => {
    setCursor((d) => (mode === "week" ? addWeeks(d, 1) : addMonths(d, 1)));
  };

  const openAdd = (dateISO?: string) => {
    setForm({ title: "", date: dateISO ?? format(cursor, "yyyy-MM-dd"), start: "10:00", end: "10:30" });
    setFormOpen(true);
  };

  const save = () => {
    const title = form.title.trim();
    if (!title) return;
    // Local timezone: build Date from yyyy-MM-dd + HH:MM
    const start = new Date(`${form.date}T${form.start}:00`);
    const end = new Date(`${form.date}T${form.end}:00`);
    const ev = upsertEventLocal({ title, startISO: clampISO(start), endISO: clampISO(end) });
    setEvents(getEventsLocal());
    setFormOpen(false);
    return ev;
  };

  const deleteEv = (id: string) => {
    deleteEventLocal(id);
    setEvents(getEventsLocal());
  };

  const DayCell = ({ day }: { day: Date }) => {
    const dayStart = startOfDay(day);
    const dayEnd = endOfDay(day);
    const dayEvents = visibleEvents.filter((e) => {
      const s = parseISO(e.startISO);
      return isWithinInterval(s, { start: dayStart, end: dayEnd });
    });

    return (
      <div className="rounded-lg border border-slate-200 bg-white p-2 min-h-[120px]">
        <div className="flex items-center justify-between">
          <div className={`text-xs font-medium ${isSameDay(day, new Date()) ? "text-slate-900" : "text-slate-600"}`}>
            {format(day, "EEE dd")}
          </div>
          <button className="notion-icon-btn" title="Añadir evento" onClick={() => openAdd(format(day, "yyyy-MM-dd"))}>
            +
          </button>
        </div>
        <div className="mt-2 space-y-1">
          {dayEvents.length ? dayEvents.map((e) => (
            <div key={e.id} className="rounded-md border border-blue-200 bg-blue-50 px-2 py-1 text-xs">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="font-mono text-[10px] text-blue-900">
                    {format(parseISO(e.startISO), "HH:mm")}–{format(parseISO(e.endISO), "HH:mm")}
                  </div>
                  <div className="truncate font-medium text-blue-900">{e.title}</div>
                </div>
                <button className="text-blue-900/60 hover:text-blue-900" title="Eliminar" onClick={() => deleteEv(e.id)}>✕</button>
              </div>
            </div>
          )) : (
            <div className="text-xs text-slate-400">Sin eventos</div>
          )}
        </div>
      </div>
    );
  };

  const days = useMemo(() => {
    const out: Date[] = [];
    let d = range.start;
    while (d <= range.end) {
      out.push(d);
      d = addDays(d, 1);
    }
    return out;
  }, [range]);

  return (
    <div className="card p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button className="notion-btn" onClick={() => setCursor(new Date())}>Hoy</button>
          <button className="notion-btn" onClick={goPrev}>◀</button>
          <button className="notion-btn" onClick={goNext}>▶</button>
          <div className="text-sm text-slate-600">
            {mode === "week"
              ? `${format(range.start, "dd MMM")} – ${format(range.end, "dd MMM")}`
              : format(cursor, "MMMM yyyy")}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="date"
            className="notion-input"
            value={format(cursor, "yyyy-MM-dd")}
            onChange={(e) => setCursor(new Date(`${e.target.value}T12:00:00`))}
          />
          <button className={"notion-btn " + (mode === "week" ? "opacity-100" : "opacity-70")} onClick={() => setMode("week")}>Semana</button>
          <button className={"notion-btn " + (mode === "month" ? "opacity-100" : "opacity-70")} onClick={() => setMode("month")}>Mes</button>
          <button className="notion-btn" onClick={() => openAdd()}>+ Evento</button>
        </div>
      </div>

      <div className="mt-4">
        {mode === "week" ? (
          <div className="grid gap-2 md:grid-cols-7">
            {days.map((d) => <DayCell key={d.toISOString()} day={d} />)}
          </div>
        ) : (
          <div className="grid gap-2 grid-cols-2 sm:grid-cols-3 md:grid-cols-7">
            {days.map((d) => (
              <div key={d.toISOString()} className={"rounded-lg border bg-white p-2 min-h-[90px] " + (format(d, "MM") !== format(cursor, "MM") ? "opacity-60" : "")}
              >
                <div className="flex items-center justify-between">
                  <div className="text-xs font-medium text-slate-700">{format(d, "d")}</div>
                  <button className="notion-icon-btn" title="Añadir evento" onClick={() => openAdd(format(d, "yyyy-MM-dd"))}>+</button>
                </div>
                <div className="mt-1 space-y-1">
                  {visibleEvents
                    .filter((e) => isSameDay(parseISO(e.startISO), d))
                    .slice(0, 3)
                    .map((e) => (
                      <div key={e.id} className="truncate text-[11px] text-blue-900 bg-blue-50 border border-blue-200 rounded px-1 py-0.5">
                        {format(parseISO(e.startISO), "HH:mm")} {e.title}
                      </div>
                    ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {formOpen ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/30" onClick={() => setFormOpen(false)} />
          <div className="relative w-full max-w-md rounded-xl border border-slate-200 bg-white p-4 shadow-lg">
            <div className="font-semibold">Nuevo evento (Familia)</div>
            <div className="mt-3 space-y-2">
              <input className="notion-input w-full" placeholder="Título" value={form.title} onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))} />
              <div className="grid grid-cols-3 gap-2">
                <input type="date" className="notion-input" value={form.date} onChange={(e) => setForm((p) => ({ ...p, date: e.target.value }))} />
                <input type="time" className="notion-input" value={form.start} onChange={(e) => setForm((p) => ({ ...p, start: e.target.value }))} />
                <input type="time" className="notion-input" value={form.end} onChange={(e) => setForm((p) => ({ ...p, end: e.target.value }))} />
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button className="notion-btn" onClick={() => setFormOpen(false)}>Cancelar</button>
                <button className="notion-btn" onClick={save}>Guardar</button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
