"use client";

import { useEffect } from "react";
import { applyUiToHtml, loadUi } from "@/lib/uiSettings";

export default function UiBoot() {
  useEffect(() => {
    const ui = loadUi();
    applyUiToHtml(ui);
  }, []);
  return null;
}
