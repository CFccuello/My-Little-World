"use client";

import clsx from "clsx";
import { useMemo } from "react";
import { format } from "date-fns";
import { birdForDate } from "@/lib/birds";

type Props = {
  className?: string;
  size?: "sm" | "md" | "lg" | "xl";
  /** Lower opacity for subtle backgrounds */
  soft?: boolean;
};

function sizeClass(size: NonNullable<Props["size"]>) {
  switch (size) {
    case "sm":
      return "text-[1.4rem]";
    case "md":
      return "text-[2.2rem]";
    case "lg":
      return "text-[3.2rem]";
    case "xl":
      return "text-[4.2rem]";
  }
}

export default function BirdStamp({ className, size = "lg", soft = true }: Props) {
  const dateISO = useMemo(() => format(new Date(), "yyyy-MM-dd"), []);
  const bird = useMemo(() => birdForDate(dateISO), [dateISO]);

  return (
    <div
      aria-hidden="true"
      className={clsx(
        "nido-bird-stamp",
        sizeClass(size),
        soft ? "opacity-20" : "opacity-40",
        className,
      )}
    >
      {bird.emoji}
    </div>
  );
}
