"use client";

import { useEffect, useState } from "react";
import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";
import type { RoutineType } from "@/lib/types";
import { lsGet, lsSet } from "@/lib/localStore";

type Item = { key: string; label: string; minutes: number };

const morningItems: Item[] = [
  { key: "dishwasher_empty", label: "Recoger lavavajillas (vaciar)", minutes: 10 },
  { key: "dishwasher_load", label: "Meter lo sucio / dejarlo corriendo", minutes: 5 },
  { key: "kitchen_reset", label: "Recoger comedor + cocina (modo rápido)", minutes: 10 },
  { key: "beds", label: "Hacer camas", minutes: 3 },
  { key: "windows", label: "Abrir ventanas (ventilar)", minutes: 2 }
];

const nightItems: Item[] = [
  { key: "car_garage", label: "Meter coche (Pareja) al garaje", minutes: 5 },
  { key: "car_charge", label: "Poner coche a cargar", minutes: 2 },
  { key: "kitchen_clean", label: "Limpiar cocina (mínimo viable)", minutes: 8 },
  { key: "bibs_bottles", label: "Fregar baberos/botellitas", minutes: 10 },
  { key: "prep_tomorrow", label: "Preparar mañana (sin ropa complicada)", minutes: 10 },
  { key: "ask_davinia", label: "Preguntar por el día a tu pareja (sin móvil)", minutes: 5 }
];

function total(items: Item[]) {
  return items.reduce((a, b) => a + b.minutes, 0);
}

export default function Routines({ dateISO }: { dateISO: string }) {
  const [userId, setUserId] = useState<string | null>(null);
  const [doneKeys, setDoneKeys] = useState<Record<string, boolean>>({});

  const dateKey = dateISO;
  const lsKey = `familiaCM:routines:${dateKey}`;

  useEffect(() => {
    if (!isSupabaseConfigured) {
      setDoneKeys(lsGet(lsKey, {}));
      return;
    }
    supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id ?? null));
  }, [lsKey]);

  // Load routine logs (Supabase)
  useEffect(() => {
    if (!isSupabaseConfigured) return;
    if (!userId) return;
    const run = async () => {
      const { data, error } = await supabase
        .from("routine_logs")
        .select("routine_type,item_key,done")
        .eq("user_id", userId)
        .eq("log_date", dateKey);

      if (error) return;
      const map: Record<string, boolean> = {};
      for (const r of data ?? []) map[`${r.routine_type}:${r.item_key}`] = !!r.done;
      setDoneKeys(map);
    };
    run();
  }, [userId, dateKey]);

  const toggle = async (routine: RoutineType, itemKey: string, value: boolean) => {
    const next = { ...doneKeys, [`${routine}:${itemKey}`]: value };
    setDoneKeys(next);

    if (!isSupabaseConfigured) {
      lsSet(lsKey, next);
      return;
    }
    if (!userId) return;
    await supabase.from("routine_logs").upsert(
      { user_id: userId, log_date: dateKey, routine_type: routine, item_key: itemKey, done: value },
      { onConflict: "user_id,log_date,routine_type,item_key" }
    );
  };

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <RoutineCard
        title={`Rutina mañana (${total(morningItems)} min)`}
        routine="morning"
        items={morningItems}
        doneKeys={doneKeys}
        onToggle={toggle}
      />
      <RoutineCard
        title={`Rutina noche (${total(nightItems)} min)`}
        routine="night"
        items={nightItems}
        doneKeys={doneKeys}
        onToggle={toggle}
      />
    </div>
  );
}

function RoutineCard({
  title,
  routine,
  items,
  doneKeys,
  onToggle
}: {
  title: string;
  routine: RoutineType;
  items: Item[];
  doneKeys: Record<string, boolean>;
  onToggle: (routine: RoutineType, itemKey: string, value: boolean) => void;
}) {
  const doneCount = items.filter((it) => doneKeys[`${routine}:${it.key}`]).length;

  return (
    <div className="card p-4">
      <div className="flex items-baseline justify-between">
        <div className="font-semibold">{title}</div>
        <div className="text-sm text-slate-600">{doneCount}/{items.length}</div>
      </div>
      <div className="mt-3 space-y-2">
        {items.map((it) => {
          const checked = !!doneKeys[`${routine}:${it.key}`];
          return (
            <label key={it.key} className="flex items-center gap-3">
              <input
                type="checkbox"
                className="h-4 w-4"
                checked={checked}
                onChange={(e) => onToggle(routine, it.key, e.target.checked)}
              />
              <span className="flex-1 text-sm">{it.label}</span>
              <span className="text-xs text-slate-500 font-mono">{it.minutes}m</span>
            </label>
          );
        })}
      </div>
    </div>
  );
}
