"use client";

import clsx from "clsx";
import { useEffect, useMemo, useState, type ReactNode } from "react";

import type { PersonKey, Routine2, RoutineSection } from "@/lib/routines2";
import {
  daysRemainingToSunday,
  formatAssignees,
  getActiveSectionForDate,
  isoToday,
  loadActivePerson,
  loadCompletions2,
  loadRoutines2,
  LS_ROUTINES,
  routineDone,
  saveActivePerson,
  saveCompletions2,
  saveRoutines2,
  setRoutineDone,
} from "@/lib/routines2";

function personMeta(p: PersonKey) {
  return p === "carlos"
    ? { label: "C", bird: "🦅", name: "Carlos" }
    : { label: "D", bird: "🕊️", name: "Davinia" };
}

function daysLabel(n: number) {
  if (n === 1) return "1 día";
  return `${n} días`;
}

function AssigneeBadges({ assignedTo }: { assignedTo: PersonKey[] }) {
  if (!assignedTo || assignedTo.length === 0) {
    return <span className="nido-badge">🐣 libre</span>;
  }
  return (
    <div className="flex items-center gap-2">
      {assignedTo.includes("davinia") ? <span className="nido-badge">D 🕊️</span> : null}
      {assignedTo.includes("carlos") ? <span className="nido-badge">C 🦅</span> : null}
    </div>
  );
}

function SectionTitle({ title, right }: { title: string; right?: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <div className="text-base font-semibold text-[hsl(var(--foreground))]">{title}</div>
      {right}
    </div>
  );
}

export default function Routines2PageClient() {
  const dateISO = useMemo(() => isoToday(), []);

  const [routines, setRoutines] = useState<Routine2[]>(() => loadRoutines2());
  const [completions, setCompletions] = useState(() => loadCompletions2());
  const [activePerson, setActivePerson] = useState<PersonKey>(() => loadActivePerson());

  // Selection / assignment
  const [selectMode, setSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Record<string, boolean>>({});
  const [assignTo, setAssignTo] = useState<Record<PersonKey, boolean>>({ carlos: false, davinia: false });

  // Persist seed if missing
  useEffect(() => {
    try {
      if (typeof window === "undefined") return;
      const has = window.localStorage.getItem(LS_ROUTINES);
      if (!has) saveRoutines2(routines);
    } catch {
      // ignore
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    saveActivePerson(activePerson);
  }, [activePerson]);

  const activeDaily = useMemo(() => getActiveSectionForDate(dateISO), [dateISO]);

  const weekday = useMemo(() => routines.filter((r) => r.section === "weekday").sort((a, b) => a.sort - b.sort), [routines]);
  const weekend = useMemo(() => routines.filter((r) => r.section === "weekend").sort((a, b) => a.sort - b.sort), [routines]);
  const weekly = useMemo(() => routines.filter((r) => r.section === "weekly").sort((a, b) => a.sort - b.sort), [routines]);

  const remaining = useMemo(() => daysRemainingToSunday(dateISO), [dateISO]);

  const selectedCount = useMemo(() => Object.values(selectedIds).filter(Boolean).length, [selectedIds]);

  const canApply = useMemo(() => {
    const anyAssignee = assignTo.carlos || assignTo.davinia;
    return selectMode && selectedCount > 0 && anyAssignee;
  }, [selectMode, selectedCount, assignTo]);

  const applyAssignment = () => {
    if (!canApply) return;

    const nextAssignees: PersonKey[] = [
      ...(assignTo.davinia ? (["davinia"] as PersonKey[]) : []),
      ...(assignTo.carlos ? (["carlos"] as PersonKey[]) : []),
    ];

    const next = routines.map((r) => {
      if (!selectedIds[r.id]) return r;
      return { ...r, assignedTo: nextAssignees };
    });

    setRoutines(next);
    saveRoutines2(next);

    // reset selection
    setSelectedIds({});
    setAssignTo({ carlos: false, davinia: false });
    setSelectMode(false);
  };

  const toggleDone = (r: Routine2, value: boolean) => {
    const next = setRoutineDone(completions, r.section, r.id, dateISO, activePerson, value);
    setCompletions(next);
    saveCompletions2(next);
  };

  const toggleSelected = (id: string, value: boolean) => {
    setSelectedIds((prev) => ({ ...prev, [id]: value }));
  };

  const sectionDisabled = (section: RoutineSection) => {
    if (section === "weekly") return false;
    return section !== activeDaily;
  };

  const renderRow = (r: Routine2) => {
    const done = routineDone(completions, r.section, r.id, dateISO);
    const who = done ? personMeta(done.doneBy) : null;

    const disabled = sectionDisabled(r.section);

    return (
      <div
        key={r.id}
        className={clsx(
          "flex items-center gap-3 rounded-xl border border-[hsl(var(--border))] px-3 py-2",
          "bg-[hsl(var(--card)/0.35)]",
          disabled && "opacity-60",
          done &&
            (done.doneBy === "carlos"
              ? "ring-1 ring-[hsl(var(--primary)/0.28)]"
              : "ring-1 ring-[hsl(var(--secondary)/0.28)]")
        )}
      >
        {selectMode ? (
          <input
            type="checkbox"
            className="h-4 w-4"
            checked={!!selectedIds[r.id]}
            onChange={(e) => toggleSelected(r.id, e.target.checked)}
          />
        ) : (
          <input
            type="checkbox"
            className="h-4 w-4"
            checked={!!done}
            disabled={disabled}
            onChange={(e) => toggleDone(r, e.target.checked)}
          />
        )}

        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold text-[hsl(var(--foreground))]">{r.label}</div>
          <div className="mt-1 flex flex-wrap items-center gap-2">
            <AssigneeBadges assignedTo={r.assignedTo} />
            <span className="text-xs text-[hsl(var(--muted-foreground))]">{formatAssignees(r.assignedTo)}</span>
          </div>
        </div>

        {done && who ? (
          <span className="nido-badge" title={`Hecho por ${who.name}`}>✓ {who.label} {who.bird}</span>
        ) : null}
      </div>
    );
  };

  const doneCount = (list: Routine2[]) => {
    return list.filter((r) => !!routineDone(completions, r.section, r.id, dateISO)).length;
  };

  return (
    <div className="space-y-4">
      {/* Selector + acciones */}
      <div className="card p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="nido-eyebrow">Rutinas</div>
            <div className="mt-2 text-xl font-semibold tracking-tight text-[hsl(var(--foreground))]">
              Orden suave. Sin drama.
            </div>
            <div className="mt-2 text-sm text-[hsl(var(--muted-foreground))]">
              Marca rápido y sigue. Los pollitos no necesitan perfección.
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-[hsl(var(--muted-foreground))]">Marcando como</span>
            {(["davinia", "carlos"] as PersonKey[]).map((p) => {
              const meta = personMeta(p);
              const active = activePerson === p;
              return (
                <button
                  key={p}
                  type="button"
                  className={clsx("nido-pill", active && "is-active")}
                  onClick={() => setActivePerson(p)}
                  aria-pressed={active}
                >
                  <span className="text-sm">{meta.label}</span>
                  <span className="text-sm" aria-hidden="true">
                    {meta.bird}
                  </span>
                </button>
              );
            })}

            <button
              type="button"
              className={clsx("btn", selectMode && "btn-primary")}
              onClick={() => {
                if (selectMode) {
                  setSelectMode(false);
                  setSelectedIds({});
                  setAssignTo({ carlos: false, davinia: false });
                } else {
                  setSelectMode(true);
                }
              }}
            >
              {selectMode ? "Salir" : "Asignar"}
            </button>
          </div>
        </div>

        {selectMode ? (
          <div className="mt-4 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/0.35)] p-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="text-sm font-semibold text-[hsl(var(--foreground))]">
                Seleccionadas: {selectedCount}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  className={clsx("nido-pill", assignTo.davinia && "is-active")}
                  onClick={() => setAssignTo((p) => ({ ...p, davinia: !p.davinia }))}
                >
                  D <span aria-hidden="true">🕊️</span>
                </button>
                <button
                  type="button"
                  className={clsx("nido-pill", assignTo.carlos && "is-active")}
                  onClick={() => setAssignTo((p) => ({ ...p, carlos: !p.carlos }))}
                >
                  C <span aria-hidden="true">🦅</span>
                </button>

                <button type="button" className={clsx("btn-primary", !canApply && "opacity-50")} disabled={!canApply} onClick={applyAssignment}>
                  Aplicar
                </button>
              </div>
            </div>

            <div className="mt-2 text-xs text-[hsl(var(--muted-foreground))]">
              Consejo del dodo 🦤: asigna 2–3 cosas, no el mundo entero.
            </div>
          </div>
        ) : null}
      </div>

      {/* Lun–Vie */}
      <div className="card p-4">
        <SectionTitle
          title="Lun–Vie"
          right={<span className="nido-badge">{doneCount(weekday)}/{weekday.length}</span>}
        />
        {sectionDisabled("weekday") ? (
          <div className="mt-2 text-sm text-[hsl(var(--muted-foreground))]">
            Hoy no toca. Esto se marca de lunes a viernes.
          </div>
        ) : null}
        <div className="mt-3 space-y-2">
          {weekday.length > 0 ? weekday.map(renderRow) : (
            <div className="text-sm text-[hsl(var(--muted-foreground))]">Sin rutinas de semana. Un nido minimalista.</div>
          )}
        </div>
      </div>

      {/* Sáb–Dom */}
      <div className="card p-4">
        <SectionTitle
          title="Sáb–Dom"
          right={<span className="nido-badge">{doneCount(weekend)}/{weekend.length}</span>}
        />
        {sectionDisabled("weekend") ? (
          <div className="mt-2 text-sm text-[hsl(var(--muted-foreground))]">
            Guardado para el finde. Los pollitos no corren.
          </div>
        ) : null}
        <div className="mt-3 space-y-2">
          {weekend.length > 0 ? weekend.map(renderRow) : (
            <div className="text-sm text-[hsl(var(--muted-foreground))]">Sin rutinas de finde (sí, eso también es un plan).</div>
          )}
        </div>
      </div>

      {/* Semanales */}
      <div className="card p-4">
        <SectionTitle
          title="Semanales"
          right={
            <div className="flex items-center gap-2">
              <span className="nido-badge">Quedan {daysLabel(remaining)}</span>
              <span className="nido-badge">{doneCount(weekly)}/{weekly.length}</span>
            </div>
          }
        />
        <div className="mt-2 text-sm text-[hsl(var(--muted-foreground))]">
          Deadline domingo. Si queda algo, no pasa nada: el nido se reajusta.
        </div>
        <div className="mt-3 space-y-2">
          {weekly.length > 0 ? weekly.map(renderRow) : (
            <div className="text-sm text-[hsl(var(--muted-foreground))]">No hay semanales aún. 🦤 ok.</div>
          )}
        </div>
      </div>
    </div>
  );
}
