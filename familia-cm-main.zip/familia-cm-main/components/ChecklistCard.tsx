"use client";

import { useMemo, useState } from "react";
import type { ChecklistItem, ChecklistKey } from "@/lib/types";
import { lsGet, lsSet } from "@/lib/localStore";
import { categoryMeta } from "@/lib/colors";
// Lightweight uuid fallback (no extra dependency):
function makeId() {
  try {
    // @ts-ignore
    if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
  } catch {}
  return `id_${Math.random().toString(16).slice(2)}${Date.now().toString(16)}`;
}

const listToCategory: Record<ChecklistKey, keyof typeof categoryMeta> = {
  work: "work",
  carlos: "carlos",
  // Checklist combinado: visualmente se comporta como "Casa"
  home_family: "home",
};

const listToAccent: Record<ChecklistKey, string> = {
  work: "accent-yellow-500",
  carlos: "accent-violet-500",
  home_family: "accent-stone-500",
};

export default function ChecklistCard({
  dateISO,
  listKey,
  title,
  iconOverride,
}: {
  dateISO: string;
  listKey: ChecklistKey;
  title: string;
  iconOverride?: string;
}) {
  const storageKey = `familiaCM:checklist:${dateISO}:${listKey}`;
  const meta = categoryMeta[listToCategory[listKey]];
  const accent = listToAccent[listKey];

  const [items, setItems] = useState<ChecklistItem[]>(() => lsGet(storageKey, [] as ChecklistItem[]));
  const [draft, setDraft] = useState("");

  const doneCount = useMemo(() => items.filter((i) => i.done).length, [items]);

  const persist = (next: ChecklistItem[]) => {
    setItems(next);
    lsSet(storageKey, next);
  };

  return (
    <div className="card p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className={`inline-flex items-center gap-2 rounded-full border px-2 py-0.5 text-sm ${meta.pillClass}`}>
              <span className="text-base leading-none">{iconOverride ?? meta.icon}</span>
              <span className="font-medium">{title}</span>
            </span>
            <span className="text-xs text-slate-500">{doneCount}/{items.length}</span>
          </div>
        </div>
      </div>

      <div className="mt-3 space-y-2">
        {items.map((it) => (
          <div key={it.id} className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={it.done}
              onChange={() => {
                persist(items.map((x) => (x.id === it.id ? { ...x, done: !x.done } : x)));
              }}
              className={`h-4 w-4 ${accent}`}
            />
            <div className={`flex-1 text-sm ${it.done ? "line-through text-slate-500" : "text-slate-800"}`}>
              {it.text}
            </div>
            <button
              className="text-slate-400 hover:text-slate-700"
              title="Eliminar"
              onClick={() => persist(items.filter((x) => x.id !== it.id))}
            >
              ✕
            </button>
          </div>
        ))}
      </div>

      <form
        className="mt-3 flex items-center gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          const text = draft.trim();
          if (!text) return;
          persist([...items, { id: makeId(), text, done: false }]);
          setDraft("");
        }}
      >
        <input
          className="notion-input flex-1"
          placeholder="Añadir item…"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
        />
        <button className="notion-btn" type="submit">Añadir</button>
      </form>
    </div>
  );
}
