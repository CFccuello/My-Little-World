"use client";

import { ReactNode, useMemo, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import Nav from "@/components/Nav";
import MobileBottomNav from "@/components/MobileBottomNav";
import IosTopBar from "@/components/IosTopBar";
import PullToRefresh from "@/components/PullToRefresh";
import SplashGate from "@/components/SplashGate";
import ComedorWatcher from "@/components/ComedorWatcher";
import { triggerNidoRefresh } from "@/lib/refreshBus";

export default function Shell({ children }: { children: ReactNode }) {
  const pathname = usePathname() || "/";
  const router = useRouter();
  const [refreshKey, setRefreshKey] = useState(0);

  const showAppChrome = useMemo(() => {
    if (pathname === "/login") return false;
    if (pathname.startsWith("/auth")) return false;
    return true;
  }, [pathname]);

  return (
    <div className="nido-app min-h-[100svh] flex flex-col">
      {/* Background watchers (only when the app chrome is active) */}
      <ComedorWatcher enabled={showAppChrome} />

      {showAppChrome ? (
        <>
          {/* Daily tiny splash (kid-friendly) */}
          <SplashGate />

          <header className="nido-header">
            {/* iPhone / PWA: barra tipo iOS con back (no hay botón físico) */}
            <div className="md:hidden">
              <IosTopBar />
            </div>

            {/* Desktop: cabecera con navegación completa (Carlos) */}
            <div className="hidden md:block">
              <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="nido-logo">N</div>
                  <div className="leading-tight">
                    <div className="text-sm font-semibold text-[hsl(var(--foreground))]">NIDO</div>
                    <div className="text-xs text-[hsl(var(--muted-foreground))]">Lo importante, hoy.</div>
                  </div>
                </div>

                <Nav />
              </div>
            </div>
          </header>
        </>
      ) : null}

      {/* Contenido (scrollable) + Pull-to-refresh */}
      <PullToRefresh
        className="flex-1"
        onRefresh={async () => {
          // Force remount of client components + re-fetch server components.
          triggerNidoRefresh({ reason: "pull-to-refresh" });
          setRefreshKey((k) => k + 1);
          router.refresh();
        }}
      >
        <main className="mx-auto max-w-6xl px-4 py-4 pb-[calc(6.5rem+env(safe-area-inset-bottom))] md:pb-6">
          <div key={refreshKey}>{children}</div>
        </main>
      </PullToRefresh>

      {/* Barra inferior móvil (PWA) */}
      {showAppChrome ? (
        <div className="md:hidden">
          <MobileBottomNav />
        </div>
      ) : null}
    </div>
  );
}
