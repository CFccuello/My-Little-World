"use client";

import { useEffect, useMemo, useState } from "react";
import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";
import type { Task } from "@/lib/types";
import { lsGet, lsSet } from "@/lib/localStore";

const priorities: Task["priority"][] = ["Alta", "Media", "Baja"];
const energies: Task["energy"][] = ["Baja", "Media", "Alta"];

function uid() {
  return Math.random().toString(36).slice(2) + "-" + Date.now().toString(36);
}

export default function Tasks({ todayISO }: { todayISO: string }) {
  const [userId, setUserId] = useState<string | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [form, setForm] = useState({
    title: "",
    window_start: todayISO,
    window_end: todayISO,
    duration_min: 30,
    priority: "Media" as Task["priority"],
    energy: "Media" as Task["energy"]
  });

  const lsKey = "familiaCM:tasks";

  useEffect(() => {
    if (!isSupabaseConfigured) {
      setTasks(lsGet(lsKey, [] as Task[]));
      return;
    }
    supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id ?? null));
  }, []);

  const load = async (uid_: string) => {
    const { data } = await supabase
      .from("tasks")
      .select("*")
      .eq("user_id", uid_)
      .order("done", { ascending: true })
      .order("window_end", { ascending: true })
      .limit(200);
    setTasks((data ?? []) as any);
  };

  useEffect(() => {
    if (!isSupabaseConfigured) return;
    if (!userId) return;
    load(userId);
  }, [userId]);

  const persistLocal = (next: Task[]) => {
    setTasks(next);
    lsSet(lsKey, next);
  };

  const add = async () => {
    if (!form.title.trim()) return;

    if (!isSupabaseConfigured) {
      const next: Task[] = [
        ...tasks,
        {
          id: uid(),
          title: form.title.trim(),
          window_start: form.window_start,
          window_end: form.window_end,
          duration_min: Number(form.duration_min) || 30,
          priority: form.priority,
          energy: form.energy,
          done: false
        }
      ];
      persistLocal(next);
      setForm((p) => ({ ...p, title: "" }));
      return;
    }

    if (!userId) return;
    await supabase.from("tasks").insert({
      user_id: userId,
      title: form.title.trim(),
      window_start: form.window_start,
      window_end: form.window_end,
      duration_min: Number(form.duration_min) || 30,
      priority: form.priority,
      energy: form.energy,
      done: false
    });
    setForm((p) => ({ ...p, title: "" }));
    await load(userId);
  };

  const toggle = async (id: string, done: boolean) => {
    if (!isSupabaseConfigured) {
      persistLocal(tasks.map(t => t.id === id ? { ...t, done } : t));
      return;
    }
    if (!userId) return;
    setTasks((prev) => prev.map(t => t.id === id ? { ...t, done } : t));
    await supabase.from("tasks").update({ done }).eq("id", id).eq("user_id", userId);
  };

  const pendingCount = useMemo(() => tasks.filter(t => !t.done).length, [tasks]);

  return (
    <div className="space-y-4">
      <div className="card p-4">
        <div className="font-semibold">Añadir tarea</div>
        <div className="mt-3 grid gap-3 md:grid-cols-2">
          <div className="md:col-span-2">
            <div className="label">Nombre</div>
            <input className="input" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Ej: Preparar informe semanal" />
          </div>
          <div>
            <div className="label">Ventana inicio</div>
            <input className="input" type="date" value={form.window_start} onChange={(e) => setForm({ ...form, window_start: e.target.value })} />
          </div>
          <div>
            <div className="label">Ventana fin</div>
            <input className="input" type="date" value={form.window_end} onChange={(e) => setForm({ ...form, window_end: e.target.value })} />
          </div>
          <div>
            <div className="label">Duración (min)</div>
            <input className="input" type="number" min={5} step={5} value={form.duration_min} onChange={(e) => setForm({ ...form, duration_min: Number(e.target.value) })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <div className="label">Prioridad</div>
              <select className="input" value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value as any })}>
                {priorities.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <div className="label">Energía</div>
              <select className="input" value={form.energy} onChange={(e) => setForm({ ...form, energy: e.target.value as any })}>
                {energies.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
          </div>
        </div>
        <div className="mt-3 flex items-center gap-2">
          <button className="btn-primary" onClick={add}>Añadir</button>
          <div className="text-sm text-slate-600">Tip: crea la tarea “fea” primero, y luego la ajustas.</div>
        </div>
      </div>

      <div className="card p-4">
        <div className="flex items-baseline justify-between gap-2">
          <div className="font-semibold">Tabla de tareas</div>
          <div className="text-sm text-slate-600">Pendientes: {pendingCount} · Total: {tasks.length}</div>
        </div>

        <div className="mt-3 notion-table-wrap">
          <table className="notion-table">
            <thead>
              <tr>
                <th>Hecha</th>
                <th>Nombre</th>
                <th>Ventana</th>
                <th>Duración</th>
                <th>Prioridad</th>
                <th>Energía</th>
              </tr>
            </thead>
            <tbody>
              {tasks.length === 0 ? (
                <tr>
                  <td colSpan={6} className="notion-empty">Sin tareas aún. Añade una arriba.</td>
                </tr>
              ) : null}
              {tasks.map((t) => (
                <tr key={t.id} className={t.done ? "opacity-60" : ""}>
                  <td>
                    <input type="checkbox" checked={t.done} onChange={(e) => toggle(t.id, e.target.checked)} />
                  </td>
                  <td className="font-medium">{t.title}</td>
                  <td className="font-mono">{t.window_start} → {t.window_end}</td>
                  <td className="font-mono">{t.duration_min}m</td>
                  <td>{t.priority}</td>
                  <td>{t.energy}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
