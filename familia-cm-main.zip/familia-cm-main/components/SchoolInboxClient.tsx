"use client";

import { useEffect, useMemo, useState } from "react";
import { format } from "date-fns";
import { upsertEventLocal } from "@/lib/eventsStore";
import { lsGet, lsSet } from "@/lib/localStore";

type InboxItem = {
  id: string;
  source: "telegram" | "manual";
  receivedAtISO: string;
  summary: string;
  original: string;
  status: "new" | "archived";
};

function makeId(): string {
  return `id_${Math.random().toString(16).slice(2)}${Date.now().toString(16)}`;
}

const STORAGE_KEY = "familiaCM:schoolInbox";

function saveAll(items: InboxItem[]) {
  lsSet(STORAGE_KEY, items);
}

export default function SchoolInboxClient() {
  const [items, setItems] = useState<InboxItem[]>(() => lsGet(STORAGE_KEY, [] as InboxItem[]));
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState({ source: "Greta" as "Greta" | "Máximo" | "Ludoteca", original: "", summary: "" });

  useEffect(() => {
    saveAll(items);
  }, [items]);

  const newCount = useMemo(() => items.filter((x) => x.status === "new").length, [items]);
  const visible = useMemo(() => items.filter((x) => x.status === "new"), [items]);

  const addManual = () => {
    const original = draft.original.trim();
    if (!original) return;
    const summary = (draft.summary.trim() || original.split("\n")[0]).slice(0, 180);
    setItems((prev) => [
      {
        id: makeId(),
        source: "manual",
        receivedAtISO: new Date().toISOString(),
        summary: `[${draft.source}] ${summary}`,
        original,
        status: "new",
      },
      ...prev,
    ]);
    setOpen(false);
    setDraft({ source: "Greta", original: "", summary: "" });
  };

  const archive = (id: string) => setItems((prev) => prev.map((x) => (x.id === id ? { ...x, status: "archived" } : x)));

  const createEventQuick = (it: InboxItem) => {
    // MVP: crea un evento "Cole" hoy 10:00–11:00 con el resumen
    const dateISO = format(new Date(), "yyyy-MM-dd");
    const start = new Date(`${dateISO}T10:00:00`);
    const end = new Date(`${dateISO}T11:00:00`);
    upsertEventLocal({ title: `Cole · ${it.summary}`, startISO: start.toISOString(), endISO: end.toISOString() });
    archive(it.id);
  };

  return (
    <div className="space-y-4">
      <div className="card p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <div className="font-semibold">Inbox común</div>
            <div className="text-sm text-slate-600">Pendientes: <b>{newCount}</b></div>
          </div>
          <div className="flex items-center gap-2">
            <button className="notion-btn" onClick={() => setOpen(true)}>+ Añadir mensaje</button>
            <button className="notion-btn" onClick={() => setItems((p) => p.filter((x) => x.status === "new"))} title="Elimina archivados">Limpiar archivados</button>
          </div>
        </div>
      </div>

      <div className="card p-4">
        <div className="font-semibold">Mensajes nuevos</div>
        <div className="mt-3 space-y-3">
          {visible.length ? (
            visible.map((it) => (
              <div key={it.id} className="rounded-xl border border-slate-200 bg-white p-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-xs text-slate-500">{format(new Date(it.receivedAtISO), "dd/MM HH:mm")}</div>
                    <div className="mt-1 text-sm font-semibold text-slate-900">{it.summary}</div>
                    <details className="mt-2">
                      <summary className="cursor-pointer text-sm text-slate-600">Ver original</summary>
                      <pre className="mt-2 whitespace-pre-wrap text-xs text-slate-700">{it.original}</pre>
                    </details>
                  </div>
                  <div className="flex shrink-0 flex-col gap-2">
                    <button className="notion-btn" onClick={() => createEventQuick(it)} title="Crea evento hoy 10:00">Crear evento</button>
                    <button className="notion-btn" onClick={() => archive(it.id)}>Archivar ✕</button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-sm text-slate-500">No hay mensajes nuevos. Los pollitos estan en silencio.</div>
          )}
        </div>
        <div className="mt-3 text-xs text-slate-500">
          Nota: la conexión Telegram se implementa en la siguiente iteración. Por ahora puedes pegar el mensaje aquí y convertirlo en evento.
        </div>
      </div>

      {open ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/30" onClick={() => setOpen(false)} />
          <div className="relative w-full max-w-lg rounded-xl border border-slate-200 bg-white p-4 shadow-lg">
            <div className="font-semibold">Añadir mensaje (manual)</div>
            <div className="mt-3 grid gap-2">
              <label className="text-xs text-slate-600">Fuente</label>
              <select className="notion-input" value={draft.source} onChange={(e) => setDraft((p) => ({ ...p, source: e.target.value as any }))}>
                <option value="Greta">Greta</option>
                <option value="Máximo">Máximo</option>
                <option value="Ludoteca">Ludoteca</option>
              </select>
              <label className="text-xs text-slate-600">Resumen (opcional)</label>
              <input className="notion-input" value={draft.summary} onChange={(e) => setDraft((p) => ({ ...p, summary: e.target.value }))} placeholder="Ej: excursión martes / traer 5€..." />
              <label className="text-xs text-slate-600">Mensaje original</label>
              <textarea className="notion-input min-h-[120px]" value={draft.original} onChange={(e) => setDraft((p) => ({ ...p, original: e.target.value }))} placeholder="Pega aquí el mensaje completo..." />
              <div className="flex items-center justify-end gap-2 pt-2">
                <button className="notion-btn" onClick={() => setOpen(false)}>Cancelar</button>
                <button className="notion-btn" onClick={addManual}>Guardar</button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
