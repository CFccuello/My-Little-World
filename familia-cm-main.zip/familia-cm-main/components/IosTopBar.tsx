"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useMemo } from "react";

const TAB_ROOTS = new Set(["/", "/today", "/calendar", "/commands", "/familia"]);

function titleFromPath(pathname: string): string {
  if (pathname === "/") return "NIDO";

  const map: Array<{ prefix: string; title: string }> = [
    { prefix: "/today", title: "Hoy" },
    { prefix: "/calendar", title: "Semana" },
    { prefix: "/commands", title: "Añadir" },
    { prefix: "/familia", title: "Familia" },
    { prefix: "/electricidad", title: "Electricidad" },
    { prefix: "/comida", title: "Comida" },
    { prefix: "/medicacion", title: "Medicación" },
    { prefix: "/routines", title: "Rutinas" },
    { prefix: "/lavavajillas", title: "Lavavajillas" },
    { prefix: "/inspiracion", title: "Inspiración" },
    { prefix: "/tasks", title: "Tareas" },
    { prefix: "/settings", title: "Ajustes" },
    { prefix: "/docs", title: "Docs" },
    { prefix: "/finance", title: "Finanzas" },
    { prefix: "/login", title: "Login" },
  ];

  for (const it of map) {
    if (pathname === it.prefix || pathname.startsWith(it.prefix + "/")) return it.title;
  }
  return "NIDO";
}

export default function IosTopBar() {
  const pathname = usePathname() || "/";
  const router = useRouter();

  const isTabRoot = TAB_ROOTS.has(pathname);
  const showBack = !isTabRoot;

  const title = useMemo(() => titleFromPath(pathname), [pathname]);

  return (
    <div className="nido-ios-topbar">
      {/* Left */}
      <div className="flex items-center justify-start">
        {showBack ? (
          <button
            type="button"
            className="nido-icon-btn"
            aria-label="Atrás"
            onClick={() => {
              // iOS no tiene back físico: damos un comportamiento amable.
              // Si no hay historial dentro de la app, volvemos a Inicio.
              if (typeof window !== "undefined" && window.history.length > 1) {
                router.back();
              } else {
                router.push("/");
              }
            }}
          >
            <span className="nido-ios-back">‹</span>
          </button>
        ) : (
          <div className="nido-logo" aria-label="NIDO">
            N
          </div>
        )}
      </div>

      {/* Center */}
      <div className="nido-ios-title" aria-label="Título">
        {title}
      </div>

      {/* Right */}
      <div className="flex items-center justify-end">
        {pathname === "/settings" ? (
          <div className="w-[2.4rem]" />
        ) : (
          <Link href="/settings" className="nido-icon-btn" aria-label="Ajustes">
            ⚙
          </Link>
        )}
      </div>
    </div>
  );
}
