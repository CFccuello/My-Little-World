"use client";

import clsx from "clsx";
import { ReactNode, useEffect, useMemo, useRef, useState } from "react";

type Props = {
  children: ReactNode;
  className?: string;
  onRefresh?: () => void | Promise<void>;
};

const MAX_PULL = 120;
const THRESHOLD = 84;

export default function PullToRefresh({ children, className, onRefresh }: Props) {
  const scrollerRef = useRef<HTMLDivElement | null>(null);

  const startYRef = useRef<number>(0);
  const pullingRef = useRef<boolean>(false);
  const refreshingRef = useRef<boolean>(false);

  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  const label = useMemo(() => {
    if (refreshing) return "Actualizando el nido…";
    if (pull >= THRESHOLD) return "Suelta para refrescar";
    if (pull > 0) return "Tira para refrescar";
    return "";
  }, [pull, refreshing]);

  useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;

    const onTouchStart = (e: TouchEvent) => {
      if (refreshingRef.current) return;
      // Only start if we are at the top.
      if (el.scrollTop > 0) return;
      pullingRef.current = true;
      startYRef.current = e.touches[0]?.clientY ?? 0;
    };

    const onTouchMove = (e: TouchEvent) => {
      if (!pullingRef.current) return;
      if (refreshingRef.current) return;
      // Only when at top.
      if (el.scrollTop > 0) return;

      const y = e.touches[0]?.clientY ?? 0;
      const raw = y - startYRef.current;
      if (raw <= 0) {
        setPull(0);
        return;
      }
      // Prevent the browser “rubber band” when we are pulling.
      e.preventDefault();

      // Ease down the distance.
      const eased = Math.min(MAX_PULL, Math.round(raw * 0.55));
      setPull(eased);
    };

    const finish = async () => {
      if (!pullingRef.current) return;
      pullingRef.current = false;

      if (refreshingRef.current) return;

      if (pull >= THRESHOLD) {
        refreshingRef.current = true;
        setRefreshing(true);
        setPull(THRESHOLD);
        try {
          await onRefresh?.();
        } finally {
          // Small delay feels more “native”.
          await new Promise((r) => setTimeout(r, 250));
          refreshingRef.current = false;
          setRefreshing(false);
          setPull(0);
        }
        return;
      }

      setPull(0);
    };

    const onTouchEnd = () => {
      void finish();
    };

    el.addEventListener("touchstart", onTouchStart, { passive: true });
    el.addEventListener("touchmove", onTouchMove, { passive: false });
    el.addEventListener("touchend", onTouchEnd, { passive: true });
    el.addEventListener("touchcancel", onTouchEnd, { passive: true });

    return () => {
      el.removeEventListener("touchstart", onTouchStart);
      el.removeEventListener("touchmove", onTouchMove);
      el.removeEventListener("touchend", onTouchEnd);
      el.removeEventListener("touchcancel", onTouchEnd);
    };
  }, [onRefresh, pull]);

  return (
    <div ref={scrollerRef} className={clsx("nido-scroll nido-ptr", className)}>
      <div className="nido-ptr-indicator" style={{ height: pull }} aria-hidden={pull === 0}>
        <div className={clsx("nido-ptr-inner", refreshing && "is-refreshing")}>
          <div className="nido-ptr-bird" aria-hidden="true">
            {refreshing ? "🪶" : pull >= THRESHOLD ? "🐥" : "🪺"}
          </div>
          <div className="nido-ptr-label">{label}</div>
        </div>
      </div>

      <div
        className={clsx("nido-ptr-content", pull > 0 && "is-pulling", refreshing && "is-refreshing")}
        style={{ transform: pull > 0 ? `translateY(${pull}px)` : undefined }}
      >
        {children}
      </div>
    </div>
  );
}
