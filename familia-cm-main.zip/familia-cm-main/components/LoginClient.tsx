"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import clsx from "clsx";
import { isSupabaseConfigured, supabase } from "@/lib/supabaseClient";

const LS_EMAIL_KEY = "nido:last_email";

function safeReturnTo(raw: string | null): string {
  const v = (raw || "").trim();
  if (!v) return "/";
  if (!v.startsWith("/")) return "/";
  return v;
}

export default function LoginClient() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const returnTo = useMemo(() => safeReturnTo(searchParams?.get("return_to")), [searchParams]);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  useEffect(() => {
    if (!isSupabaseConfigured) return;

    const last = window.localStorage.getItem(LS_EMAIL_KEY);
    if (last && !email) setEmail(last);

    let mounted = true;

    supabase.auth.getSession().then(({ data }) => {
      if (!mounted) return;
      if (data.session) router.replace(returnTo);
    });

    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      if (session) router.replace(returnTo);
    });

    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [returnTo]);

  const handleLogin = async () => {
    setError("");
    setMessage("");

    const e = email.trim();
    if (!e || !password) {
      setError("Introduce email y contraseña");
      return;
    }

    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({
      email: e,
      password,
    });
    setLoading(false);

    if (error) {
      setError(error.message);
      return;
    }

    window.localStorage.setItem(LS_EMAIL_KEY, e);
    router.replace(returnTo);
    router.refresh();
  };

  const handleForgotPassword = async () => {
    setError("");
    setMessage("");

    const e = email.trim();
    if (!e) {
      setError("Primero escribe tu email para enviarte el enlace");
      return;
    }

    setLoading(true);
    const redirectTo = `${window.location.origin}/auth/reset`;
    const { error } = await supabase.auth.resetPasswordForEmail(e, { redirectTo });
    setLoading(false);

    if (error) {
      setError(error.message);
      return;
    }

    window.localStorage.setItem(LS_EMAIL_KEY, e);
    setMessage("Te he enviado un email para crear una nueva contraseña.");
  };

  return (
    <div className="mx-auto w-full max-w-md px-4 pt-10">
      <div className="card p-6">
        <div className="nido-eyebrow">Acceso</div>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight text-[hsl(var(--foreground))]">
          Entrar en NIDO
        </h1>
        <p className="mt-2 text-sm text-[hsl(var(--muted-foreground))]">
          Email + contraseña. Acceso solo por invitación.
        </p>

        {!isSupabaseConfigured ? (
          <div className="nido-callout nido-callout-amber mt-4">
            <div className="font-semibold">Modo demo</div>
            <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">
              Supabase no está configurado en este entorno. Puedes entrar directamente en la app.
            </div>
            <div className="mt-3">
              <button className="btn-primary" onClick={() => router.replace("/")}>
                Ir a Inicio
              </button>
            </div>
          </div>
        ) : null}

        <div className="mt-5 space-y-3">
          <div>
            <label className="label">Email</label>
            <input
              type="email"
              placeholder="carlos@…"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="input mt-1"
              autoComplete="email"
              inputMode="email"
            />
          </div>

          <div>
            <label className="label">Contraseña</label>
            <input
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="input mt-1"
              autoComplete="current-password"
            />
          </div>

          {error ? <p className="text-sm text-amber-700">{error}</p> : null}
          {message ? <p className="text-sm text-emerald-700">{message}</p> : null}

          <button
            onClick={handleLogin}
            disabled={loading || !isSupabaseConfigured}
            className={clsx(
              "btn-primary w-full",
              (loading || !isSupabaseConfigured) && "opacity-60 cursor-not-allowed"
            )}
          >
            {loading ? "Entrando…" : "Entrar"}
          </button>

          <button
            onClick={handleForgotPassword}
            disabled={loading || !isSupabaseConfigured}
            className={clsx(
              "btn w-full",
              (loading || !isSupabaseConfigured) && "opacity-60 cursor-not-allowed"
            )}
          >
            He olvidado mi contraseña
          </button>

          <div className="pt-2 text-xs text-[hsl(var(--muted-foreground))]">
            Tip del dodo 🦤: si Safari te hace cosas raras, cierra la PWA y ábrela otra vez.
          </div>
        </div>
      </div>
    </div>
  );
}
