"use client";

import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

export default function Protected({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const pathname = usePathname() || "/";

  useEffect(() => {
    if (!isSupabaseConfigured) {
      // Demo mode (no Supabase). We still allow navigating the UI,
      // but we avoid showing a big banner on every screen.
      setReady(true);
      return;
    }
    let mounted = true;
    let initialResolved = false;

    const redirectToLogin = () => {
      const returnTo = encodeURIComponent(pathname);
      window.location.href = `/login?return_to=${returnTo}`;
    };

    const finish = (session: any) => {
      if (!mounted) return;
      if (!session?.user) {
        redirectToLogin();
        return;
      }
      setReady(true);
    };

    // Wait for INITIAL_SESSION. This avoids “ghost redirects” when the PWA
    // reloads and the session hasn't hydrated yet.
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (!mounted) return;
      if (event === "INITIAL_SESSION") {
        initialResolved = true;
        finish(session);
      }
    });

    // Fallback: if INITIAL_SESSION doesn't arrive, check manually.
    const t = window.setTimeout(async () => {
      if (!mounted) return;
      if (initialResolved) return;
      const { data } = await supabase.auth.getSession();
      finish(data.session);
    }, 1200);

    return () => {
      mounted = false;
      window.clearTimeout(t);
      sub.subscription.unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname]);

  if (!ready) {
    return (
      <div className="card p-5">
        <div className="text-sm text-[hsl(var(--muted-foreground))]">Cargando...</div>
      </div>
    );
  }

  return (
    <>
      {children}
    </>
  );
}
