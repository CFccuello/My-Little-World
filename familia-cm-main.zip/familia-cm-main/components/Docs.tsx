"use client";

import { useEffect, useMemo, useState } from "react";
import clsx from "clsx";

type DocGroup = "Bancos" | "Médicos" | "Facturas" | "Cole" | "Manuales / Instrucciones" | "Otros";

type DocLink = {
  id: string;
  title: string;
  group: DocGroup;
  url: string;
  note?: string;
  createdAt: number;
};

const GROUPS: DocGroup[] = ["Bancos", "Médicos", "Facturas", "Cole", "Manuales / Instrucciones", "Otros"];

function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function safeUrl(url: string) {
  const u = url.trim();
  if (!u) return "";
  if (u.startsWith("http://") || u.startsWith("https://")) return u;
  return `https://${u}`;
}

function migrateGroup(g: string): DocGroup {
  // Migración suave: “Garantías” -> “Manuales / Instrucciones”
  const t = (g || "").trim();
  if (t.toLowerCase() === "garantías" || t.toLowerCase() === "garantias") return "Manuales / Instrucciones";
  if (GROUPS.includes(t as DocGroup)) return t as DocGroup;
  return "Otros";
}

export default function Docs() {
  const lsKey = "nido:docs";
  const [items, setItems] = useState<DocLink[]>([]);
  const [title, setTitle] = useState("");
  const [group, setGroup] = useState<DocGroup>("Otros");
  const [url, setUrl] = useState("");
  const [note, setNote] = useState("");
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(lsKey);
      if (!raw) return;

      const parsed = JSON.parse(raw) as any[];
      const migrated: DocLink[] = (parsed || [])
        .map((x) => ({
          id: String(x.id ?? uid()),
          title: String(x.title ?? "").trim(),
          group: migrateGroup(String(x.group ?? "Otros")),
          url: safeUrl(String(x.url ?? "")),
          note: x.note ? String(x.note) : undefined,
          createdAt: Number(x.createdAt ?? Date.now()),
        }))
        .filter((x) => x.title && x.url);

      setItems(migrated);

      // Guardamos ya migrado (para no arrastrar “Garantías”).
      localStorage.setItem(lsKey, JSON.stringify(migrated));
    } catch {
      // silencioso: en el nido no hacemos dramas
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(lsKey, JSON.stringify(items));
    } catch {}
  }, [items]);

  const canAdd = useMemo(() => title.trim().length > 0 && url.trim().length > 0, [title, url]);

  function add() {
    if (!canAdd) return;

    const u = safeUrl(url);
    if (!u) return;

    const next: DocLink = {
      id: uid(),
      title: title.trim(),
      group,
      url: u,
      note: note.trim() || undefined,
      createdAt: Date.now(),
    };

    setItems([next, ...items]);
    setTitle("");
    setUrl("");
    setNote("");
    setGroup("Otros");
    setMessage("Guardado 🐣");
  }

  function remove(id: string) {
    setItems(items.filter((x) => x.id !== id));
  }

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border bg-white p-4">
        <div className="text-sm font-semibold text-slate-900">Docs (enlaces rápidos)</div>
        <div className="text-xs text-slate-500 mt-1">
          Idea simple: en OneDrive, guarda todo bajo <span className="font-mono">NIDO/Docs</span> y aquí pegas los enlaces.
          El pollito 🐥 se encarga de recordarlo.
        </div>

        {message ? <div className="mt-3 text-sm text-slate-700">{message}</div> : null}

        <div className="grid gap-2 mt-4 md:grid-cols-6">
          <input
            className="md:col-span-2 rounded-xl border px-3 py-2 text-sm"
            placeholder="Nombre (ej: Seguro coche, Tarjeta sanitaria…)"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />

          <select
            className="md:col-span-1 rounded-xl border px-3 py-2 text-sm bg-white"
            value={group}
            onChange={(e) => setGroup(e.target.value as DocGroup)}
          >
            {GROUPS.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>

          <input
            className="md:col-span-2 rounded-xl border px-3 py-2 text-sm"
            placeholder="Enlace OneDrive / URL"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
          />

          <button
            className={clsx(
              "md:col-span-1 rounded-xl px-3 py-2 text-sm font-medium",
              canAdd ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-400 cursor-not-allowed"
            )}
            onClick={add}
            disabled={!canAdd}
          >
            Guardar
          </button>

          <input
            className="md:col-span-6 rounded-xl border px-3 py-2 text-sm"
            placeholder="Nota opcional (ej: vence 2026-03-01)"
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
        </div>
      </div>

      <div className="rounded-2xl border bg-white p-4">
        <div className="text-sm font-semibold text-slate-900">Enlaces guardados</div>

        {items.length === 0 ? (
          <div className="text-sm text-slate-600 mt-3">
            Aún no hay enlaces. Empieza por uno (Bancos, Médicos, Cole o Manuales) y listo 🐣
          </div>
        ) : (
          <div className="mt-3 grid gap-2">
            {items.map((it) => (
              <div key={it.id} className="rounded-xl border p-3 flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-slate-900 truncate">{it.title}</div>
                  <div className="text-xs text-slate-500 mt-0.5">{it.group}</div>
                  {it.note && <div className="text-xs text-slate-600 mt-1">{it.note}</div>}
                  <a
                    className="text-xs text-blue-700 underline mt-2 inline-block"
                    href={it.url}
                    target="_blank"
                    rel="noreferrer"
                  >
                    Abrir (OneDrive)
                  </a>
                </div>

                <button
                  className="text-xs rounded-lg border px-2 py-1 text-slate-600 hover:bg-slate-50"
                  onClick={() => remove(it.id)}
                >
                  Quitar
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="card p-4">
        <div className="text-xs text-slate-500">
          Nota: en B04 haremos “Docs por persona” (tiles). Esto es V1 rápido para que nada se pierda.
        </div>
      </div>
    </div>
  );
}
