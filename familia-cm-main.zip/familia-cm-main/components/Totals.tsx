import { categoryMeta } from "@/lib/colors";
import type { ColorKey } from "@/lib/types";

export default function Totals({ totals }: { totals: Record<string, number> }) {
  const entries = Object.entries(totals)
    .sort((a, b) => b[1] - a[1]);

  const fmt = (mins: number) => {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return `${h}h ${String(m).padStart(2, "0")}m`;
  };

  return (
    <div className="card p-4">
      <div className="font-semibold">Totales (por labor)</div>
      <div className="mt-3 space-y-2 text-sm">
        {entries.map(([k, mins]) => (
          <div key={k} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {(() => {
                const key = k as ColorKey;
                const meta = (categoryMeta as any)[key];
                if (!meta) return <span className="text-slate-700">{k}</span>;
                return (
                  <span className={`inline-flex items-center gap-2 rounded-full border px-2 py-0.5 ${meta.pillClass}`}>
                    <span className="text-base leading-none">{meta.icon}</span>
                    <span className="font-medium">{meta.label}</span>
                  </span>
                );
              })()}
            </div>
            <div className="font-mono text-slate-700">{fmt(mins)}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
