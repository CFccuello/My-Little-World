"use client";

import { useEffect, useMemo, useState } from "react";
import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";
import { differenceInCalendarDays, parseISO } from "date-fns";
import { lsGet, lsSet } from "@/lib/localStore";

type MedRow = { med_key: string; done: boolean; log_date: string };

export default function Medication({ dateISO }: { dateISO: string }) {
  const [userId, setUserId] = useState<string | null>(null);
  const [today, setToday] = useState<Record<string, boolean>>({});
  const [lastDutaDate, setLastDutaDate] = useState<string | null>(null);

  const lsKey = `familiaCM:meds:${dateISO}`;
  const lsLastKey = `familiaCM:meds:lastDuta`;

  useEffect(() => {
    if (!isSupabaseConfigured) {
      setToday(lsGet(lsKey, {}));
      setLastDutaDate(lsGet(lsLastKey, null));
      return;
    }
    supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id ?? null));
  }, [lsKey]);

  useEffect(() => {
    if (!isSupabaseConfigured) return;
    if (!userId) return;
    const run = async () => {
      const { data } = await supabase
        .from("med_logs")
        .select("med_key,done,log_date")
        .eq("user_id", userId)
        .eq("log_date", dateISO);

      const map: Record<string, boolean> = {};
      for (const r of (data ?? []) as MedRow[]) map[r.med_key] = !!r.done;
      setToday(map);

      const { data: last } = await supabase
        .from("med_logs")
        .select("log_date")
        .eq("user_id", userId)
        .eq("med_key", "dutasteride")
        .eq("done", true)
        .order("log_date", { ascending: false })
        .limit(1);

      setLastDutaDate(last?.[0]?.log_date ?? null);
    };
    run();
  }, [userId, dateISO]);

  const dutaSuggestion = useMemo(() => {
    if (!lastDutaDate) return "Toca (no hay registro previo).";
    const diff = differenceInCalendarDays(parseISO(dateISO), parseISO(lastDutaDate));
    if (diff === 0) return "Ya está registrada hoy.";
    if (diff === 1) return "Hoy NO toca (alterno).";
    if (diff % 2 === 0) return "Toca hoy (alterno).";
    return "Hoy NO toca (alterno).";
  }, [dateISO, lastDutaDate]);

  const toggle = async (med_key: "loniten" | "dutasteride", value: boolean) => {
    const next = { ...today, [med_key]: value };
    setToday(next);

    if (!isSupabaseConfigured) {
      lsSet(lsKey, next);
      if (med_key === "dutasteride" && value) {
        setLastDutaDate(dateISO);
        lsSet(lsLastKey, dateISO);
      }
      return;
    }

    if (!userId) return;
    await supabase.from("med_logs").upsert(
      { user_id: userId, log_date: dateISO, med_key, done: value },
      { onConflict: "user_id,log_date,med_key" }
    );
    if (med_key === "dutasteride" && value) setLastDutaDate(dateISO);
  };

  return (
    <div className="card p-4">
      <div className="font-semibold">Medicación (🟨 Salud)</div>
      <div className="mt-3 space-y-3 text-sm">
        <MedLine
          label="Loniten 0,5 (diario)"
          checked={!!today["loniten"]}
          onChange={(v) => toggle("loniten", v)}
          hint="Recomendación: después del desayuno."
        />
        <MedLine
          label="Dutasteride (día sí / día no)"
          checked={!!today["dutasteride"]}
          onChange={(v) => toggle("dutasteride", v)}
          hint={dutaSuggestion}
        />
      </div>
      <div className="mt-3 text-xs text-slate-500">
        Nota: esto es un recordatorio/registro. No modifica pautas médicas.
      </div>
    </div>
  );
}

function MedLine({
  label, checked, onChange, hint
}: { label: string; checked: boolean; onChange: (v: boolean) => void; hint: string }) {
  return (
    <div className="flex items-start gap-3">
      <input
        type="checkbox"
        className="h-4 w-4 mt-0.5"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
      />
      <div className="flex-1">
        <div className="font-medium">{label}</div>
        <div className="text-slate-600">{hint}</div>
      </div>
    </div>
  );
}
