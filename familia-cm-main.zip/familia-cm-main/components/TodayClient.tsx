"use client";

import Legend from "@/components/Legend";
import DayTimeline from "@/components/DayTimeline";
import Totals from "@/components/Totals";
import Routines from "@/components/Routines";
import Medication from "@/components/Medication";
import ChecklistCard from "@/components/ChecklistCard";
import { buildDefaultSchedule, defaultSettings, totalsByColor } from "@/lib/schedule";
import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";
import type { Settings } from "@/lib/types";
import { format } from "date-fns";
import { useEffect, useMemo, useState } from "react";
import { lsGet } from "@/lib/localStore";

export default function TodayClient() {
  const dateISO = format(new Date(), "yyyy-MM-dd");
  const [settings, setSettings] = useState<Settings>(defaultSettings());

  useEffect(() => {
    if (!isSupabaseConfigured) {
      setSettings(lsGet("familiaCM:settings", defaultSettings()));
      return;
    }
    const run = async () => {
      const { data: u } = await supabase.auth.getUser();
      const uid = u.user?.id;
      if (!uid) return;
      const { data } = await supabase.from("settings").select("*").eq("id", uid).single();
      if (data) setSettings(data as any);
      else setSettings((p) => ({ ...p, id: uid }));
    };
    run();
  }, []);

  const built = useMemo(() => buildDefaultSchedule(settings, dateISO), [settings, dateISO]);
  const totals = useMemo(() => totalsByColor(built.blocks), [built.blocks]);

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <div>
            <div className="text-lg font-semibold">Briefing de hoy</div>
            <div className="text-sm text-slate-600">{dateISO} · {settings.tz}</div>
          </div>
          <div className="text-sm font-medium">Frase: “Haz lo importante. Lo demás se acomoda.”</div>
        </div>

        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <div className="card p-4">
            <div className="font-semibold">3 prioridades de trabajo (datos/informes)</div>
            <ol className="mt-2 list-decimal pl-5 text-sm text-slate-700 space-y-1">
              <li>Informe principal: versión enviable + conclusiones claras (1 página o 3 slides).</li>
              <li>Calidad de datos: checks rápidos (outliers, faltantes, cortes).</li>
              <li>Siguiente paso: lista corta de acciones (quién hace qué y cuándo).</li>
            </ol>
          </div>
          <div className="card p-4">
            <div className="font-semibold">1 acción para reducir carga mental en Pareja</div>
            <div className="mt-2 text-sm text-slate-700">
              “Pack invisible”: <b>cocina lista + coche cargando + check-in 5 min</b> (sin móvil).
              Si hay docs, se guardan en <b>Docs</b> (INBOX) y listo.
            </div>
          </div>
        </div>
      </div>

      <Legend />

      {built.warnings.length ? (
        <div className="card p-4 border border-amber-200 bg-amber-50">
          <div className="font-semibold">Avisos</div>
          <ul className="mt-2 text-sm text-amber-900 list-disc pl-5 space-y-1">
            {built.warnings.map((w, i) => <li key={i}>{w}</li>)}
          </ul>
        </div>
      ) : null}

      <div className="grid gap-4 lg:grid-cols-2">
        <DayTimeline blocks={built.blocks} title="Horario del día (timeline · pasado en gris)" />
        <Totals totals={totals} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <ChecklistCard dateISO={dateISO} listKey="work" title="Checklist Trabajo" />
        <ChecklistCard dateISO={dateISO} listKey="carlos" title="Checklist Carlos" />
        <ChecklistCard dateISO={dateISO} listKey="home_family" title="Checklist Casa & Familia" iconOverride="🏡👨🏻‍🦱👱🏻‍♀️👧🏻👦🏻👶🏻" />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Medication dateISO={dateISO} />
        <div className="card p-4">
          <div className="font-semibold">Reglas aplicadas</div>
          <div className="mt-2 text-sm text-slate-700 space-y-1">
            <div><b>Trabajo mínimo:</b> {Number(settings.work_min_hours)}h</div>
            <div><b>Perros:</b> {settings.dogs_minutes} min · <b>Gym:</b> {settings.gym_minutes} min</div>
            <div><b>Comida:</b> {settings.meal_minutes} min · <b>Familia desde:</b> {settings.family_start_evening}</div>
            <div><b>Sueño:</b> {settings.sleep_start} → {settings.sleep_end}</div>
          </div>
        </div>
      </div>

      <Routines dateISO={dateISO} />
    </div>
  );
}
