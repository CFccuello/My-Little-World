"use client";

import { useEffect, useMemo, useState } from "react";
import { format } from "date-fns";
import clsx from "clsx";
import { birdForDate } from "@/lib/birds";

// SplashGate
// - Shows a short (daily) “aww” splash on iPhone/PWA.
// - Dismisses automatically after a short time, or on tap.
// - If a local SVG is available (public/birds/*.svg), it will render it.
//   Fallback to emoji if missing/error.

const LS_KEY = "nido_splash_last_date";

export default function SplashGate() {
  const dateISO = useMemo(() => format(new Date(), "yyyy-MM-dd"), []);
  const bird = useMemo(() => birdForDate(dateISO), [dateISO]);

  const [open, setOpen] = useState(false);
  const [imgOk, setImgOk] = useState(true);

  // Reset image fallback when the bird changes.
  useEffect(() => {
    setImgOk(true);
  }, [bird.image]);

  useEffect(() => {
    try {
      const last = localStorage.getItem(LS_KEY);
      if (last !== dateISO) {
        localStorage.setItem(LS_KEY, dateISO);
        setOpen(true);

        // A hair longer than before so the SVG "reads" without prisa.
        const t = window.setTimeout(() => setOpen(false), 1600);
        return () => window.clearTimeout(t);
      }
    } catch {
      // If localStorage is not available, fail silently.
    }
  }, [dateISO]);

  if (!open) return null;

  const showImage = Boolean(bird.image) && imgOk;

  return (
    <div
      className="nido-splash"
      role="dialog"
      aria-label="Bienvenida"
      onClick={() => setOpen(false)}
    >
      <div
        className={clsx("nido-splash-card")}
        // Prevent scroll behind splash on iOS
        onClick={(e) => {
          e.stopPropagation();
          setOpen(false);
        }}
      >
        {showImage ? (
          <div className="nido-splash-illustration" aria-hidden="true">
            <img
              src={bird.image}
              alt={bird.name}
              onError={() => setImgOk(false)}
            />
          </div>
        ) : (
          <div className="nido-splash-emoji" aria-hidden="true">
            {bird.emoji}
          </div>
        )}

        <div className="nido-splash-title">NIDO</div>
        <div className="nido-splash-sub">{bird.note}</div>
        <div className="nido-splash-hint">Toca para entrar</div>
      </div>
    </div>
  );
}
