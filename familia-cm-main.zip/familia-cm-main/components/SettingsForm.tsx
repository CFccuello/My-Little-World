"use client";

import Link from "next/link";
import clsx from "clsx";
import { useEffect, useMemo, useState } from "react";

import ThemeSelector from "@/components/ThemeSelector";
import { lsGet, lsSet } from "@/lib/localStore";
import { defaultSettings } from "@/lib/schedule";
import { seedRecurringChecklists, seedSchoolEvents } from "@/lib/seedData";
import { isSupabaseConfigured, supabase } from "@/lib/supabaseClient";
import type { Settings } from "@/lib/types";

type Profile = {
  displayName: string;
  photoUrl: string;
  instagramUrl: string;
};

const PROFILE_KEY = "nido:profile";
const SETTINGS_LS_KEY = "familiaCM:settings";
const ADMIN_EMAIL = (process.env.NEXT_PUBLIC_ADMIN_EMAIL ?? "").toLowerCase();

function emptyProfile(): Profile {
  return { displayName: "", photoUrl: "", instagramUrl: "" };
}

export default function SettingsForm() {
  const [userId, setUserId] = useState<string | null>(null);
  const [email, setEmail] = useState<string | null>(null);

  const [profile, setProfile] = useState<Profile>(emptyProfile());
  const [profileMsg, setProfileMsg] = useState<string>("");

  const [settings, setSettings] = useState<Settings>(defaultSettings());
  const [msg, setMsg] = useState<string>("");

  const isAdmin = useMemo(() => {
    // Demo mode: keep it open so you can iterate fast.
    if (!isSupabaseConfigured) return true;
    // If no admin email was configured, do not block (to avoid locking yourself out).
    if (!ADMIN_EMAIL) return true;
    if (!email) return false;
    return email.toLowerCase() === ADMIN_EMAIL;
  }, [email]);

  useEffect(() => {
    // Profile: always local for now (later: Supabase profiles)
    setProfile(lsGet(PROFILE_KEY, emptyProfile()));

    if (!isSupabaseConfigured) {
      setSettings(lsGet(SETTINGS_LS_KEY, defaultSettings()));
      return;
    }

    supabase.auth.getUser().then(({ data }) => {
      setUserId(data.user?.id ?? null);
      setEmail(data.user?.email ?? null);
    });
  }, []);

  useEffect(() => {
    if (!isSupabaseConfigured) return;
    if (!userId) return;
    const run = async () => {
      const { data } = await supabase.from("settings").select("*").eq("id", userId).single();
      if (data) setSettings(data as any);
      else setSettings((p) => ({ ...p, id: userId }));
    };
    run();
  }, [userId]);

  const saveSchedulePrefs = async () => {
    setMsg("Guardando preferencias...");
    if (!isSupabaseConfigured) {
      lsSet(SETTINGS_LS_KEY, settings);
      setMsg("Guardado (local).");
      return;
    }
    if (!userId) return;
    const payload = { ...settings, id: userId };
    const { error } = await supabase.from("settings").upsert(payload, { onConflict: "id" });
    if (error) setMsg(`Error: ${error.message}`);
    else setMsg("Guardado.");
  };

  const saveProfile = () => {
    lsSet(PROFILE_KEY, profile);
    setProfileMsg("Guardado.");
    window.setTimeout(() => setProfileMsg(""), 1600);
  };

  const avatarLabel = (profile.displayName || email || "NIDO").trim();
  const avatarInitial = avatarLabel ? avatarLabel[0]?.toUpperCase() : "N";

  return (
    <div className="space-y-4">
      {!isSupabaseConfigured ? (
        <div className="nido-callout nido-callout-amber">
          <div className="font-semibold">Modo demo</div>
          <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">
            Supabase no está configurado. Puedes probar toda la interfaz, pero los datos se guardan solo en este
            dispositivo.
          </div>
        </div>
      ) : null}

      {/* Mi cuenta */}
      <section className="nido-summary nido-summary-glass">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="nido-eyebrow">Mi cuenta</div>
            <div className="mt-2 text-lg font-semibold tracking-tight text-[hsl(var(--foreground))]">
              Tu perfil y conexiones
            </div>
            <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">
              Un sitio único para tu foto, nombre y redes. (Davinia no tiene que tocar nada aquí.)
            </div>
          </div>
          <span className="nido-badge">{isAdmin ? "Admin" : "Usuario"}</span>
        </div>

        <div className="mt-4 flex items-center gap-3">
          <div
            className={clsx(
              "h-12 w-12 rounded-full border",
              "border-[hsl(var(--border))]",
              "bg-[hsl(var(--card)/0.35)]",
              "grid place-items-center",
              "text-[hsl(var(--foreground))] font-semibold",
            )}
          >
            {profile.photoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={profile.photoUrl}
                alt="Foto de perfil"
                className="h-12 w-12 rounded-full object-cover"
                onError={() => setProfile((p) => ({ ...p, photoUrl: "" }))}
              />
            ) : (
              <span>{avatarInitial}</span>
            )}
          </div>

          <div className="min-w-0">
            <div className="text-sm font-semibold text-[hsl(var(--foreground))] truncate">
              {profile.displayName || "Sin nombre (por ahora)"}
            </div>
            <div className="text-xs text-[hsl(var(--muted-foreground))] truncate">
              {email ? email : "Modo demo"}
            </div>
          </div>
        </div>

        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <Field label="Nombre (visible)" hint="Ej: Carlos">
            <input
              className="input"
              value={profile.displayName}
              onChange={(e) => setProfile((p) => ({ ...p, displayName: e.target.value }))}
              placeholder="Carlos"
            />
          </Field>

          <Field label="Foto (URL)" hint="Opcional. Luego lo conectamos a Storage">
            <input
              className="input"
              value={profile.photoUrl}
              onChange={(e) => setProfile((p) => ({ ...p, photoUrl: e.target.value }))}
              placeholder="https://..."
            />
          </Field>

          <Field label="Instagram (URL)" hint="Para que Inspiración sea 1 toque">
            <input
              className="input"
              value={profile.instagramUrl}
              onChange={(e) => setProfile((p) => ({ ...p, instagramUrl: e.target.value }))}
              placeholder="https://instagram.com/..."
            />
          </Field>

          <div className="hidden md:block" />
        </div>

        <div className="mt-3 flex items-center gap-2">
          <button className="nido-cta" onClick={saveProfile} type="button">
            Guardar
          </button>
          <div className="text-sm text-[hsl(var(--muted-foreground))]">{profileMsg}</div>
        </div>
      </section>

      {/* Preferencias (solo Carlos) */}
      {isAdmin ? (
        <section className="nido-summary nido-summary-glass">
          <div className="nido-eyebrow">Preferencias</div>
          <div className="mt-2 text-lg font-semibold tracking-tight text-[hsl(var(--foreground))]">
            Apariencia y estilo
          </div>
          <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">
            Esto lo gestionas tú. Davinia solo usa la app.
          </div>

          <div className="mt-4">
            <ThemeSelector />
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-2">
            <Link href="/lab" className="nido-badge">
              Ver 5 estilos (Laboratorio)
            </Link>
            {!ADMIN_EMAIL ? (
              <span className="nido-badge">Tip: define NEXT_PUBLIC_ADMIN_EMAIL para bloquear a Davinia</span>
            ) : null}
          </div>
        </section>
      ) : (
        <section className="nido-summary nido-summary-glass">
          <div className="nido-eyebrow">Preferencias</div>
          <div className="mt-2 text-lg font-semibold tracking-tight text-[hsl(var(--foreground))]">
            Tranquila: aquí no hace falta tocar nada
          </div>
          <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">
            Las preferencias las gestiona Carlos. Tú solo abre Inicio y sigue el día.
          </div>
        </section>
      )}

      {/* Reglas base / agenda automática (solo Carlos) */}
      {isAdmin ? (
        <section className="nido-summary nido-summary-glass">
          <div className="nido-eyebrow">Preferencias</div>
          <div className="mt-2 text-lg font-semibold tracking-tight text-[hsl(var(--foreground))]">
            Preferencias de agenda
          </div>
          <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">
            Reglas base para generar la agenda automática (sin solapes).
          </div>

          <div className="mt-4 grid gap-3 md:grid-cols-2">
            <Field label="Trabajo mínimo (horas/día)">
              <input
                className="input"
                type="number"
                min={0}
                step={0.5}
                value={settings.work_min_hours}
                onChange={(e) => setSettings({ ...settings, work_min_hours: Number(e.target.value) })}
              />
            </Field>
            <Field label="Perros (min/día)">
              <input
                className="input"
                type="number"
                min={0}
                step={5}
                value={settings.dogs_minutes}
                onChange={(e) => setSettings({ ...settings, dogs_minutes: Number(e.target.value) })}
              />
            </Field>
            <Field label="Gym (min/día)">
              <input
                className="input"
                type="number"
                min={0}
                step={5}
                value={settings.gym_minutes}
                onChange={(e) => setSettings({ ...settings, gym_minutes: Number(e.target.value) })}
              />
            </Field>
            <Field label="Comida con Davinia (min)">
              <input
                className="input"
                type="number"
                min={0}
                step={5}
                value={settings.meal_minutes}
                onChange={(e) => setSettings({ ...settings, meal_minutes: Number(e.target.value) })}
              />
            </Field>
            <Field label="Inicio tarde con familia (HH:MM)">
              <input
                className="input"
                value={settings.family_start_evening}
                onChange={(e) => setSettings({ ...settings, family_start_evening: e.target.value })}
              />
            </Field>
            <Field label="Hora inicio perros (HH:MM)">
              <input
                className="input"
                value={settings.dogs_start}
                onChange={(e) => setSettings({ ...settings, dogs_start: e.target.value })}
              />
            </Field>
            <Field label="Dormir: inicio (HH:MM)">
              <input
                className="input"
                value={settings.sleep_start}
                onChange={(e) => setSettings({ ...settings, sleep_start: e.target.value })}
              />
            </Field>
            <Field label="Dormir: fin (HH:MM)">
              <input
                className="input"
                value={settings.sleep_end}
                onChange={(e) => setSettings({ ...settings, sleep_end: e.target.value })}
              />
            </Field>
          </div>

          <div className="mt-3 flex items-center gap-2">
            <button className="nido-cta" onClick={saveSchedulePrefs} type="button">
              Guardar
            </button>
            <div className="text-sm text-[hsl(var(--muted-foreground))]">{msg}</div>
          </div>
        </section>
      ) : null}

      {/* Carga rápida (para probar) */}
      {isAdmin ? (
        <section className="nido-summary nido-summary-glass">
          <div className="nido-eyebrow">Demo</div>
          <div className="mt-2 text-lg font-semibold tracking-tight text-[hsl(var(--foreground))]">
            Carga rápida para probar
          </div>
          <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">
            Rellena datos de ejemplo en este dispositivo: eventos del cole y tareas periódicas.
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-2">
            <button
              type="button"
              className="nido-cta secondary"
              onClick={() => {
                seedSchoolEvents(8);
                setMsg("Eventos del cole cargados (8 semanas). Ve a Semana.");
              }}
            >
              Cargar eventos cole
            </button>
            <button
              type="button"
              className="nido-cta secondary"
              onClick={() => {
                seedRecurringChecklists(7);
                setMsg("Tareas periódicas cargadas (7 días + domingo/semanales). Ve a Inicio.");
              }}
            >
              Cargar tareas periódicas
            </button>
          </div>

          <div className="mt-2 text-xs text-[hsl(var(--muted-foreground))]">
            Nota: ahora es localStorage. En una iteración lo pasamos a Supabase multiusuario.
          </div>
        </section>
      ) : null}

      {/* Next step */}
      {isAdmin ? (
        <section className="nido-summary nido-summary-glass">
          <div className="nido-eyebrow">Siguiente</div>
          <div className="mt-2 text-lg font-semibold tracking-tight text-[hsl(var(--foreground))]">
            Notificaciones (cuando quieras)
          </div>
          <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">
            Avisos tipo calendario: 1 día antes y 15 min antes. iPhone/PWA. (Lo planificamos en el siguiente bloque.)
          </div>
        </section>
      ) : null}
    </div>
  );
}

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="label">{label}</div>
      {hint ? <div className="text-[11px] text-[hsl(var(--muted-foreground))]">{hint}</div> : null}
      <div className={clsx(hint ? "mt-1" : "")}>{children}</div>
    </div>
  );
}
