"use client";

import { useMemo, useState } from "react";
import { categoryMeta } from "@/lib/colors";
import { upsertEventLocal } from "@/lib/eventsStore";
import { lsGet, lsSet } from "@/lib/localStore";
import type { ChecklistItem, ChecklistKey } from "@/lib/types";
import { addDays, addWeeks, format, nextDay, startOfDay } from "date-fns";
import type { Day } from "date-fns";

type Preview =
  | { kind: "none"; title: string; detail?: string }
  | { kind: "task"; title: string; detail: string; dateISO: string; listKey: ChecklistKey; text: string }
  | { kind: "event"; title: string; detail: string; occurrences: { title: string; startISO: string; endISO: string }[] };

function makeId(): string {
  return `id_${Math.random().toString(16).slice(2)}${Date.now().toString(16)}`;
}

function checklistStorageKey(dateISO: string, listKey: ChecklistKey): string {
  return `familiaCM:checklist:${dateISO}:${listKey}`;
}

function addChecklistItem(dateISO: string, listKey: ChecklistKey, text: string) {
  const key = checklistStorageKey(dateISO, listKey);
  const existing = lsGet<ChecklistItem[]>(key, []);
  const norm = text.trim().toLowerCase();
  if (!norm) return;
  if (existing.some((x) => x.text.trim().toLowerCase() === norm)) return;
  lsSet(key, [...existing, { id: makeId(), text, done: false }]);
}

function dt(dateISO: string, hhmm: string): Date {
  const [h, m] = hhmm.split(":").map((x) => Number(x));
  const base = startOfDay(new Date(`${dateISO}T12:00:00`));
  base.setHours(h, m, 0, 0);
  return base;
}

function parseWeekdayToken(s: string): Day | null {
  const t = s.toLowerCase().trim();
  const map: Record<string, Day> = {
    lunes: 1,
    martes: 2,
    miercoles: 3,
    miércoles: 3,
    jueves: 4,
    viernes: 5,
    sabado: 6,
    sábado: 6,
    domingo: 0,
  };
  return map[t] ?? null;
}
function inferListKey(text: string): ChecklistKey {
  const t = text.toLowerCase();
  if (t.includes("trabajo") || t.includes("informe") || t.includes("datos")) return "work";
  if (t.includes("gym") || t.includes("perros") || t.includes("carlos")) return "carlos";
  return "home_family";
}

const EXAMPLES: { label: string; command: string; pill: string }[] = [
  { label: "Evento familia", command: "Evento (Familia) viernes 17:10 Kids&Us Lleida", pill: categoryMeta.family.pillClass },
  { label: "Tarea trabajo", command: "Tarea (Trabajo) hoy 10:00 Revisar informe datos", pill: categoryMeta.work.pillClass },
  { label: "Tarea casa", command: "Tarea (Casa) hoy 21:00 Limpiar cocina", pill: categoryMeta.home.pillClass },
  { label: "Recurrencia", command: "Evento (Familia) todos los domingos 09:00 Cambiar sábanas", pill: categoryMeta.family.pillClass },
];

export default function CommandsClient() {
  const legend = useMemo(() => Object.values(categoryMeta), []);
  const [text, setText] = useState("");
  const [preview, setPreview] = useState<Preview>({
    kind: "none",
    title: "Escribe o dicta un comando",
    detail: "Ejemplos abajo. Se creará una vista previa antes de guardar.",
  });

  const buildPreview = (raw: string): Preview => {
    const input = raw.trim();
    if (!input) return { kind: "none", title: "Escribe o dicta un comando" };

    const lower = input.toLowerCase();
    const isTask = lower.startsWith("tarea") || lower.includes("tarea (");
    const isEvent = lower.startsWith("evento") || lower.includes("evento (");

    // Fecha
    let date = new Date();
    if (lower.includes("mañana")) date = addDays(new Date(), 1);

    // Día de semana
    for (const tok of ["lunes","martes","miércoles","miercoles","jueves","viernes","sábado","sabado","domingo"]) {
      if (lower.includes(tok)) {
        const wd = parseWeekdayToken(tok);
        if (wd !== null) date = nextDay(new Date(), wd);
      }
    }

    const dateISO = format(date, "yyyy-MM-dd");

    // Hora HH:MM
    const timeMatch = input.match(/\b([01]?\d|2[0-3]):([0-5]\d)\b/);
    const time = timeMatch ? `${timeMatch[1].padStart(2, "0")}:${timeMatch[2]}` : "10:00";

    // Recurrencia simple "todos los X"
    const recurMatch = lower.match(/todos\s+los\s+(lunes|martes|mi[eé]rcoles|jueves|viernes|s[áa]bado|domingo)/);
    const recurring = Boolean(recurMatch);

    // Título limpio: quitar prefijos
    const cleaned = input
      .replace(/^tarea\s*/i, "")
      .replace(/^evento\s*/i, "")
      .replace(/\(.*?\)/g, "")
      .replace(/\b(hoy|mañana|lunes|martes|mi[eé]rcoles|jueves|viernes|s[áa]bado|domingo)\b/gi, "")
      .replace(/\b\d{1,2}:\d{2}\b/g, "")
      .replace(/todos\s+los\s+\w+/gi, "")
      .trim();

    if (!isTask && !isEvent) {
      return {
        kind: "none",
        title: "Comando no reconocido",
        detail: "Empieza por 'Tarea' o 'Evento'. Ej: Tarea (Casa) hoy 21:00 Limpiar cocina",
      };
    }

    if (isTask) {
      const listKey = inferListKey(lower);
      const taskText = `${time} · ${cleaned || "(sin título)"}`;
      return {
        kind: "task",
        title: "Vista previa · Tarea",
        detail: `${dateISO} · ${listKey.toUpperCase()} · ${taskText}`,
        dateISO,
        listKey,
        text: taskText,
      };
    }

    // Event
    const occ: { title: string; startISO: string; endISO: string }[] = [];
    if (recurring && recurMatch) {
      const wd = parseWeekdayToken(recurMatch[1]);
      if (wd === null) {
        return { kind: "none", title: "No pude interpretar la recurrencia" };
      }
      for (let w = 0; w < 12; w++) {
        const d = nextDay(addWeeks(new Date(), w), wd);
        const iso = format(d, "yyyy-MM-dd");
        const start = dt(iso, time);
        const end = dt(iso, time);
        end.setMinutes(end.getMinutes() + 60);
        occ.push({ title: cleaned || "(sin título)", startISO: start.toISOString(), endISO: end.toISOString() });
      }
    } else {
      const start = dt(dateISO, time);
      const end = dt(dateISO, time);
      end.setMinutes(end.getMinutes() + 60);
      occ.push({ title: cleaned || "(sin título)", startISO: start.toISOString(), endISO: end.toISOString() });
    }

    return {
      kind: "event",
      title: "Vista previa · Evento",
      detail: `${occ.length} ocurrencia(s) · ${time} · ${cleaned || "(sin título)"}`,
      occurrences: occ,
    };
  };

  const onPreview = () => setPreview(buildPreview(text));

  const onApply = () => {
    if (preview.kind === "task") {
      addChecklistItem(preview.dateISO, preview.listKey, preview.text);
      setPreview({ kind: "none", title: "Tarea creada", detail: preview.detail });
      setText("");
      return;
    }
    if (preview.kind === "event") {
      for (const o of preview.occurrences) {
        upsertEventLocal({ title: o.title, startISO: o.startISO, endISO: o.endISO });
      }
      setPreview({ kind: "none", title: "Evento creado", detail: preview.detail });
      setText("");
    }
  };

  return (
    <div className="space-y-4">
      <div className="card p-4">
        <div className="font-semibold">Leyenda (colores por categoría)</div>
        <div className="mt-3 flex flex-wrap gap-2">
          {legend.map((m) => (
            <span key={m.key} className={`inline-flex items-center gap-2 rounded-full border px-2 py-1 text-sm ${m.pillClass}`}>
              <span className="text-base leading-none">{m.icon}</span>
              <span className="font-medium">{m.label}</span>
            </span>
          ))}
        </div>
      </div>

      <div className="card p-4">
        <div className="font-semibold">Comando rápido</div>
        <div className="mt-2 text-sm text-slate-600">
          Escribe o dicta (micrófono del teclado iOS) y pulsa “Vista previa”.
        </div>

        <div className="mt-3 flex flex-col gap-2 md:flex-row">
          <input
            className="notion-input flex-1"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Ej: Evento (Familia) viernes 17:10 Kids&Us Lleida"
          />
          <button className="notion-btn" onClick={onPreview}>Vista previa</button>
        </div>

        <div className="mt-3 rounded-xl border border-slate-200 bg-white p-3">
          <div className="text-sm font-semibold">{preview.title}</div>
          {preview.detail ? <div className="mt-1 text-sm text-slate-700">{preview.detail}</div> : null}
          <div className="mt-3 flex items-center gap-2">
            <button className="notion-btn" onClick={() => setPreview(buildPreview(text))}>Refrescar</button>
            <button className="notion-btn" onClick={onApply} disabled={preview.kind === "none"}>
              Crear
            </button>
          </div>
        </div>

        <div className="mt-4">
          <div className="text-sm font-semibold">Ejemplos (tap para copiar)</div>
          <div className="mt-2 grid gap-2 md:grid-cols-2">
            {EXAMPLES.map((ex) => (
              <button
                key={ex.command}
                className={`rounded-xl border px-3 py-2 text-left ${ex.pill}`}
                onClick={() => {
                  setText(ex.command);
                  setPreview(buildPreview(ex.command));
                }}
              >
                <div className="text-xs opacity-80">{ex.label}</div>
                <div className="mt-1 text-sm font-medium">{ex.command}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
