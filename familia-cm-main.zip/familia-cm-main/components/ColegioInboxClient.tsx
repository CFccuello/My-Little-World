"use client";

import { useEffect, useMemo, useState } from "react";
import clsx from "clsx";
import { listInbox, archiveItem, createAction, type SchoolInboxItem } from "@/lib/schoolInbox";

function fmt(iso?: string | null) {
  if (!iso) return "—";
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return "—";
  return new Date(t).toLocaleString();
}

function short(s?: string | null, n = 160) {
  const x = (s ?? "").trim();
  if (x.length <= n) return x;
  return x.slice(0, n - 1) + "…";
}

export default function ColegioInboxClient() {
  const [items, setItems] = useState<SchoolInboxItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [toast, setToast] = useState<string>("");

  async function load() {
    setLoading(true);
    try {
      const data = await listInbox(80);
      setItems(data);
    } catch (e: any) {
      setToast(`Error cargando: ${e?.message ?? "unknown"}`);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  const grouped = useMemo(() => {
    // agrupamos por día (solo visual)
    const groups: Record<string, SchoolInboxItem[]> = {};
    for (const it of items) {
      const d = (it.source_message_date ?? it.created_at).slice(0, 10);
      groups[d] = groups[d] ?? [];
      groups[d].push(it);
    }
    return Object.entries(groups).sort((a, b) => (a[0] < b[0] ? 1 : -1));
  }, [items]);

  return (
    <div className="space-y-4">
      <div className="card p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-sm font-semibold text-[hsl(var(--foreground))]">Inbox del cole</div>
            <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">
              Aquí entra lo que reenvíes al “NIDO TUNNEL”. Luego lo conviertes en acción.
            </div>
          </div>

          <button className="btn" onClick={() => void load()} disabled={loading}>
            {loading ? "Cargando…" : "Refrescar"}
          </button>
        </div>

        {toast ? <div className="mt-3 text-sm text-amber-700">{toast}</div> : null}
      </div>

      {loading ? (
        <div className="card p-4 text-sm text-[hsl(var(--muted-foreground))]">Cargando mensajes…</div>
      ) : items.length === 0 ? (
        <div className="card p-4 text-sm text-[hsl(var(--muted-foreground))]">
          Aún no hay mensajes. Reenvía uno al grupo “NIDO TUNNEL” y aparecerá aquí.
        </div>
      ) : (
        grouped.map(([day, dayItems]) => (
          <div key={day} className="space-y-2">
            <div className="text-xs text-[hsl(var(--muted-foreground))] uppercase tracking-wider">{day}</div>

            {dayItems.map((it) => (
              <div key={it.id} className="card p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-[hsl(var(--foreground))] truncate">
                      {it.source_chat_title ?? "Cole"} · {it.from_name ?? "—"}
                    </div>
                    <div className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">
                      {fmt(it.source_message_date)} · importancia: {it.parsed_importance}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      className={clsx("btn", busyId === it.id && "opacity-60 cursor-not-allowed")}
                      disabled={busyId === it.id}
                      onClick={async () => {
                        setBusyId(it.id);
                        try {
                          await archiveItem(it.id);
                          setToast("Archivado.");
                          // Reload lightweight: remove from list locally
                          setItems((prev) => prev.filter((x) => x.id !== it.id));
                        } catch (e: any) {
                          setToast(e?.message ?? "Error archivando");
                        } finally {
                          setBusyId(null);
                        }
                      }}
                    >
                      Archivar
                    </button>
                  </div>
                </div>

                <div className="mt-3 text-sm text-[hsl(var(--foreground))] whitespace-pre-wrap">
                  {short(it.text_raw, 480) || "—"}
                </div>

                {Array.isArray(it.attachments) && it.attachments.length > 0 ? (
                  <div className="mt-3 text-xs text-[hsl(var(--muted-foreground))]">
                    Adjuntos: {it.attachments.length}
                  </div>
                ) : null}

                <div className="mt-4 flex flex-wrap gap-2">
                  <button
                    className={clsx("btn-primary", busyId === it.id && "opacity-60 cursor-not-allowed")}
                    disabled={busyId === it.id}
                    onClick={async () => {
                      setBusyId(it.id);
                      try {
                        await createAction({
                          inbox_id: it.id,
                          type: "task",
                          title: it.parsed_summary ?? it.text_raw?.slice(0, 80) ?? "Tarea (cole)",
                          details: it.text_raw ?? null,
                          importance: it.parsed_importance ?? "normal",
                          status: "suggested",
                        });
                        setToast("Acción creada (tarea).");
                      } catch (e: any) {
                        setToast(e?.message ?? "Error creando acción");
                      } finally {
                        setBusyId(null);
                      }
                    }}
                  >
                    Crear tarea
                  </button>

                  <button
                    className={clsx("btn", busyId === it.id && "opacity-60 cursor-not-allowed")}
                    disabled={busyId === it.id}
                    onClick={async () => {
                      setBusyId(it.id);
                      try {
                        await createAction({
                          inbox_id: it.id,
                          type: "event",
                          title: it.parsed_summary ?? it.text_raw?.slice(0, 80) ?? "Evento (cole)",
                          details: it.text_raw ?? null,
                          importance: it.parsed_importance ?? "normal",
                          status: "suggested",
                        });
                        setToast("Acción creada (evento).");
                      } catch (e: any) {
                        setToast(e?.message ?? "Error creando acción");
                      } finally {
                        setBusyId(null);
                      }
                    }}
                  >
                    Crear evento
                  </button>
                </div>
              </div>
            ))}
          </div>
        ))
      )}
    </div>
  );
}
