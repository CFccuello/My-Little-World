import type { ScheduleBlock } from "@/lib/types";
import { categoryMeta, dotClassFor } from "@/lib/colors";

export default function ScheduleTable({ blocks }: { blocks: ScheduleBlock[] }) {
  return (
    <div className="card p-4">
      <div className="font-semibold">Agenda (sin solapes)</div>
      <div className="mt-3 space-y-2">
        {blocks.map((b) => (
          <div key={b.id} className="flex items-start gap-3">
            <div className="pt-0.5 flex items-center gap-2">
              <span className={"inline-block h-2.5 w-2.5 rounded-full " + dotClassFor(b.color)} />
              <span className="text-base leading-none">{categoryMeta[b.color].icon}</span>
            </div>
            <div className="flex-1">
              <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                <div className="font-mono text-sm text-slate-600">{b.start}–{b.end}</div>
                <div className="font-medium">{b.label}</div>
              </div>
              {b.notes ? <div className="text-sm text-slate-600 mt-1">{b.notes}</div> : null}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
