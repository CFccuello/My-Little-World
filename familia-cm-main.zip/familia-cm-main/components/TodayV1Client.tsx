"use client";

import Link from "next/link";
import clsx from "clsx";
import { useEffect, useMemo, useState } from "react";
import { addDays, differenceInCalendarDays, format, parseISO } from "date-fns";

import BirdStamp from "@/components/BirdStamp";
import Routines2TodayCard from "@/components/Routines2TodayCard";
import { getEventsLocal } from "@/lib/eventsStore";
import { lsGet } from "@/lib/localStore";
import type { CalendarEvent, ChecklistItem } from "@/lib/types";
import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";

type EventView = CalendarEvent & {
  _date: Date;
  _diff: number;
};

// Summarise a list of checklist items into useful metrics.
function summarise(items: ChecklistItem[]) {
  const total = items.length;
  const done = items.filter((i) => i.done).length;
  const undone = items.filter((i) => !i.done);
  return { total, done, undone };
}

const DAYS_ES = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"] as const;
const MONTHS_ES = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"] as const;

function formatShortEs(d: Date) {
  const day = DAYS_ES[d.getDay()] ?? "";
  const dd = d.getDate();
  const mm = MONTHS_ES[d.getMonth()] ?? "";
  return `${day} ${dd} ${mm}`;
}

function labelForDiff(diff: number, d: Date) {
  if (diff === 0) return "Hoy";
  if (diff === 1) return "Mañana";
  return formatShortEs(d);
}

/**
 * V1 "Cole badge":
 * - We count messages for today in school_inbox_items
 * - Because the current schema doesn't have a status column.
 * Later we can add `status` and use real "new/processed".
 */
async function countSchoolInboxToday(dateISO: string): Promise<number> {
  if (!isSupabaseConfigured) return 0;

  // Today range in UTC-ish ISO boundaries.
  // We use dateISO (local) but query timestamptz; V1 it's OK to use >= dateISO 00:00 local-ish.
  const start = `${dateISO}T00:00:00`;
  const end = `${dateISO}T23:59:59`;

  // Prefer source_message_date; if null, created_at still works but this is a V1 approximation.
  // We do two counts (OR) isn't supported directly in a simple count head query,
  // so we fetch IDs with a small limit and count in memory if needed.
  const { data, error } = await supabase
    .from("school_inbox_items")
    .select("id,source_message_date,created_at")
    .or(`source_message_date.gte.${start},created_at.gte.${start}`)
    .limit(200);

  if (error) return 0;

  const startT = Date.parse(start);
  const endT = Date.parse(end);

  const inToday = (data ?? []).filter((r: any) => {
    const t = Date.parse(r.source_message_date ?? r.created_at ?? "");
    if (Number.isNaN(t)) return false;
    return t >= startT && t <= endT;
  });

  return inToday.length;
}

export default function TodayV1Client() {
  const dateISO = useMemo(() => format(new Date(), "yyyy-MM-dd"), []);
  const [coleCount, setColeCount] = useState<number>(0);

  // Cole: load count for today (best-effort)
  useEffect(() => {
    let mounted = true;

    void (async () => {
      try {
        const n = await countSchoolInboxToday(dateISO);
        if (mounted) setColeCount(n);
      } catch {
        // ignore
      }
    })();

    return () => {
      mounted = false;
    };
  }, [dateISO]);

  // Load checklists from localStorage. If a list doesn't exist yet,
  // lsGet returns an empty array.
  const lists = useMemo(() => {
    return {
      carlos: summarise(lsGet<ChecklistItem[]>(`familiaCM:checklist:${dateISO}:carlos`, [])),
      home: summarise(lsGet<ChecklistItem[]>(`familiaCM:checklist:${dateISO}:home_family`, [])),
    };
  }, [dateISO]);

  // Build a flat list of all undone tasks across lists.
  // IMPORTANT: Davinia's “Hoy” does not show work.
  const minimalTasks = useMemo(() => {
    const all = [...lists.carlos.undone, ...lists.home.undone];
    return all.slice(0, 3).map((item) => item.text);
  }, [lists]);

  // Calendar: upcoming 7 days summary (tomorrow highlighted)
  // NOTE: Explicit typing avoids TS inferring `never[]` when returning `[]`.
  const upcoming = useMemo<EventView[]>(() => {
    try {
      const now = new Date();
      const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const end = addDays(start, 7);

      const all = getEventsLocal();
      const filtered = all
        .map((e): EventView => {
          const d = parseISO(e.startISO);
          return {
            ...e,
            _date: d,
            _diff: differenceInCalendarDays(d, start),
          };
        })
        .filter((e) => e._date >= start && e._date <= end)
        .sort((a, b) => a._date.getTime() - b._date.getTime());

      return filtered;
    } catch {
      return [];
    }
  }, [dateISO]);

  const carlosDone = lists.carlos.done;
  const homeDone = lists.home.done;

  const tomorrowFirst = useMemo<EventView[]>(() => {
    const tomorrow = upcoming.filter((e) => e._diff === 1);
    const rest = upcoming.filter((e) => e._diff !== 1);
    return [...tomorrow, ...rest];
  }, [upcoming]);

  const upcomingToShow = tomorrowFirst.slice(0, 4);

  return (
    <div className="space-y-4">
      {/* Hero */}
      <div className={clsx("nido-hero nido-hero-glass", "relative overflow-hidden")}>
        <BirdStamp className="absolute -right-4 -top-5" size="xl" />

        <div className="nido-eyebrow">Hoy</div>
        <div className="mt-2 text-2xl font-semibold tracking-tight text-[hsl(var(--foreground))]">
          Un paso. Con eso vale.
        </div>
        <div className="mt-2 text-sm text-[hsl(var(--muted-foreground))]">Casa y familia. Sin ruido.</div>

        <div className="mt-4 flex flex-wrap gap-2">
          <span className="nido-badge">🐥 Sin juicio</span>
          <span className="nido-badge">Lo importante &gt; lo perfecto</span>
        </div>
      </div>

      {/* COLE (nuevo bloque, compacto) */}
      <div className={clsx("nido-summary nido-summary-glass")}>
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="nido-eyebrow">Cole</div>
            <div className="mt-2 text-base font-semibold text-[hsl(var(--foreground))]">
              Inbox del cole
            </div>
            <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">
              {coleCount > 0 ? `${coleCount} mensaje(s) hoy` : "De momento, nada nuevo."}
            </div>
          </div>

          <Link href="/colegio" className="nido-badge no-underline">
            Abrir
          </Link>
        </div>

        <div className="mt-3 text-xs text-[hsl(var(--muted-foreground))]">
          Tip: reenvía al grupo “NIDO TUNNEL” y aparece aquí.
        </div>
      </div>

      {/* Lo mínimo */}
      <div className={clsx("nido-summary nido-summary-glass")}>
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="nido-eyebrow">Lo mínimo</div>
            <div className="mt-2 text-base font-semibold text-[hsl(var(--foreground))]">
              Si solo haces una cosa, que sea esta.
            </div>
          </div>
          <div className="nido-badge">0–3</div>
        </div>

        <div className="mt-3">
          {minimalTasks.length > 0 ? (
            <ul className="space-y-2">
              {minimalTasks.map((t, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-[hsl(var(--foreground))]">
                  <span className="mt-0.5 text-[hsl(var(--muted-foreground))]">•</span>
                  <span className="min-w-0">{t}</span>
                </li>
              ))}
            </ul>
          ) : (
            <div className="text-sm text-[hsl(var(--muted-foreground))]">Hoy está en calma. Los pollitos descansan.</div>
          )}
        </div>
      </div>

      {/* Próximos 7 días */}
      <div className={clsx("nido-summary nido-summary-glass")}>
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="nido-eyebrow">Próximos</div>
            <div className="mt-2 text-base font-semibold text-[hsl(var(--foreground))]">7 días por delante</div>
          </div>

          <Link href="/calendar" className="nido-badge no-underline">
            Ver semana
          </Link>
        </div>

        <div className="mt-3 space-y-2">
          {upcomingToShow.length > 0 ? (
            upcomingToShow.map((e) => (
              <div
                key={e.id}
                className={clsx(
                  "flex items-center justify-between gap-3 rounded-lg border border-[hsl(var(--border))] px-3 py-2",
                  "bg-[hsl(var(--card)/0.35)]",
                  e._diff === 1 && "ring-1 ring-[hsl(var(--primary)/0.35)]"
                )}
              >
                <div className="min-w-0">
                  <div
                    className={clsx(
                      "text-xs font-semibold",
                      e._diff === 1 ? "text-[hsl(var(--primary-foreground))]" : "text-[hsl(var(--muted-foreground))]"
                    )}
                    style={e._diff === 1 ? { filter: "none" } : undefined}
                  >
                    {labelForDiff(e._diff, e._date)}
                  </div>
                  <div className="text-sm font-semibold text-[hsl(var(--foreground))] truncate">{e.title}</div>
                </div>

                <div className="text-xs text-[hsl(var(--muted-foreground))] whitespace-nowrap">
                  {format(e._date, "HH:mm")}
                </div>
              </div>
            ))
          ) : (
            <div className="text-sm text-[hsl(var(--muted-foreground))]">
              Semana tranquila. Si entra algo nuevo, tira hacia abajo para refrescar.
            </div>
          )}
        </div>
      </div>

      {/* Rutinas 2.0 (compacto) */}
      <div className={clsx("nido-summary nido-summary-glass")}>
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="nido-eyebrow">Rutinas</div>
            <div className="mt-2 text-base font-semibold text-[hsl(var(--foreground))]">Check rápido, sin drama</div>
          </div>
          <div className="nido-badge">🪺</div>
        </div>
        <div className="mt-3">
          <Routines2TodayCard dateISO={dateISO} />
        </div>
      </div>

      {/* Hecho hoy */}
      <div className={clsx("nido-summary nido-summary-glass")}>
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="nido-eyebrow">Hecho hoy</div>
            <div className="mt-2 text-base font-semibold text-[hsl(var(--foreground))]">Visible y real</div>
          </div>
        </div>
        <div className="mt-3 flex items-center gap-2 text-sm text-[hsl(var(--muted-foreground))]">
          <span className="nido-badge">Carlos {carlosDone}</span>
          <span className="nido-badge">Davinia {homeDone}</span>
        </div>
      </div>
    </div>
  );
}
