"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import clsx from "clsx";
import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";
import { useEffect, useState } from "react";

const items = [
  { href: "/today", label: "Hoy" },
  { href: "/routines", label: "Rutinas" },
  { href: "/tasks", label: "Tareas" },

  // NUEVO: familia + módulos clave
  { href: "/familia", label: "Familia" },
  { href: "/electricidad", label: "Electricidad" },
  { href: "/comida", label: "Comida" },
  { href: "/medicacion", label: "Medicación" },
  { href: "/lavavajillas", label: "Lavavajillas" },
  { href: "/inspiracion", label: "Inspiración" },

  // existentes
  { href: "/docs", label: "Docs" },
  { href: "/finance", label: "Finanzas" },
  { href: "/settings", label: "Ajustes" },
];

export default function Nav() {
  const pathname = usePathname();
  const [email, setEmail] = useState<string | null>(null);

  useEffect(() => {
    if (!isSupabaseConfigured) return;
    supabase.auth.getSession().then(({ data }) => {
      setEmail(data.session?.user.email ?? null);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setEmail(session?.user.email ?? null);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  return (
    <div className="flex items-center gap-2">
      <nav className="hidden md:flex items-center gap-1 flex-wrap">
        {items.map((it) => {
          const active = pathname === it.href || pathname?.startsWith(it.href + "/");
          return (
            <Link
              key={it.href}
              href={it.href}
              className={clsx(
                "nido-toplink",
                active && "nido-toplink-active"
              )}
            >
              {it.label}
            </Link>
          );
        })}
      </nav>

      <div className="flex items-center gap-2">
        {!isSupabaseConfigured ? (
          <div className="nido-badge">Demo</div>
        ) : email ? (
          <>
            <div className="hidden sm:block text-sm text-[hsl(var(--muted-foreground))] max-w-[220px] truncate">
              {email}
            </div>
            <button
              className="btn text-sm"
              onClick={async () => {
                await supabase.auth.signOut();
                window.location.href = "/login";
              }}
            >
              Salir
            </button>
          </>
        ) : (
          <Link className="btn text-sm no-underline" href="/login">
            Login
          </Link>
        )}
      </div>
    </div>
  );
}
