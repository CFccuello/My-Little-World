"use client";

import clsx from "clsx";
import { useEffect, useMemo, useState } from "react";
import {
  checkComedorMonzon,
  loadComedorMonzonState,
  onComedorMonzonUpdate,
  type MonzonState,
} from "@/lib/comedorMonzon3";

function fmt(iso?: string) {
  if (!iso) return "—";
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return "—";
  return new Date(t).toLocaleString();
}

export default function ComedorMonzonCard() {
  const [state, setState] = useState<MonzonState>(() => loadComedorMonzonState());
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    // initial
    setState(loadComedorMonzonState());
    const off = onComedorMonzonUpdate(() => {
      setState(loadComedorMonzonState());
    });
    return () => off();
  }, []);

  const status = useMemo(() => {
    if (!state.lastCheckISO) return "Aún no se ha comprobado.";
    if (!state.pdfUrl) return "No se encontró un PDF todavía.";
    return "PDF detectado.";
  }, [state.lastCheckISO, state.pdfUrl]);

  const statusClass = useMemo(() => {
    if (!state.lastCheckISO) return "nido-callout nido-callout-amber";
    if (!state.pdfUrl) return "nido-callout nido-callout-amber";
    return "nido-callout";
  }, [state.lastCheckISO, state.pdfUrl]);

  return (
    <div className={clsx("p-4", statusClass)}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="nido-eyebrow">Comedor · Monzón 3</div>
          <div className="mt-2 text-base font-semibold text-[hsl(var(--foreground))]">Menú mensual (PDF)</div>
          <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">
            Greta + Máximo. Botón rápido para abrir el PDF sin navegar.
          </div>
        </div>
        <div className="text-3xl leading-none" aria-hidden="true">
          🧾
        </div>
      </div>

      <div className="mt-3 text-sm text-[hsl(var(--muted-foreground))]">{status}</div>

      <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-[hsl(var(--muted-foreground))]">
        <div>
          <div className="font-semibold text-[hsl(var(--foreground))]">Última comprobación</div>
          <div>{fmt(state.lastCheckISO)}</div>
        </div>
        <div>
          <div className="font-semibold text-[hsl(var(--foreground))]">Último OK</div>
          <div>{fmt(state.lastOkISO)}</div>
        </div>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {state.pdfUrl ? (
          <a
            className="btn-primary no-underline"
            href={state.pdfUrl}
            target="_blank"
            rel="noreferrer"
          >
            Ver el menú (PDF)
          </a>
        ) : (
          <button className="btn-primary opacity-60 cursor-not-allowed" disabled>
            Ver el menú (PDF)
          </button>
        )}

        <button
          className={clsx("btn", busy && "opacity-60 cursor-not-allowed")}
          disabled={busy}
          onClick={async () => {
            try {
              setBusy(true);
              await checkComedorMonzon();
            } finally {
              setBusy(false);
            }
          }}
        >
          {busy ? "Comprobando…" : "Comprobar ahora"}
        </button>
      </div>

      <div className="mt-3 text-xs text-[hsl(var(--muted-foreground))]">
        Tip: el cole suele publicar el nuevo PDF entre el día 28 y el 4.
      </div>
    </div>
  );
}
