import { legend } from "@/lib/colors";

export default function Legend() {
  return (
    <div className="card p-4">
      <div className="font-semibold">Leyenda</div>
      <div className="mt-3 flex flex-wrap gap-2">
        {legend.map((it) => (
          <span
            key={it.key}
            className={`inline-flex items-center gap-2 rounded-full border px-3 py-1 text-sm ${it.pillClass}`}
            title={it.label}
          >
            <span className="text-base leading-none">{it.icon}</span>
            <span className="font-medium">{it.label}</span>
          </span>
        ))}
      </div>
    </div>
  );
}
