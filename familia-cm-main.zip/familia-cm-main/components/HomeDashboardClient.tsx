"use client";

import DayTimeline from "@/components/DayTimeline";
import WeekEventsWidget from "@/components/WeekEventsWidget";
import ChecklistCard from "@/components/ChecklistCard";
import Totals from "@/components/Totals";
import Legend from "@/components/Legend";
import { buildDefaultSchedule, defaultSettings, totalsByColor } from "@/lib/schedule";
import { lsGet } from "@/lib/localStore";
import type { Settings } from "@/lib/types";
import { format } from "date-fns";
import { useEffect, useMemo, useState } from "react";
import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";

export default function HomeDashboardClient() {
  const dateISO = format(new Date(), "yyyy-MM-dd");
  const [settings, setSettings] = useState<Settings>(defaultSettings());

  useEffect(() => {
    if (!isSupabaseConfigured) {
      setSettings(lsGet("familiaCM:settings", defaultSettings()));
      return;
    }
    const run = async () => {
      const { data: u } = await supabase.auth.getUser();
      const uid = u.user?.id;
      if (!uid) return;
      const { data } = await supabase.from("settings").select("*").eq("id", uid).single();
      if (data) setSettings(data as any);
      else setSettings((p) => ({ ...p, id: uid }));
    };
    run();
  }, []);

  const built = useMemo(() => buildDefaultSchedule(settings, dateISO), [settings, dateISO]);
  const totals = useMemo(() => totalsByColor(built.blocks), [built.blocks]);

  return (
    <div className="space-y-4">
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <DayTimeline blocks={built.blocks} title="Horario del día (timeline)" />
        </div>
        <div className="space-y-4">
          <WeekEventsWidget />
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <ChecklistCard dateISO={dateISO} listKey="work" title="Checklist Trabajo" />
        <ChecklistCard dateISO={dateISO} listKey="carlos" title="Checklist Carlos" />
        <ChecklistCard dateISO={dateISO} listKey="home_family" title="Checklist Casa & Familia" />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Totals totals={totals} />
        <div className="space-y-4">
          <Legend />
          {built.warnings.length ? (
            <div className="card p-4 border border-amber-200 bg-amber-50">
              <div className="font-semibold">Avisos</div>
              <ul className="mt-2 text-sm text-amber-900 list-disc pl-5 space-y-1">
                {built.warnings.map((w, i) => <li key={i}>{w}</li>)}
              </ul>
            </div>
          ) : null}
          <div className="card p-4">
            <div className="font-semibold">Reglas rápidas</div>
            <div className="mt-2 text-sm text-slate-700 space-y-1">
              <div><b>Trabajo mínimo:</b> {Number(settings.work_min_hours)}h</div>
              <div><b>Perros:</b> {settings.dogs_minutes} min · <b>Gym:</b> {settings.gym_minutes} min</div>
              <div><b>Comida:</b> {settings.meal_minutes} min · <b>Familia desde:</b> {settings.family_start_evening}</div>
              <div><b>Sueño:</b> {settings.sleep_start} → {settings.sleep_end}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
