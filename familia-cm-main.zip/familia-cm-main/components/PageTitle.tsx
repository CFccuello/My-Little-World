export default function PageTitle({
  icon,
  title,
  subtitle
}: {
  icon: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="nido-hero">
      <div className="flex items-center gap-3">
        <div className="text-3xl leading-none">{icon}</div>
        <div>
          <h1 className="text-3xl font-semibold tracking-tight text-[hsl(var(--foreground))]">{title}</h1>
          {subtitle ? (
            <p className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">{subtitle}</p>
          ) : null}
        </div>
      </div>
    </div>
  );
}
