"use client";

import clsx from "clsx";
import { useEffect, useMemo, useState } from "react";
import { getBirdOfDay, isoToday, markBirdSeen, shouldShowBirdOverlay } from "@/lib/birdOfDay";

type Props = {
  enabled?: boolean;
};

/**
 * V1.2 — Onboarding “Ave del día”.
 *
 * - Shows 1–2s on first entry and once per day (config via shouldShowBirdOverlay).
 * - Stores: last_seen_date + ave_id in localStorage.
 * - Tap to dismiss.
 */
export default function BirdOfDayOverlay({ enabled = true }: Props) {
  const [open, setOpen] = useState(false);
  const [closing, setClosing] = useState(false);

  const dateISO = useMemo(() => isoToday(), []);
  const bird = useMemo(() => getBirdOfDay(dateISO), [dateISO]);

  useEffect(() => {
    if (!enabled) return;
    if (typeof window === "undefined") return;

    if (!shouldShowBirdOverlay(dateISO)) return;

    // Mark as seen immediately to avoid double-show on fast reloads.
    markBirdSeen(dateISO, bird.id);

    setOpen(true);
    setClosing(false);

    const t1 = window.setTimeout(() => setClosing(true), 1150);
    const t2 = window.setTimeout(() => setOpen(false), 1450);
    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
    };
  }, [enabled, dateISO, bird.id]);

  if (!open) return null;

  return (
    <div
      className={clsx(
        "fixed inset-0 z-[70]",
        "flex items-start justify-center",
        "px-4",
        closing ? "opacity-0" : "opacity-100"
      )}
      style={{
        paddingTop: "calc(env(safe-area-inset-top) + 18px)",
        transition: "opacity 220ms",
      }}
      role="dialog"
      aria-label="Ave del día"
      onClick={() => {
        setClosing(true);
        window.setTimeout(() => setOpen(false), 180);
      }}
    >
      <div
        className={clsx(
          "w-full max-w-sm",
          "rounded-3xl border",
          "bg-white/90 backdrop-blur",
          "shadow-sm",
          "px-4 py-4"
        )}
      >
        <div className="flex items-center gap-3">
          <div className="text-3xl" aria-hidden="true">
            {bird.emoji}
          </div>
          <div className="flex-1">
            <div className="text-xs uppercase tracking-wide text-slate-500">Ave del día</div>
            <div className="text-base font-semibold text-slate-900">{bird.name}</div>
            <div className="mt-0.5 text-sm text-slate-600">{bird.note}</div>
          </div>
        </div>

        <div className="mt-3 text-xs text-slate-500">
          Toca para cerrar.
        </div>
      </div>
    </div>
  );
}
