"use client";

import type { ScheduleBlock } from "@/lib/types";
import { categoryMeta, dotClassFor } from "@/lib/colors";
import { useEffect, useState } from "react";

function toMinutes(hhmm: string): number {
  if (hhmm === "24:00") return 24 * 60;
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + m;
}

export default function DayTimeline({ blocks, title = "Horario del día" }: { blocks: ScheduleBlock[]; title?: string }) {
  const [nowMin, setNowMin] = useState(() => {
    const d = new Date();
    return d.getHours() * 60 + d.getMinutes();
  });

  useEffect(() => {
    const id = window.setInterval(() => {
      const d = new Date();
      setNowMin(d.getHours() * 60 + d.getMinutes());
    }, 30_000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <div className="card p-4">
      <div className="font-semibold">{title}</div>
      <div className="mt-3 space-y-2">
        {blocks.map((b) => {
          const start = toMinutes(b.start);
          const end = toMinutes(b.end);
          const isPast = end <= nowMin;
          const isCurrent = start <= nowMin && nowMin < end;
          const meta = categoryMeta[b.color];

          return (
            <div
              key={b.id}
              className={
                "flex items-start gap-3 rounded-lg border px-3 py-2 " +
                (isCurrent
                  ? "border-slate-400 bg-white"
                  : "border-slate-200 bg-white") +
                (isPast ? " opacity-60" : "")
              }
            >
              <div className="pt-0.5 flex items-center gap-2">
                <span className={"inline-block h-2.5 w-2.5 rounded-full " + dotClassFor(b.color)} />
                <span className={"text-base leading-none" + (isPast ? " grayscale" : "")}>{meta.icon}</span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                  <div className={"font-mono text-sm " + (isPast ? "text-slate-500" : "text-slate-600")}>{b.start}–{b.end}</div>
                  <div className={"font-medium truncate " + (isPast ? "text-slate-600" : "text-slate-900")}>{b.label}</div>
                </div>
                {b.notes ? (
                  <div className={"text-sm mt-1 " + (isPast ? "text-slate-500" : "text-slate-600")}>{b.notes}</div>
                ) : null}
              </div>
              {isCurrent ? (
                <span className="notion-pill">Ahora</span>
              ) : null}
            </div>
          );
        })}
      </div>
    </div>
  );
}
