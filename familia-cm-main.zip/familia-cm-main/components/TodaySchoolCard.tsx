"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { countNew } from "@/lib/schoolInbox";

export default function TodaySchoolCard() {
  const [count, setCount] = useState<number>(0);

  useEffect(() => {
    let mounted = true;
    countNew()
      .then((n) => mounted && setCount(n))
      .catch(() => {});
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <Link href="/colegio" className="nido-card-summary no-underline">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="nido-eyebrow">COLE</div>
          <div className="mt-1 text-base font-semibold text-slate-900">Inbox del cole</div>
          <div className="mt-1 text-sm text-slate-600">
            {count > 0 ? `${count} nuevo(s)` : "Todo tranquilo. De momento."}
          </div>
        </div>
        <div className="nido-cta-secondary">Abrir</div>
      </div>
    </Link>
  );
}
