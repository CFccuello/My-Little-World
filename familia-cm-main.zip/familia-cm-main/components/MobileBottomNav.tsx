"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import clsx from "clsx";

type Item = {
  href: string;
  label: string;
  icon: string;
  // If kind is "primary" the item will be highlighted differently (used
  // for the central "Añadir" action).
  kind?: "primary" | "normal";
};

// Definition of the navigation items. We fix five entries in this order:
// Inicio, Hoy, Añadir, Semana, Familia. The third entry is marked as
// primary to draw attention to the add action.
const ITEMS: Item[] = [
  { href: "/", label: "Inicio", icon: "⌂" },
  { href: "/today", label: "Hoy", icon: "☀" },
  { href: "/commands", label: "Añadir", icon: "＋", kind: "primary" },
  { href: "/calendar", label: "Semana", icon: "▦" },
  { href: "/familia", label: "Familia", icon: "👪" },
];

export default function MobileBottomNav() {
  const pathname = usePathname();

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 nido-bottomnav">
      <div className="mx-auto max-w-screen-sm px-2 pt-2 pb-[calc(0.5rem+env(safe-area-inset-bottom))]">
        <nav className="grid grid-cols-5 gap-1" aria-label="Navegación">
          {ITEMS.map((it) => {
            const active = pathname === it.href || pathname?.startsWith(it.href + "/");
            const isPrimary = it.kind === "primary";
            return (
              <Link
                key={it.href}
                href={it.href}
                className={clsx(
                  "nido-bottomnav-item",
                  isPrimary
                    ? active
                      ? "nido-bottomnav-primary is-active"
                      : "nido-bottomnav-primary"
                    : active
                      ? "nido-bottomnav-item-active"
                      : ""
                )}
              >
                <div className={clsx("leading-none", isPrimary ? "text-2xl -mt-0.5" : "text-xl")}>{it.icon}</div>
                <div className={clsx("mt-1", isPrimary && "font-semibold")}>{it.label}</div>
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}