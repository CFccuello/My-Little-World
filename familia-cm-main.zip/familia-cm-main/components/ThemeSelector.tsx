"use client";

import clsx from "clsx";
import { useEffect, useMemo, useState } from "react";

import { applyUiToHtml, loadUi, saveUi, type ModeId, type ThemeId } from "@/lib/uiSettings";

type ThemeOption = {
  id: ThemeId;
  name: string;
  vibe: string;
  emoji: string;
};

const THEMES: ThemeOption[] = [
  { id: "calm-sand", name: "Arena", vibe: "Suave y cálido", emoji: "🪺" },
  { id: "blue-order", name: "Azul", vibe: "Orden limpio", emoji: "🫧" },
  { id: "green-health", name: "Verde", vibe: "Salud y equilibrio", emoji: "🌿" },
  { id: "pink-home", name: "Rosa", vibe: "Hogar y cariño", emoji: "🐣" },
  { id: "graphite-focus", name: "Grafito", vibe: "Foco y noche", emoji: "🌙" },
  { id: "lavender-calm", name: "Lavanda", vibe: "Calma premium", emoji: "💜" },
];

const MODES: Array<{ id: ModeId; label: string; hint: string }> = [
  { id: "auto", label: "Auto", hint: "Sigue el sistema" },
  { id: "light", label: "Claro", hint: "Siempre claro" },
  { id: "dark", label: "Oscuro", hint: "Siempre oscuro" },
];

export default function ThemeSelector() {
  const initial = useMemo(() => loadUi(), []);
  const [theme, setTheme] = useState<ThemeId>(initial.theme);
  const [mode, setMode] = useState<ModeId>(initial.mode);
  const [savedMsg, setSavedMsg] = useState<string | null>(null);

  // Live preview (applies immediately). The explicit “Guardar” button
  // exists to give confidence.
  useEffect(() => {
    const next = loadUi();
    const preview = { ...next, theme, mode };
    applyUiToHtml(preview);
  }, [theme, mode]);

  function handleSave() {
    const next = loadUi();
    const merged = { ...next, theme, mode };
    saveUi(merged);
    applyUiToHtml(merged);
    setSavedMsg("Guardado. Tu nido está listo.");
    window.setTimeout(() => setSavedMsg(null), 1800);
  }

  const currentTheme = THEMES.find((t) => t.id === theme);

  return (
    <div className="space-y-4">
      <div>
        <div className="text-sm font-semibold text-[hsl(var(--foreground))]">Tema</div>
        <div className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">
          Cambia la sensación. Puedes guardar aunque ya esté aplicado.
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        {THEMES.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTheme(t.id)}
            className={clsx(
              "rounded-xl border px-3 py-2 text-left",
              "bg-[hsl(var(--card)/0.35)]",
              "border-[hsl(var(--border))]",
              "active:scale-[0.99] transition",
              t.id === theme && "ring-2 ring-[hsl(var(--primary)/0.35)]",
            )}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="text-sm font-semibold text-[hsl(var(--foreground))] truncate">
                  {t.name}
                </div>
                <div className="text-xs text-[hsl(var(--muted-foreground))] truncate">{t.vibe}</div>
              </div>
              <div className="text-lg leading-none">{t.emoji}</div>
            </div>
          </button>
        ))}
      </div>

      <div>
        <div className="text-sm font-semibold text-[hsl(var(--foreground))]">Modo</div>
        <div className="mt-2 grid grid-cols-3 gap-2">
          {MODES.map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => setMode(m.id)}
              className={clsx(
                "rounded-xl border px-3 py-2 text-left",
                "bg-[hsl(var(--card)/0.35)]",
                "border-[hsl(var(--border))]",
                "active:scale-[0.99] transition",
                m.id === mode && "ring-2 ring-[hsl(var(--primary)/0.35)]",
              )}
            >
              <div className="text-sm font-semibold text-[hsl(var(--foreground))]">{m.label}</div>
              <div className="text-[11px] text-[hsl(var(--muted-foreground))]">{m.hint}</div>
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center justify-between gap-3">
        <button type="button" className="nido-cta" onClick={handleSave}>
          Guardar
        </button>
        <div className="text-xs text-[hsl(var(--muted-foreground))]">
          {savedMsg ? (
            <span className="nido-badge">{savedMsg}</span>
          ) : currentTheme ? (
            <span className="nido-badge">{currentTheme.emoji} {currentTheme.name} · {mode}</span>
          ) : null}
        </div>
      </div>
    </div>
  );
}
