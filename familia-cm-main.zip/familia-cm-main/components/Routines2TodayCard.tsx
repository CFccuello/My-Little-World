"use client";

import Link from "next/link";
import clsx from "clsx";
import { useEffect, useMemo, useState } from "react";

import type { PersonKey, Routine2 } from "@/lib/routines2";
import {
  daysRemainingToSunday,
  formatAssignees,
  getActiveSectionForDate,
  loadActivePerson,
  loadCompletions2,
  loadRoutines2,
  LS_ROUTINES,
  routineDone,
  saveActivePerson,
  saveCompletions2,
  saveRoutines2,
  setRoutineDone,
  sortRoutines,
} from "@/lib/routines2";

function personChip(p: PersonKey) {
  return p === "carlos"
    ? { label: "C", bird: "🦅", name: "Carlos" }
    : { label: "D", bird: "🕊️", name: "Davinia" };
}

function daysLabel(n: number) {
  if (n === 1) return "1 día";
  return `${n} días`;
}

export default function Routines2TodayCard({ dateISO }: { dateISO: string }) {
  const [routines, setRoutines] = useState<Routine2[]>(() => sortRoutines(loadRoutines2()));
  const [completions, setCompletions] = useState(() => loadCompletions2());
  const [activePerson, setActivePerson] = useState<PersonKey>(() => loadActivePerson());

  // Ensure seed is persisted once (so assignment edits have a stable base).
  useEffect(() => {
    try {
      if (typeof window === "undefined") return;
      const has = window.localStorage.getItem(LS_ROUTINES);
      if (!has) saveRoutines2(routines);
    } catch {
      // ignore
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    saveActivePerson(activePerson);
  }, [activePerson]);

  const dailySection = useMemo(() => getActiveSectionForDate(dateISO), [dateISO]);

  const daily = useMemo(() => {
    return routines
      .filter((r) => r.section === dailySection)
      .sort((a, b) => a.sort - b.sort);
  }, [routines, dailySection]);

  const weekly = useMemo(() => {
    return routines
      .filter((r) => r.section === "weekly")
      .sort((a, b) => a.sort - b.sort);
  }, [routines]);

  const remaining = useMemo(() => daysRemainingToSunday(dateISO), [dateISO]);

  const doneCountDaily = useMemo(() => {
    return daily.filter((r) => !!routineDone(completions, r.section, r.id, dateISO)).length;
  }, [daily, completions, dateISO]);

  const doneCountWeekly = useMemo(() => {
    return weekly.filter((r) => !!routineDone(completions, r.section, r.id, dateISO)).length;
  }, [weekly, completions, dateISO]);

  const toggleDone = (r: Routine2, value: boolean) => {
    const next = setRoutineDone(completions, r.section, r.id, dateISO, activePerson, value);
    setCompletions(next);
    saveCompletions2(next);
  };

  return (
    <div className="space-y-3">
      {/* Selector de quién está marcando */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="text-xs font-semibold text-[hsl(var(--muted-foreground))]">Marcando como</div>
        <div className="flex items-center gap-2">
          {(["davinia", "carlos"] as PersonKey[]).map((p) => {
            const meta = personChip(p);
            const active = activePerson === p;
            return (
              <button
                key={p}
                type="button"
                className={clsx("nido-pill", active && "is-active")}
                onClick={() => setActivePerson(p)}
                aria-pressed={active}
              >
                <span className="text-sm">{meta.label}</span>
                <span className="text-sm" aria-hidden="true">
                  {meta.bird}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Diario (solo sección activa hoy) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between gap-2">
          <div className="text-sm font-semibold text-[hsl(var(--foreground))]">
            {dailySection === "weekday" ? "Lun–Vie" : "Sáb–Dom"}
          </div>
          <div className="nido-badge">{doneCountDaily}/{daily.length}</div>
        </div>

        {daily.length > 0 ? (
          <div className="space-y-2">
            {daily.map((r) => {
              const done = routineDone(completions, r.section, r.id, dateISO);
              const who = done ? personChip(done.doneBy) : null;

              return (
                <label
                  key={r.id}
                  className={clsx(
                    "flex items-center gap-3 rounded-xl border border-[hsl(var(--border))] px-3 py-2",
                    "bg-[hsl(var(--card)/0.35)]",
                    done &&
                      (done.doneBy === "carlos"
                        ? "ring-1 ring-[hsl(var(--primary)/0.28)]"
                        : "ring-1 ring-[hsl(var(--secondary)/0.28)]")
                  )}
                >
                  <input
                    type="checkbox"
                    className="h-4 w-4"
                    checked={!!done}
                    onChange={(e) => toggleDone(r, e.target.checked)}
                  />

                  <div className="min-w-0 flex-1">
                    <div className={clsx("text-sm", done ? "text-[hsl(var(--foreground))]" : "text-[hsl(var(--foreground))]")}> {r.label}</div>
                    <div className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">
                      {formatAssignees(r.assignedTo)}
                    </div>
                  </div>

                  {done && who ? (
                    <span className="nido-badge" title={`Hecho por ${who.name}`}>✓ {who.label} {who.bird}</span>
                  ) : null}
                </label>
              );
            })}
          </div>
        ) : (
          <div className="text-sm text-[hsl(var(--muted-foreground))]">Sin rutinas aquí. El nido está sorprendentemente tranquilo.</div>
        )}
      </div>

      {/* Semanales */}
      <div className="space-y-2">
        <div className="flex items-center justify-between gap-2">
          <div className="text-sm font-semibold text-[hsl(var(--foreground))]">Semanales</div>
          <div className="flex items-center gap-2">
            <span className="nido-badge">Quedan {daysLabel(remaining)}</span>
            <span className="nido-badge">{doneCountWeekly}/{weekly.length}</span>
          </div>
        </div>

        {weekly.length > 0 ? (
          <div className="space-y-2">
            {weekly.map((r) => {
              const done = routineDone(completions, r.section, r.id, dateISO);
              const who = done ? personChip(done.doneBy) : null;

              return (
                <label
                  key={r.id}
                  className={clsx(
                    "flex items-center gap-3 rounded-xl border border-[hsl(var(--border))] px-3 py-2",
                    "bg-[hsl(var(--card)/0.35)]",
                    done &&
                      (done.doneBy === "carlos"
                        ? "ring-1 ring-[hsl(var(--primary)/0.28)]"
                        : "ring-1 ring-[hsl(var(--secondary)/0.28)]")
                  )}
                >
                  <input
                    type="checkbox"
                    className="h-4 w-4"
                    checked={!!done}
                    onChange={(e) => toggleDone(r, e.target.checked)}
                  />

                  <div className="min-w-0 flex-1">
                    <div className="text-sm text-[hsl(var(--foreground))]">{r.label}</div>
                    <div className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">
                      {formatAssignees(r.assignedTo)}
                    </div>
                  </div>

                  {done && who ? (
                    <span className="nido-badge" title={`Hecho por ${who.name}`}>✓ {who.label} {who.bird}</span>
                  ) : null}
                </label>
              );
            })}
          </div>
        ) : (
          <div className="text-sm text-[hsl(var(--muted-foreground))]">No hay semanales aún. El dodo 🦤 aplaude tu minimalismo.</div>
        )}
      </div>

      <div className="flex items-center justify-between gap-3 pt-1">
        <div className="text-xs text-[hsl(var(--muted-foreground))]">
          Truco: si algo se queda a medias, el nido no juzga.
        </div>
        <Link href="/routines" className="nido-badge no-underline">
          Ver todas
        </Link>
      </div>
    </div>
  );
}
