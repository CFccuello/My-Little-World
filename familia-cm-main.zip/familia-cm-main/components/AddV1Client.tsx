"use client";

import { useMemo, useState } from "react";
import { lsGet, lsSet } from "@/lib/localStore";

// Representa un elemento añadido a la lista 'later'. Se guarda con un
// identificador simple, el tipo (tarea, compra, medicación, nota) y
// el texto introducido por el usuario. La propiedad 'done' permite
// reutilizar el mismo esquema de checklist aunque estos ítems se
// gestionen por separado.
interface LaterItem {
  id: string;
  type: "tarea" | "compra" | "medicacion" | "nota";
  text: string;
  done: boolean;
}

function makeId(): string {
  return `id_${Math.random().toString(16).slice(2)}${Date.now().toString(16)}`;
}

/**
 * Componente para añadir elementos rápidos. Muestra cuatro plantillas
 * (tarea, compra, medicación, nota). Cuando el usuario selecciona
 * una plantilla, se abre un formulario simple donde puede introducir
 * el texto. Al guardar, el elemento se almacena en localStorage en
 * la clave "familiaCM:later" y se restablece el estado inicial.
 */
export default function AddV1Client() {
  const [selected, setSelected] = useState<null | LaterItem["type"]>(null);
  const [text, setText] = useState("");
  const [message, setMessage] = useState<string | null>(null);

  const TYPES = useMemo(() => {
    const map: Record<
      LaterItem["type"],
      { icon: string; title: string; desc: string; placeholder: string; helper?: string }
    > = {
      tarea: {
        icon: "✅",
        title: "Tarea",
        desc: "Una cosa. Sin drama.",
        placeholder: "Ej: Poner lavadora · sábanas",
      },
      compra: {
        icon: "🛒",
        title: "Compra",
        desc: "Algo que falta. Y ya.",
        placeholder: "Ej: Toallitas Roma",
      },
      medicacion: {
        icon: "💊",
        title: "Medicación",
        desc: "Recordatorio (con cariño).",
        placeholder: "Ej: Recordar jarabe 21:00",
        helper: "Si necesitas cálculo/dosis: entra en Medicación. Aquí es solo “me lo apunto”.",
      },
      nota: {
        icon: "📝",
        title: "Nota",
        desc: "Idea suelta. El nido la guarda.",
        placeholder: "Ej: Idea de merienda: yogur + fruta",
      },
    };
    return map;
  }, []);

  const onSelect = (type: LaterItem["type"]) => {
    setSelected(type);
    setText("");
    setMessage(null);
  };

  const onSave = () => {
    const t = text.trim();
    if (!t || !selected) return;
    const key = "familiaCM:later";
    const existing = lsGet<LaterItem[]>(key, []);
    const newItem: LaterItem = { id: makeId(), type: selected, text: t, done: false };
    lsSet(key, [...existing, newItem]);

    // Importante: mensaje visible aunque volvamos a la pantalla de plantillas.
    setMessage("Listo 🐣 Guardado. Tú a lo tuyo.");
    setSelected(null);
    setText("");
  };

  const selectedMeta = selected ? TYPES[selected] : null;

  return (
    <div className="space-y-4">
      {/* Hero para la pantalla de añadir */}
      <div className="nido-hero">
        <div>
          <div className="nido-eyebrow">Añadir</div>
          <div className="mt-2 text-2xl font-semibold tracking-tight text-[hsl(var(--foreground))]">
            Guardar ahora, decidir después
          </div>
          <div className="mt-2 text-sm text-[hsl(var(--muted-foreground))]">
            El pollito 🐥 lo guarda. Tú sigues con tu día.
          </div>
        </div>
      </div>

      {/* Mensaje global (feedback real) */}
      {message ? (
        <div className="card p-3">
          <div className="text-sm text-[hsl(var(--foreground))]">{message}</div>
        </div>
      ) : null}

      {/* Selección de plantillas si no hay selección */}
      {selected === null ? (
        <div className="grid grid-cols-2 gap-3">
          {(Object.keys(TYPES) as LaterItem["type"][]).map((t) => (
            <button key={t} className="nido-card text-left" onClick={() => onSelect(t)}>
              <div className="text-xl">{TYPES[t].icon}</div>
              <div className="mt-2 text-base font-semibold text-[hsl(var(--foreground))]">{TYPES[t].title}</div>
              <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">{TYPES[t].desc}</div>
            </button>
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {/* Formulario para la plantilla seleccionada */}
          <div className="card p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-xs text-[hsl(var(--muted-foreground))]">Nueva</div>
                <div className="font-semibold mb-1">
                  {selectedMeta?.title ?? "Entrada"} {selectedMeta?.icon ?? ""}
                </div>
                {selectedMeta?.helper ? (
                  <div className="text-sm text-[hsl(var(--muted-foreground))]">{selectedMeta.helper}</div>
                ) : null}
              </div>
            </div>

            <textarea
              className="input min-h-[110px] mt-3"
              placeholder={selectedMeta?.placeholder ?? "Escribe aquí…"}
              value={text}
              onChange={(e) => setText(e.target.value)}
            />

            <div className="mt-3 flex items-center gap-2">
              <button className="nido-cta" onClick={onSave} disabled={!text.trim()}>
                Guardar
              </button>
              <button
                className="nido-cta-secondary"
                onClick={() => {
                  setSelected(null);
                  setText("");
                  setMessage(null);
                }}
              >
                Volver
              </button>
            </div>

            <div className="mt-3 text-xs text-[hsl(var(--muted-foreground))]">
              Consejo de nido: una frase corta vale más que una novela.
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
