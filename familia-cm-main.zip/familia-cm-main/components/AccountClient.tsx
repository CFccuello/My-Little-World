"use client";

import clsx from "clsx";
import { useEffect, useMemo, useState } from "react";
import { useNidoUser } from "@/lib/useNidoUser";
import { roleLabel } from "@/lib/roles";
import { loadProfile, saveProfile, type Profile } from "@/lib/profileStore";

export default function AccountClient() {
  const user = useNidoUser();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [msg, setMsg] = useState<string>("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user.ready) return;
    if (!user.userId) return;
    let mounted = true;
    loadProfile(user.userId, user.email).then((p) => {
      if (!mounted) return;
      setProfile(p);
    });
    return () => {
      mounted = false;
    };
  }, [user.ready, user.userId, user.email]);

  const initials = useMemo(() => {
    const name = (profile?.display_name || user.email || "").trim();
    if (!name) return "N";
    const parts = name.split(/\s+/).filter(Boolean);
    const a = parts[0]?.[0] ?? "N";
    const b = parts.length > 1 ? parts[parts.length - 1]?.[0] ?? "" : "";
    return `${a}${b}`.toUpperCase();
  }, [profile?.display_name, user.email]);

  const save = async () => {
    if (!profile) return;
    setLoading(true);
    setMsg("Guardando…");
    const res = await saveProfile(profile);
    setLoading(false);
    setMsg(res.message || (res.ok ? "Guardado." : "Guardado local."));
    window.setTimeout(() => setMsg(""), 1600);
  };

  if (!user.ready || !profile) {
    return (
      <div className="card p-4">
        <div className="text-sm text-slate-600">Cargando…</div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header / identity */}
      <div className="card p-4">
        <div className="flex items-start gap-4">
          <div
            className={clsx(
              "h-14 w-14 rounded-3xl grid place-items-center",
              "bg-slate-900 text-white font-semibold"
            )}
            aria-label="Avatar"
            title="Avatar (pronto)"
          >
            {initials}
          </div>

          <div className="flex-1">
            <div className="font-semibold">Perfil</div>
            <div className="mt-1 text-sm text-slate-600">
              {user.email} · {roleLabel(user.role)}
            </div>
            <div className="mt-2 text-xs text-slate-500">
              Avatar: subiremos foto a Supabase Storage en una iteración posterior.
            </div>
          </div>
        </div>
      </div>

      {/* Fields */}
      <div className="card p-4">
        <div className="font-semibold">Datos</div>
        <div className="mt-3 grid gap-3">
          <Field label="Nombre">
            <input
              className="input"
              value={profile.display_name}
              onChange={(e) => setProfile({ ...profile, display_name: e.target.value })}
              placeholder="Tu nombre"
            />
          </Field>
          <Field label="Email">
            <input className="input" value={user.email || ""} readOnly />
          </Field>
          <Field label="Rol">
            <input className="input" value={roleLabel(user.role)} readOnly />
          </Field>
        </div>
      </div>

      <div className="card p-4">
        <div className="font-semibold">Links</div>
        <div className="mt-1 text-sm text-slate-600">
          Guarda aquí enlaces útiles (sociales o personales).
        </div>

        <div className="mt-3 grid gap-3">
          <Field label="Web">
            <input
              className="input"
              value={profile.website_url}
              onChange={(e) => setProfile({ ...profile, website_url: e.target.value })}
              placeholder="https://..."
              inputMode="url"
            />
          </Field>
          <Field label="Instagram">
            <input
              className="input"
              value={profile.instagram_url}
              onChange={(e) => setProfile({ ...profile, instagram_url: e.target.value })}
              placeholder="https://instagram.com/..."
              inputMode="url"
            />
          </Field>
          <Field label="X / Twitter">
            <input
              className="input"
              value={profile.x_url}
              onChange={(e) => setProfile({ ...profile, x_url: e.target.value })}
              placeholder="https://x.com/..."
              inputMode="url"
            />
          </Field>
          <Field label="LinkedIn">
            <input
              className="input"
              value={profile.linkedin_url}
              onChange={(e) => setProfile({ ...profile, linkedin_url: e.target.value })}
              placeholder="https://linkedin.com/in/..."
              inputMode="url"
            />
          </Field>
        </div>

        <div className="mt-3 flex items-center gap-2">
          <button className="btn-primary" onClick={save} disabled={loading}>
            {loading ? "Guardando…" : "Guardar"}
          </button>
          <div className="text-sm text-slate-600">{msg}</div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="label">{label}</div>
      {children}
    </div>
  );
}
