"use client";

import Papa from "papaparse";
import { useMemo, useState, useEffect } from "react";
import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";
import { lsGet, lsSet } from "@/lib/localStore";

type Row = { date: string; description: string; amount: number };

function normalizeHeader(h: string) {
  return h.trim().toLowerCase();
}

function normalizeUrlNumber(raw: string): number | null {
  // Quita moneda, espacios y normaliza separadores.
  // Soporta:
  // - "1.234,56" -> 1234.56
  // - "1,234.56" -> 1234.56
  // - "-12,34" -> -12.34
  const s0 = (raw ?? "")
    .toString()
    .replace(/\u00A0/g, " ")
    .replace(/[€$]/g, "")
    .replace(/\s/g, "")
    .trim();

  if (!s0) return null;

  const hasComma = s0.includes(",");
  const hasDot = s0.includes(".");

  let s = s0;

  if (hasComma && hasDot) {
    // Si hay ambos, asumimos que el último separador es el decimal.
    const lastComma = s.lastIndexOf(",");
    const lastDot = s.lastIndexOf(".");
    const decimalIsComma = lastComma > lastDot;

    if (decimalIsComma) {
      s = s.replace(/\./g, "").replace(",", ".");
    } else {
      s = s.replace(/,/g, "");
    }
  } else if (hasComma && !hasDot) {
    s = s.replace(",", ".");
  } else {
    // solo dot o nada: lo dejamos
  }

  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

export default function Finance() {
  const [rows, setRows] = useState<Row[]>([]);
  const [userId, setUserId] = useState<string | null>(null);

  // Microcopy + estado visible
  const [status, setStatus] = useState<string>("Aún no hay CSV. Cuando lo subas, lo ordeno sin juicio. 🐣");
  const [fileName, setFileName] = useState<string | null>(null);

  const lsKey = "familiaCM:transactions";

  useEffect(() => {
    if (!isSupabaseConfigured) return;
    supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id ?? null));
  }, []);

  const totals = useMemo(() => {
    const income = rows.filter((r) => r.amount > 0).reduce((a, b) => a + b.amount, 0);
    const expense = rows.filter((r) => r.amount < 0).reduce((a, b) => a + b.amount, 0);
    return { income, expense, net: income + expense };
  }, [rows]);

  const parseFile = (file: File) => {
    setStatus("Leyendo CSV… el dodo 🦤 está concentrado.");
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (res) => {
        const data = res.data as any[];
        const mapped: Row[] = [];

        for (const r of data) {
          const keys = Object.keys(r);

          const get = (cands: string[]) => {
            for (const k of keys) {
              const nk = normalizeHeader(k);
              if (cands.includes(nk)) return r[k];
            }
            return "";
          };

          const dateRaw = String(
            get([
              "date",
              "fecha",
              "booking date",
              "value date",
              "fecha operación",
              "fecha operacion",
              "fecha de operación",
              "fecha de operacion",
            ])
          ).trim();

          const descriptionRaw = String(
            get(["description", "concepto", "detalle", "referencia", "descripcion", "descripción"])
          ).trim();

          const amountRaw = String(
            get(["amount", "importe", "cantidad", "monto", "importe (€)", "importe(€)", "importe eur", "importe€"])
          ).trim();

          const date = dateRaw.slice(0, 10);
          const description = descriptionRaw;
          const amount = normalizeUrlNumber(amountRaw);

          if (!date || !description || amount === null) continue;

          mapped.push({ date, description, amount });
        }

        setRows(mapped);

        if (mapped.length === 0) {
          setStatus(
            "No he encontrado filas válidas. Tip pollito 🐥: revisa que existan columnas Fecha/Concepto/Importe (o similares)."
          );
          return;
        }

        setStatus(`Listo 🐣 He leído ${mapped.length} fila(s). Mira la vista previa abajo.`);
      },
      error: () => setStatus("Uy… el dodo 🦤 no ha podido leer ese CSV. Prueba otro archivo."),
    });
  };

  const save = async () => {
    if (rows.length === 0) {
      setStatus("Nada que guardar aún. Primero un CSV 🐣");
      return;
    }

    if (!isSupabaseConfigured) {
      const prev = lsGet(lsKey, [] as Row[]);
      const next = [...rows, ...prev].slice(0, 5000);
      lsSet(lsKey, next);
      setStatus("Guardado en este dispositivo 🪺 (modo local).");
      return;
    }

    if (!userId) {
      setStatus("Necesito sesión iniciada para guardar en Supabase.");
      return;
    }

    setStatus("Guardando en Supabase…");
    const payload = rows.map((r) => ({
      user_id: userId,
      tx_date: r.date,
      description: r.description,
      amount: r.amount,
    }));

    const { error } = await supabase
      .from("transactions")
      .upsert(payload, { onConflict: "user_id,tx_date,description,amount" });

    if (error) setStatus(`Error guardando: ${error.message}`);
    else setStatus("Guardado OK 🐥");
  };

  const clear = () => {
    setRows([]);
    setFileName(null);
    setStatus("Lista limpia. Cuando quieras, otro CSV 🐣");
  };

  return (
    <div className="space-y-4">
      <div className="card p-4">
        <div className="font-semibold">Finanzas</div>
        <div className="mt-2 text-sm text-slate-600">
          Importa un CSV del banco para ver totales. El nido lo ordena y tú solo miras lo importante.
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <input
            type="file"
            accept=".csv,text/csv"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              setFileName(f.name);
              parseFile(f);
            }}
          />

          <button className="btn-primary" onClick={save} disabled={rows.length === 0}>
            {isSupabaseConfigured ? "Guardar (Supabase)" : "Guardar (local)"}
          </button>

          <button className="btn" onClick={clear} disabled={rows.length === 0 && !fileName}>
            Limpiar
          </button>
        </div>

        <div className="mt-3 text-sm text-slate-700">
          {fileName ? (
            <span>
              Archivo: <span className="font-mono">{fileName}</span>
            </span>
          ) : (
            <span>Archivo: —</span>
          )}
        </div>

        <div className="mt-2 text-sm text-slate-600">{status}</div>

        <div className="mt-3 text-xs text-slate-500">
          Consejo del dodo 🦤: si tu banco usa “;” o nombres raros, igual funciona. Si no, dime el encabezado y lo adapto.
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Stat label="Ingresos" value={totals.income} />
        <Stat label="Gastos" value={totals.expense} />
        <Stat label="Neto" value={totals.net} />
      </div>

      <div className="card p-4">
        <div className="font-semibold">Vista previa (primeras 50 filas)</div>
        <div className="mt-3 notion-table-wrap">
          <table className="notion-table min-w-[640px]">
            <thead>
              <tr>
                <th>Fecha</th>
                <th>Concepto</th>
                <th>Importe</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td className="notion-empty" colSpan={3}>
                    Aún no hay tabla. Sube un CSV y te enseño el resumen 🐣
                  </td>
                </tr>
              ) : null}
              {rows.slice(0, 50).map((r, idx) => (
                <tr key={idx}>
                  <td className="font-mono">{r.date}</td>
                  <td className="truncate max-w-[520px]" title={r.description}>
                    {r.description}
                  </td>
                  <td className="font-mono">{r.amount.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="card p-4">
      <div className="text-sm text-slate-600">{label}</div>
      <div className="mt-1 text-2xl font-semibold font-mono">{value.toFixed(2)}</div>
    </div>
  );
}
