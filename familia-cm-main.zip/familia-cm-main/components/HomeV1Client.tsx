"use client";

import Link from "next/link";
import { format } from "date-fns";
import { useEffect, useMemo } from "react";
import { lsGet } from "@/lib/localStore";
import type { ChecklistItem } from "@/lib/types";
import { birdForDate } from "@/lib/birds";
import { getEventsLocal } from "@/lib/eventsStore";
import { parseISO, isAfter } from "date-fns";
import { applyUiToHtml, loadUi, type HomeLayoutId } from "@/lib/uiSettings";

// Claim shown at the top of the home screen.
const HOME_CLAIM = "Tu casa y tu familia, en orden. Sin ruido.";

// Definition of the modules/cards on the home screen. Comida se muestra primero
// porque es el módulo más utilizado por Davinia, seguido de Familia,
// Medicación y Rutinas. Cada entrada incluye un icono, un título y una ruta
// destino, así como una clase de color de fondo (tinte) para diferenciar
// visualmente los módulos.
const HOME_MODULES = [
  {
    key: "comida",
    title: "Comida",
    icon: "🍽️",
    href: "/comida",
    tintClass: "bg-amber-50",
  },
  {
    key: "familia",
    title: "Familia",
    icon: "👪",
    href: "/familia",
    tintClass: "bg-sky-50",
  },
  {
    key: "medicacion",
    title: "Medicación",
    icon: "💊",
    href: "/medicacion",
    tintClass: "bg-violet-50",
  },
  {
    key: "rutinas",
    title: "Rutinas",
    icon: "✅",
    href: "/today",
    tintClass: "bg-emerald-50",
  },
] as const;

type ChecklistSummary = {
  total: number;
  done: number;
  next?: string;
};

/**
 * Summarise a checklist into counts of total/done and pick the next undone
 * item. This helper makes it easy to calculate progress for each checklist.
 */
function summarise(items: ChecklistItem[]): ChecklistSummary {
  const total = items.length;
  const done = items.filter((i) => i.done).length;
  const next = items.find((i) => !i.done)?.text;
  return { total, done, next };
}

export default function HomeV1Client({
  initialLayout,
}: {
  initialLayout?: HomeLayoutId;
}) {
  // Preview-only for /lab: apply layout to HTML without persisting it.
  useEffect(() => {
    if (!initialLayout) return;

    const current = loadUi();
    applyUiToHtml({ ...current, homeLayout: initialLayout });

    return () => {
      // Restore persisted UI when leaving /lab.
      applyUiToHtml(loadUi());
    };
  }, [initialLayout]);

  // Current date (yyyy-mm-dd) for localStorage keys
  const dateISO = useMemo(() => format(new Date(), "yyyy-MM-dd"), []);

  // Unificamos el ave del día con el resto de la app (SplashGate/BirdStamp).
  const bird = useMemo(() => birdForDate(dateISO), [dateISO]);

  // Aggregate checklist data from localStorage. We assume three lists exist:
  // work, carlos and home_family. If they don't exist the helper returns
  // empty arrays.
  const doneBy = useMemo(() => {
    const work = summarise(lsGet<ChecklistItem[]>(`familiaCM:checklist:${dateISO}:work`, []));
    const carlos = summarise(lsGet<ChecklistItem[]>(`familiaCM:checklist:${dateISO}:carlos`, []));
    const home = summarise(lsGet<ChecklistItem[]>(`familiaCM:checklist:${dateISO}:home_family`, []));
    const next = home.next ?? carlos.next ?? work.next;
    const remaining = (work.total - work.done) + (carlos.total - carlos.done) + (home.total - home.done);
    return {
      next: next ?? "Nada urgente. El nido respira.",
      remaining,
      carlosDone: carlos.done,
      homeDone: home.done,
    };
  }, [dateISO]);

  const progressLabel = useMemo(() => {
    if (doneBy.remaining <= 0) return "Hoy está en calma.";
    if (doneBy.remaining === 1) return "Te queda 1 cosa. Con eso vale.";
    return `Te quedan ${doneBy.remaining}. Con una vale.`;
  }, [doneBy.remaining]);

  const nextEvent = useMemo(() => {
    const now = new Date();
    const events = getEventsLocal();
    const upcoming = events
      .map((e) => ({ ...e, start: parseISO(e.startISO) }))
      .filter((e) => isAfter(e.start, now))
      .sort((a, b) => a.start.getTime() - b.start.getTime());
    return upcoming[0] ?? null;
  }, []);

  return (
    <div className="space-y-4">
      {/* Hero / claim */}
      <div className="nido-hero">
        <div>
          <div className="text-sm text-slate-600">NIDO</div>
          <div className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">
            {HOME_CLAIM}
          </div>
          <div className="mt-2 text-sm text-slate-600">Hoy, paso a paso.</div>
        </div>
      </div>

      {/* Tarjeta principal Hoy */}
      <Link href="/today" className="nido-card-primary no-underline relative overflow-hidden">
        <div
          className="pointer-events-none absolute -right-2 -top-2 text-6xl opacity-10"
          aria-hidden="true"
        >
          {bird.emoji}
        </div>
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="nido-eyebrow">HOY</div>
            <div className="mt-1 text-lg font-semibold text-slate-900">
              Siguiente: <span className="text-slate-900">{doneBy.next}</span>
            </div>
            <div className="mt-1 text-sm text-slate-600">{progressLabel}</div>
            <div className="mt-3 flex items-center gap-2 text-xs text-slate-600">
              <span className="nido-badge">Hecho hoy</span>
              <span>Carlos {doneBy.carlosDone}</span>
              <span className="text-slate-300">·</span>
              <span>Casa {doneBy.homeDone}</span>
            </div>
          </div>
          <div className="nido-cta">Continuar</div>
        </div>
      </Link>

      {/* Temas / módulos */}
      <div>
        <div className="nido-section-title">Temas</div>
        <div className="nido-grid">
          {HOME_MODULES.map((m) => (
            <Link key={m.key} href={m.href} className={`nido-card ${m.tintClass} no-underline`}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-2xl leading-none">{m.icon}</div>
                  <div className="mt-2 text-base font-semibold text-slate-900">{m.title}</div>
                  <div className="mt-1 text-sm text-slate-600">Abrir</div>
                </div>
                <div className="text-slate-400">›</div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Esta semana */}
      <Link href="/calendar" className="nido-card-summary no-underline">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="nido-eyebrow">ESTA SEMANA</div>
            <div className="mt-1 text-base font-semibold text-slate-900">Lo importante, visible.</div>
            <div className="mt-1 text-sm text-slate-600">Echa un vistazo y olvídate del resto.</div>
            {nextEvent ? (
              <div className="mt-2 text-xs text-slate-500">
                Próximo: <span className="font-medium">{nextEvent.title}</span> · {format(nextEvent.start, "EEE dd · HH:mm")}
              </div>
            ) : (
              <div className="mt-2 text-xs text-slate-500">Semana tranquila. De momento, nada que perseguir.</div>
            )}
          </div>
          <div className="nido-cta-secondary">Ver semana</div>
        </div>
      </Link>

      {/* Luego */}
      <Link href="/commands" className="nido-card-summary no-underline">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="nido-eyebrow">LUEGO</div>
            <div className="mt-1 text-base font-semibold text-slate-900">Guárdalo aquí.</div>
            <div className="mt-1 text-sm text-slate-600">Sin decidir ahora. Ya lo ordenarás.</div>
          </div>
          <div className="nido-cta-secondary">Añadir</div>
        </div>
      </Link>
    </div>
  );
}
