# 13 — Iconos (mapa + identidad)

## Objetivo
Dar identidad consistente (universo aves/pollitos) **sin perder claridad**. En iPhone se decide en 1 segundo: el icono tiene que ser obvio.

### Regla de oro
- **Icono semántico** = lo que se entiende sin pensar (casa, plato, pastilla, calendario, familia…).
- **Ave** = acento/mascota (sello, micro ilustración, copy, vacíos). **No** sustituye lo semántico si genera duda.

---

## Principios de diseño
1) **Consistencia**: mismo estilo, mismo tamaño, mismos márgenes.
2) **Calma**: aves como “sello” suave (opacidad baja), no como pegatina gigante.
3) **Accesibilidad**: buen contraste en modo oscuro; tap targets grandes.
4) **Escalabilidad**: que funcione con 5 iconos del bottom nav y con 20 módulos en “Más”.

---

## Mapa propuesto

### A) Bottom nav (5 iconos, claridad máxima)
Aquí mandan los iconos universales. Las aves aparecen como **detalle** (micro-sello o “ave del día” en Home, no como icono principal).

| Tab | Icono principal (semántico) | Acento ave | Motivo |
|---|---|---|---|
| Inicio | Casa | **Sparrow** | “NIDO” / identidad del producto. |
| Hoy | Sol / “hoy” | **Chicks** | Energía suave y rutina del nido. |
| Añadir | + | **Dodo** | Humor recurrente y “no pasa nada, añádelo”. |
| Semana | Calendario / grid | **Eagle** | Visión y perspectiva. |
| Familia | Personas | **Dove** / **Swan** | Calma / hogar / vínculo. |

**Nota:** no usar aves como icono único del tab (riesgo de confusión).

---

### B) Home — “Temas” (cards)
Aquí sí podemos “vestir” más.

| Tema | Icono semántico | Ave recomendada | Uso del ave |
|---|---|---|---|
| Comida | 🍽️ / plato | **Duck** | sello suave en esquina (opacidad 8–12%). |
| Medicación | 💊 | **Owl** | sello + microcopy (modo noche). |
| Familia | 👪 | **Dove** / **Swan** | sello + tono calmado. |
| Rutinas | ✅ | **Chicks** | sello + “paso a paso”. |

**DoD visual Home:** se entiende el tema por el icono semántico; el ave solo refuerza la identidad.

---

### C) “Más” — módulos secundarios (grid)
Se mantiene el mismo patrón: icono semántico + sello ave.

| Módulo | Icono semántico | Ave |
|---|---|---|
| Docs / Manuales | 📄 / carpeta | **Parrot** (documentos / “recordatorio”) |
| Finanzas | 💳 / monedas | **Eagle** |
| Inspiración | 💡 | **Hummingbird** / **Flamingo** |
| Lavavajillas | 🍽️🫧 | **Duck** |
| Jugar | 🎲 / mando | **Flamingo** |
| Pareja | ❤️ | **Dove** |

---

## Assets disponibles
Pack SVG en `public/birds/`:
- `chicks.svg`, `dodo.svg`, `dove.svg`, `duck.svg`, `eagle.svg`, `flamingo.svg`, `hummingbird.svg`, `owl.svg`, `parrot.svg`, `penguin.svg`, `sparrow.svg`, `swan.svg`.

---

## Implementación propuesta (cuando toque)
1) **Galería en /lab** para ver todos los SVG y elegir por consenso.
2) Crear un mapa central:
   - `lib/iconMap.ts` con `moduleKey -> { emoji, birdId }`.
3) Componente único:
   - `components/Icon.tsx` que renderice:
     - emoji (rápido) y
     - sello ave (SVG) con opacidad baja.
4) Aplicación gradual:
   - Home → Temas
   - “Más” hub
   - Headers de cada tema

---

## Riesgos / anti-patrones
- **Ave como único icono** en navegación principal: bonito pero confuso.
- Saturar con color: mantener aves como sello suave.
- Mezclar estilos (line icons + ilustración grande): mejor “icono semántico simple” + “sello ave”.
