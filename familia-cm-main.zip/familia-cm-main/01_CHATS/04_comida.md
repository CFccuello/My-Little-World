# Comida (V1)

## Qué hay ahora
- Slots fijos por día: **Desayuno / Almuerzo / Comida / Merienda / Cena**.
- Por persona + Familia:
  - **Familia** / **Greta** / **Máximo** / **Roma**.
- Asignación simple (Carlos asigna, Davinia ve):
  - título + nota (opcional)
  - se guarda **"Asignado por"**.
- **Plantillas rápidas** (píldoras) que rellenan título/nota con 1 toque.
- **Copiar día → día** (por defecto hoy→mañana) para batch cooking y planes.
  - Si el destino ya tiene datos, pide confirmación antes de sobrescribir.

## Comedor (Monzón 3) — Greta + Máximo (V1)
- Tarjeta en `/comida`: **“Comedor · Monzón 3”** con botón rápido:
  - **“Ver el menú (PDF)”**
  - **“Comprobar ahora”** (refresca el enlace)
- Detección automática del PDF desde la web del cole (sin CORS) vía API:
  - `GET /api/comedor/monzon`
- Watcher en background:
  - al abrir la app
  - al volver a primer plano
  - en pull-to-refresh

## Qué falta (para dejar Comida “cerrada y operativa”)
1) **Integración diaria real del comedor (Monzón 3)**
   - Mostrar la comida del cole “en el día a día” dentro de los slots (entre Almuerzo y Merienda).
   - Opción de override manual (si cambian ingredientes ese día).

2) **Menú Roma (guardería) — PDF 4 semanas**
   - Selector “Semana actual (1–4)” + rotación automática.
   - Override manual (si cambian ingredientes) + “recalcular”.

3) **Próximos días**
   - Vista compacta abajo con los siguientes días ya rellenados.

4) **Menús que funcionan (casa)**
   - Lista de menús/fichas con receta + enlace a vídeo (YouTube / Instagram / TikTok).

5) **Aparatos de cocina**
   - Inventario simple (Cosori 2 cajones, Thermomix TM7, sandwichera…).

6) **Lista de la compra ligada a menús + gustos**
   - Preferencias “le gusta / no le gusta” (por miembro) y aviso si algo choca.

7) **IA (más adelante, con datos)**
   - Propuesta de menú por pirámide de alimentos (unificar al máximo entre hijos).
