# Visión y principios (NIDO)

## Qué es NIDO
App familiar iPhone (PWA) para tener la casa y la familia “en orden” sin ruido.

## Éxito (5 segundos)
Davinia abre y entiende:
- qué toca hoy
- qué está hecho y por quién
- dónde ir para comida/medicación/familia en 2–3 toques

## Estética y tono
- Calmado pero bonito (glass suave + aire)
- Microcopy aves/pollitos
- Cero juicio

## No objetivos
- No “panel admin”
- No estilo Notion en móvil
- No flujos largos de clasificación
