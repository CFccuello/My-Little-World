# Pareja

V1:
- check-in semanal
- ideas de cita
- detalle del día
- lista deseos
