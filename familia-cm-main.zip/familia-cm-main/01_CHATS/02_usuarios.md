# Usuarios / roles

- Admin: Carlos
- User: Davinia
- (Tere/Suegra): no por ahora

## Visibilidad
- Preferencias avanzadas: solo admin
- Docs sensibles (Bancos): solo admin
- Davinia: uso diario sin tocar estructura

## Auth / acceso (PWA)
- Email + password (solo invitación).
- La PWA mantiene sesión en refresh/restart.
- Login recuerda último email y soporta `return_to`.
