# Inspiración

- Mostrar ejemplos seed (cards)
- Añadir: pegar enlace + nota
- Conectar redes: opcional (no bloquea)
