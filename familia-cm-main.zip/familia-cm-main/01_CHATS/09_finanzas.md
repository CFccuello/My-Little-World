# Finanzas

- Import CSV con feedback
- Drag & drop + selector
- Bug actual: seleccionar archivo no hace nada (pendiente)
