# UX Davinia

## Home
- Claim + Hoy dominante + Temas (Comida primera)
- 2–3 CTAs fuertes máximo
- Microcopy: corto, calmado, cero juicio

## Hoy
- 1 frase (no duplicar)
- Lo mínimo (1–3)
- **Comida hoy en primer plano**:
  - 3 filas (Greta / Máximo / Roma)
  - destacar slot COMIDA (cole/guardería)
  - CTA “Ver menú” (1 toque) + CTA “Abrir Comida”
- Rutinas (checks) compacto arriba
- Selector simple “Marcando como: D 🕊️ / C 🦅”
- Hecho hoy (Carlos/Davinia) siempre visible

## Añadir
- Mensaje: “Guardar ahora, decidir después”
- Confirmación visible al guardar (no silenciosa)
- Plantillas con ejemplos cortos (una frase)

## Docs
- Vacío: “Aún no hay enlaces…”
- “Garantías” renombrado a “Manuales / Instrucciones”
- CTA: “Guardar” y “Abrir (OneDrive)”

## Finanzas
- Vacío: “Aún no hay CSV…”
- Si 0 filas: avisar con sugerencia concreta de columnas
- Mensaje humano (no técnico), con dodo 🦤 de forma ligera

## Interacción iPhone
- Pull-to-refresh en todas las pantallas
- Back iOS visible
- safe-area correcto
- Dark mode sin perder legibilidad
