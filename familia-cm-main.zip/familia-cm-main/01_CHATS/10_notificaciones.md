# Notificaciones

- Solo en PWA instalada
- Avisos: 1 día antes / 15 min antes
- Pedir permiso tras acción del usuario
- Requiere: SW + Web Push + backend/cron (bloque serio)
