# Rutinas 2.0

## Dónde vive
- Hoy: card compacta de Rutinas (arriba) con check rápido + “Ver todas”.
- Pantalla completa: `/routines`.

## Secciones
- Lun–Vie
- Sáb–Dom
- Semanales (deadline domingo)

## Reglas
- Asignar a Carlos/Davinia (multi select)
- Hecho por quién siempre visible
- Contador semanal: “te quedan X días”
- Rutinas diarias:
  - solo se marcan activas en su ventana (Lun–Vie o finde) para evitar marcar “domingo en martes”.

## UX (clave)
- Marcado rápido sin fricción:
  - selector “Marcando como: Davinia/Carlos” (chips D 🕊️ / C 🦅)
  - al marcar, queda “Hecho por” con chip sólido ✓ + C/D + ave.
- Asignación sin lío:
  - activar “Seleccionar”
  - elegir varias rutinas
  - “Asignar a…” (D/C) + Aplicar

## Visual
- chip C/D + 🦅/🕊️
- acento suave (borde lateral sutil según quién lo hizo)

## Persistencia (V1 local)
- localStorage:
  - `nido:routines:v1` (lista rutinas)
  - `nido:routine_completions:v1` (marcados por día/semana)
  - `nido:active_person:v1` (quién está marcando ahora)

## Nota futura (V2)
- Sync multiusuario real con Supabase (doneBy=userId, realtime opcional).
