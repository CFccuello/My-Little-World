# Medicación

- Niños:
  - Greta 20/06/2019
  - Máximo 13/09/2021
  - Roma 15/12/2023
- Cálculo con reglas definidas (seguridad)
- Registro: dosis + hora + hechoPor
- No estimar peso automáticamente
