# Electricidad (V1)

## Objetivo
Capturar lecturas de **kWh** de forma manual (sin fricción), con histórico.

## Estado actual
- Ruta: `/electricidad`
- Datos: localStorage (V1) — sin sincronización.
- Acceso:
  - tarjeta en `/familia`
  - link en navegación desktop

## Datos (V1)
- `dateISO` (YYYY-MM-DD)
- `kwh` (número)
- `note` (opcional)

## Qué falta / próxima iteración
1) Sincronización multi-dispositivo (Supabase)
2) Export CSV
3) Alertas / recordatorios (si queremos)