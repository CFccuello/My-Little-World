# Familia + Docs

## Familia
- perfiles con foto/emoji y edad

## Docs
- Carpetas por miembro
- “Familia” (solo admin) para Bancos
- “Garantías” → “Manuales / Instrucciones”
