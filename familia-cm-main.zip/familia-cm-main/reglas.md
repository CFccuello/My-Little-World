# REGLAS — NIDO

## 1) Tono y UX
- Texto corto, amable, cero juicio.
- Evitar palabras: “retrasado”, “fallaste”, “pendiente” (usar “por hacer”, “cuando puedas”).
- Microcopy recurrente de aves/pollitos. El dodo 🦤 aparece como humor amable.
- Máx 2–3 CTAs fuertes por pantalla.
- iPhone-first: safe-area, sin overflows, bottom nav no tapa contenido.

## 2) Roles y visibilidad
- Admin (Carlos):
  - Ve todo
  - Gestiona “Preferencias”
  - Ve “Familia/Bancos”
  - Configura notificaciones
- User (Davinia):
  - Usa el día a día
  - No edita estructura ni Preferencias avanzadas

## 3) Home / Hoy / Semana
- Home se entiende en 5 segundos:
  - Claim + Hoy dominante + Temas (Comida primero).
- Hoy NO incluye trabajo.
- Semana es base: resúmenes y próximos eventos.

## 4) Rutinas
- Tipos:
  - Diarias Lun–Vie
  - Diarias Sáb–Dom
  - Semanales (con deadline domingo)
- Cada item puede tener:
  - asignadoA: Carlos | Davinia | (ambos) | nadie
  - hechoPor: Carlos | Davinia | null
  - timestamp hecho
- Asignación:
  - multiselección + acción “Asignar a…”
- Hecho por:
  - se marca usando el selector “Marcando como: Davinia/Carlos”
  - siempre visible en UI (chip sólido ✓ + C/D + ave)
- Visual:
  - chip con inicial (C/D) + ave (🦅/🕊️)
  - acento suave (no saturar toda la fila)

## 5) Comida
- Slots fijos (mínimo):
  - Desayuno / Almuerzo / Comida / Merienda / Cena
- Por persona: Greta / Máximo / Roma / Familia
- Regla: si Carlos asigna, Davinia lo ve en Hoy/Home.

### Comedor (Monzón 3) — reglas V1
- El enlace al PDF se detecta desde `/api/comedor/monzon` (servidor) para evitar CORS.
- Se guarda en localStorage (`nido:comedor:monzon3:state`).
- Re-chequeo “suave”:
  - al abrir la app
  - al volver a primer plano
  - al pull-to-refresh
  - y como máximo cada 12h
- Ventana típica de publicación: entre el día 28 y el 4.

### Plantillas y copia día→día
- Plantillas rellenan título/nota (evita pensar y reduce carga).
- Copia día→día pide confirmación si el destino ya tiene datos.

## 6) Medicación (seguridad)
- No estimar peso automáticamente.
- Registrar siempre:
  - niño, peso (si aplica), medicamento, dosis, fecha/hora, hechoPor
- Cálculos solo con reglas definidas (mg/kg, máximos, intervalos) y con copy de seguridad.

## 7) Docs
- Carpetas por miembro + “Familia (admin)” para Bancos.
- “Garantías” se llama “Manuales / Instrucciones”.

## 8) Finanzas
- Import CSV debe dar feedback: “importando / listo / error”.
- Drag & drop además de selector.

## 9) Inspiración
- Captura por pegar enlace + nota.
- Conectar redes es opcional y no bloquea el uso.

## 10) Notificaciones
- Solo pedir permisos en el momento adecuado.
- Avisos configurables (1 día / 15 min).
- Nunca saturar a Davinia.

## 11) Electricidad
- V1: datos locales (localStorage) por simplicidad.
- Siempre dejar claro en UI: “esto no está sincronizado aún”.
