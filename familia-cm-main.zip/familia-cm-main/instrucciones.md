# INSTRUCCIONES — Cómo trabajamos NIDO

## Objetivo
Evitar el caos de múltiples versiones, cambios perdidos y “volver atrás”.

## Operaciones (cerrado)
1) **Chat: DESARROLLO NIDO — ÚNICO CHAT DE EJECUCIÓN**
   - Aquí se piden cambios y se entrega código.
   - Regla de oro: **archivos completos + rutas exactas** (copy/paste).
   - Cada bloque funcional termina con:
     - qué se consigue
     - archivos afectados
     - comandos git
     - checklist iPhone PWA

2) **Docs dentro del repo (fuente de verdad)**
   - Canon:
     - `state.md` (estado + URLs + stack + módulos + foco)
     - `decisiones.md` (decisiones cerradas)
     - `backlog.md` (prioridades)
     - `reglas.md` (reglas de negocio)
     - `instrucciones.md` (este documento)
   - “Tema” = documentación viva en `01_CHATS/*.md`.
   - **No se versionan chats exportados**: si hay que guardarlos, van a `99_ARCHIVOS/` (gitignored).

## Regla de documentación (obligatoria)
Después de cada bloque funcional:
- Actualizar `state.md`.
- Si se decide algo: añadirlo a `decisiones.md`.
- Si sale nuevo trabajo: `backlog.md`.
- Si aparece regla de negocio: `reglas.md`.
- Si afecta a un tema: actualizar `01_CHATS/*.md`.

## Flujo git recomendado
- Commits pequeños por feature (evitar megacommits).
- Antes de push, probar:
  - iPhone PWA (Add to Home Screen)
  - dark mode
  - safe-area + bottom nav no tapa
  - back iOS (flecha arriba izq)
  - pull-to-refresh

## Nota sobre iPhone PWA cache
Si no se ven cambios:
1) borrar PWA instalada
2) limpiar datos del sitio en Safari
3) reinstalar desde Safari (Add to Home Screen)

## Windows (CMD) — mini regla anti-estrés
- Si copias comandos y ves líneas que empiezan por `#`, **no las ejecutes** (eso es comentario de bash; en Windows CMD da error).
- Para comentar en CMD usa `REM`.

## Higiene del repo
- NO versionar `.obsidian/`.
- NO versionar `node_modules/` ni `.next/`.
- `package-lock.json` solo si usamos npm.
- Warnings LF/CRLF son normales en Windows.

---

## Contexto técnico (cerrado)
- Front: Next.js (App Router `/app`) + TypeScript.
- Deploy: Vercel.
- Backend: Supabase (Auth + DB + Storage).
- Auth: SOLO email+password, SOLO por invitación. Signups desactivados.
- Recovery: existe `/auth/reset`.
- Mobile-first: Davinia usa iPhone + PWA.

## Roles (cerrado)
- Admin: Carlos.
- User: Davinia.