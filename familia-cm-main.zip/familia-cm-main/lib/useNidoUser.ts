"use client";

import { useEffect, useMemo, useState } from "react";
import { isSupabaseConfigured, supabase } from "@/lib/supabaseClient";
import { getRoleFromEmail, type Role } from "@/lib/roles";

const ADMIN_EMAIL = (process.env.NEXT_PUBLIC_ADMIN_EMAIL ?? "").trim().toLowerCase();

export type NidoUser = {
  // Canon
  id: string | null;
  email: string | null;
  isAdmin: boolean;
  role: Role;
  demo: boolean;

  // Compat con componentes antiguos
  ready: boolean;
  userId: string | null;
};

export function useNidoUser(): NidoUser {
  const [id, setId] = useState<string | null>(null);
  const [email, setEmail] = useState<string | null>(null);
  const [ready, setReady] = useState<boolean>(false);

  useEffect(() => {
    if (!isSupabaseConfigured) {
      setReady(true);
      return;
    }

    let mounted = true;
    let initialResolved = false;

    const setFromSession = (session: any) => {
      if (!mounted) return;
      setId(session?.user?.id ?? null);
      setEmail(session?.user?.email ?? null);
      setReady(true);
    };

    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (!mounted) return;

      if (event === "INITIAL_SESSION") {
        initialResolved = true;
        setFromSession(session);
        return;
      }

      if (event === "SIGNED_IN" || event === "TOKEN_REFRESHED" || event === "USER_UPDATED") {
        setFromSession(session);
        return;
      }

      if (event === "SIGNED_OUT") {
        setId(null);
        setEmail(null);
        setReady(true);
      }
    });

    const t = window.setTimeout(async () => {
      if (!mounted) return;
      if (initialResolved) return;
      const { data } = await supabase.auth.getSession();
      setFromSession(data.session);
    }, 1200);

    return () => {
      mounted = false;
      window.clearTimeout(t);
      sub.subscription.unsubscribe();
    };
  }, []);

  const isAdmin = useMemo(() => {
    if (!isSupabaseConfigured) return true;
    if (!ADMIN_EMAIL) return true; // default seguro durante setup
    if (!email) return false;
    return email.toLowerCase() === ADMIN_EMAIL;
  }, [email]);

  const role = useMemo<Role>(() => getRoleFromEmail(email), [email]);

  return {
    id,
    email,
    isAdmin,
    role,
    demo: !isSupabaseConfigured,

    // Compat
    ready,
    userId: id,
  };
}
