import { lsGet, lsSet } from "@/lib/localStore";
import type { CalendarEvent } from "@/lib/types";

const KEY = "familiaCM:events";

function makeId() {
  try {
    // @ts-ignore
    if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
  } catch {}
  return `id_${Math.random().toString(16).slice(2)}${Date.now().toString(16)}`;
}

export function getEventsLocal(): CalendarEvent[] {
  return lsGet(KEY, [] as CalendarEvent[]);
}

export function upsertEventLocal(ev: Omit<CalendarEvent, "id"> & { id?: string }): CalendarEvent {
  const events = getEventsLocal();
  const id = ev.id ?? makeId();
  const next: CalendarEvent = { id, title: ev.title, startISO: ev.startISO, endISO: ev.endISO };
  const idx = events.findIndex((e) => e.id === id);
  const out = idx >= 0 ? events.map((e) => (e.id === id ? next : e)) : [...events, next];
  lsSet(KEY, out);
  return next;
}

export function deleteEventLocal(id: string): void {
  const events = getEventsLocal();
  lsSet(KEY, events.filter((e) => e.id !== id));
}
