import { addDays, addWeeks, format, nextDay, setHours, setMinutes, startOfDay } from "date-fns";
import { upsertEventLocal } from "@/lib/eventsStore";
import { lsGet, lsSet } from "@/lib/localStore";
import type { ChecklistItem, ChecklistKey } from "@/lib/types";

function makeId(): string {
  return `id_${Math.random().toString(16).slice(2)}${Date.now().toString(16)}`;
}

function listStorageKey(dateISO: string, listKey: ChecklistKey): string {
  return `familiaCM:checklist:${dateISO}:${listKey}`;
}

function pushItems(dateISO: string, listKey: ChecklistKey, texts: string[]) {
  const key = listStorageKey(dateISO, listKey);
  const existing = lsGet<ChecklistItem[]>(key, []);
  const have = new Set(existing.map((x) => x.text.trim().toLowerCase()));
  const next = [...existing];
  for (const t of texts) {
    const norm = t.trim().toLowerCase();
    if (!norm) continue;
    if (have.has(norm)) continue;
    next.push({ id: makeId(), text: t, done: false });
    have.add(norm);
  }
  lsSet(key, next);
}

function dt(dateISO: string, hhmm: string): Date {
  const [h, m] = hhmm.split(":").map((x) => Number(x));
  const base = startOfDay(new Date(`${dateISO}T12:00:00`));
  return setMinutes(setHours(base, h), m);
}

/**
 * Carga eventos del cole/extraescolares (Familia) en el calendario local.
 * - Lunes: Mis Manitas (Greta) 16:15–18:15
 * - Martes/Jueves: Atletismo (Greta) 15:40–17:00
 * - Viernes: Kids&Us Lleida (Greta+Máximo) 17:10–20:00
 */
export function seedSchoolEvents(weeksForward = 8) {
  const today = new Date();
  const start = startOfDay(today);

  for (let w = 0; w < weeksForward; w++) {
    const base = addWeeks(start, w);
    const mon = nextDay(base, 1);
    const tue = nextDay(base, 2);
    const thu = nextDay(base, 4);
    const fri = nextDay(base, 5);

    upsertEventLocal({
      title: "Greta · Mis Manitas",
      startISO: dt(format(mon, "yyyy-MM-dd"), "16:15").toISOString(),
      endISO: dt(format(mon, "yyyy-MM-dd"), "18:15").toISOString(),
    });

    for (const d of [tue, thu]) {
      upsertEventLocal({
        title: "Greta · Atletismo",
        startISO: dt(format(d, "yyyy-MM-dd"), "15:40").toISOString(),
        endISO: dt(format(d, "yyyy-MM-dd"), "17:00").toISOString(),
      });
    }

    upsertEventLocal({
      title: "Kids&Us Lleida · Greta + Máximo (salir 17:10)",
      startISO: dt(format(fri, "yyyy-MM-dd"), "17:10").toISOString(),
      endISO: dt(format(fri, "yyyy-MM-dd"), "20:00").toISOString(),
    });
  }
}

/**
 * Carga tareas periódicas en las 3 checklists (Trabajo / Carlos / Casa&Familia)
 * para los próximos N días.
 */
export function seedRecurringChecklists(daysForward = 7) {
  for (let i = 0; i < daysForward; i++) {
    const d = addDays(new Date(), i);
    const dateISO = format(d, "yyyy-MM-dd");

    // Trabajo (ejemplos de foco)
    pushItems(dateISO, "work", [
      "Bloque 1 · análisis / informe (90 min)",
      "Bloque 2 · limpieza de datos / automatización (60 min)",
      "Cierre · dejar preparado mañana (15 min)",
    ]);

    // Carlos
    pushItems(dateISO, "carlos", [
      "Gym 1h",
      "Perros (flexible: 12–13 o 20–21)",
      "Higiene del sueño (pantallas fuera 30 min antes)",
    ]);

    // Casa & Familia
    pushItems(dateISO, "home_family", [
      "Mañana · sacar lavavajillas",
      "Mañana · meter lo sucio en lavavajillas",
      "Mañana · recoger comedor/cocina",
      "Mañana · hacer camas",
      "Mañana · abrir ventanas habitaciones",
      "Lavadora niños (mañana) · 30°C · 1200rpm · intensivo · detergente que toca",
      "Lavadora adultos (mañana) · 30°C · 1200rpm · intensivo · detergente que toca",
      "21:00 · baños (bayeta)",
      "21:00 · limpiar cocina",
      "21:00 · fiambreras / baberos / botellas",
    ]);

    // Bloque tarde niños (si quieres verlo como checklist)
    pushItems(dateISO, "home_family", [
      "18:30 · baño niños",
      "19:15 · cena niños",
      "20:00 · dormir niños",
    ]);
  }

  // Domingos (semanal)
  for (let w = 0; w < 6; w++) {
    const base = addWeeks(new Date(), w);
    const sun = nextDay(base, 0);
    const dateISO = format(sun, "yyyy-MM-dd");
    pushItems(dateISO, "home_family", [
      "Dom 09:00 · cambiar sábanas",
      "Dom 09:00 · lavadora+secadora trapos/toallas/albornoces",
      "Dom 09:00 · aspirar habitaciones",
    ]);
  }

  // Trapos/toallas 2 veces más por semana (Mié + Sáb)
  for (let w = 0; w < 6; w++) {
    const base = addWeeks(new Date(), w);
    const wed = nextDay(base, 3);
    const sat = nextDay(base, 6);
    for (const d of [wed, sat]) {
      const dateISO = format(d, "yyyy-MM-dd");
      pushItems(dateISO, "home_family", [
        "Lavadora+secadora trapos/toallas (mañana) · 30°C · 1200rpm · intensivo",
      ]);
    }
  }
}
