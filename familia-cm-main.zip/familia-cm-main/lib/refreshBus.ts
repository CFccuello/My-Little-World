"use client";

/**
 * NIDO global refresh bus.
 *
 * We use it to trigger background checks on pull-to-refresh without
 * coupling those checks to each individual page component.
 */

const EVENT_NAME = "nido:refresh";

export function triggerNidoRefresh(detail?: unknown) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail }));
}

export function onNidoRefresh(handler: () => void | Promise<void>) {
  if (typeof window === "undefined") return () => {};
  const listener = () => {
    try {
      void handler();
    } catch {
      // best effort
    }
  };
  window.addEventListener(EVENT_NAME, listener);
  return () => window.removeEventListener(EVENT_NAME, listener);
}
