import {
  CalendarCheck2,
  Utensils,
  Pill,
  UsersRound,
  Folder,
  Sparkles,
  ListTodo,
  CheckCircle2,
  Settings,
  Wallet,
  HeartPulse,
  Dumbbell,
} from "lucide-react";

export const ICONS = {
  today: CalendarCheck2,
  comida: Utensils,
  medicacion: Pill,
  familia: UsersRound,
  docs: Folder,
  inspiracion: Sparkles,
  tareas: ListTodo,
  rutina: CheckCircle2,
  ajustes: Settings,
  finanzas: Wallet,
  bienestar: HeartPulse,
  actividad: Dumbbell,
};
