import { differenceInCalendarDays, endOfWeek, format, parseISO, startOfWeek } from "date-fns";

/**
 * Rutinas 2.0 (V1 local)
 * - Secciones: Lun–Vie / Sáb–Dom / Semanales
 * - Hecho por: Carlos/Davinia
 * - Asignación: Carlos/Davinia (multi-select)
 * - Persistencia: localStorage
 */

export type PersonKey = "carlos" | "davinia";

export type RoutineSection = "weekday" | "weekend" | "weekly";

export type Routine2 = {
  id: string;
  label: string;
  section: RoutineSection;
  /** Order within its section. */
  sort: number;
  /** Optional assignment. Empty means "anyone". */
  assignedTo: PersonKey[];
};

export type DoneMeta = {
  doneBy: PersonKey;
  doneAt: number; // epoch ms
};

export type CompletionScope =
  | { kind: "daily"; key: string } // key = YYYY-MM-DD
  | { kind: "weekly"; key: string }; // key = YYYY-MM-DD (Monday of the week)

export type RoutineCompletions = Record<string, DoneMeta>; // `${kind}:${key}:${routineId}`

export const LS_ROUTINES = "nido:routines:v1";
export const LS_COMPLETIONS = "nido:routine_completions:v1";
export const LS_ACTIVE_PERSON = "nido:active_person:v1";

export function isoToday(): string {
  return format(new Date(), "yyyy-MM-dd");
}

export function isWeekendDate(dateISO: string): boolean {
  const d = parseISO(dateISO);
  const day = d.getDay();
  return day === 0 || day === 6;
}

export function getWeekKey(dateISO: string): string {
  // Week starts Monday.
  const d = parseISO(dateISO);
  const start = startOfWeek(d, { weekStartsOn: 1 });
  return format(start, "yyyy-MM-dd");
}

export function getSundayISO(dateISO: string): string {
  const d = parseISO(dateISO);
  const end = endOfWeek(d, { weekStartsOn: 1 }); // Sunday
  return format(end, "yyyy-MM-dd");
}

export function daysRemainingToSunday(dateISO: string): number {
  const d = parseISO(dateISO);
  const end = endOfWeek(d, { weekStartsOn: 1 });
  return Math.max(0, differenceInCalendarDays(end, d));
}

export function scopeKeyForToday(section: RoutineSection, dateISO: string): CompletionScope {
  if (section === "weekly") {
    return { kind: "weekly", key: getWeekKey(dateISO) };
  }
  return { kind: "daily", key: dateISO };
}

export function completionId(scope: CompletionScope, routineId: string): string {
  return `${scope.kind}:${scope.key}:${routineId}`;
}

export function getActiveSectionForDate(dateISO: string): "weekday" | "weekend" {
  return isWeekendDate(dateISO) ? "weekend" : "weekday";
}

export function seedRoutines2(): Routine2[] {
  // V1 seed: simple, home-first, low cognitive load.
  // (Davinia no edita estructura; esto se puede ajustar en próximos commits.)
  const out: Routine2[] = [
    // Lun–Vie
    { id: "dishwasher_empty", label: "Vaciar lavavajillas", section: "weekday", sort: 10, assignedTo: [] },
    { id: "dishwasher_load", label: "Meter lo sucio / ponerlo", section: "weekday", sort: 20, assignedTo: [] },
    { id: "kitchen_reset", label: "Cocina en modo rápido", section: "weekday", sort: 30, assignedTo: [] },
    { id: "beds", label: "Hacer camas", section: "weekday", sort: 40, assignedTo: [] },
    { id: "ventilate", label: "Ventilar 5 min", section: "weekday", sort: 50, assignedTo: [] },

    // Sáb–Dom
    { id: "sheets", label: "Sábanas / fundas (si toca)", section: "weekend", sort: 10, assignedTo: [] },
    { id: "laundry", label: "Lavadora (una) y fuera", section: "weekend", sort: 20, assignedTo: [] },
    { id: "fridge_reset", label: "Nevera: tirar 3 cosas", section: "weekend", sort: 30, assignedTo: [] },
    { id: "toys_reset", label: "Juguetes: reset 5 min", section: "weekend", sort: 40, assignedTo: [] },

    // Semanales (deadline domingo)
    { id: "menu_week", label: "Plan mini-menú de la semana", section: "weekly", sort: 10, assignedTo: [] },
    { id: "shopping", label: "Compra base (lo imprescindible)", section: "weekly", sort: 20, assignedTo: [] },
    { id: "bins", label: "Basura reciclaje (papel/vidrio)", section: "weekly", sort: 30, assignedTo: [] },
  ];

  return out;
}

export function loadRoutines2(): Routine2[] {
  if (typeof window === "undefined") return seedRoutines2();
  try {
    const raw = window.localStorage.getItem(LS_ROUTINES);
    if (!raw) return seedRoutines2();
    const parsed = JSON.parse(raw) as Routine2[];

    if (!Array.isArray(parsed) || parsed.length === 0) return seedRoutines2();

    // Basic hygiene: ensure assignedTo is always an array.
    return parsed.map((r) => ({
      ...r,
      assignedTo: Array.isArray((r as any).assignedTo) ? (r as any).assignedTo : [],
    }));
  } catch {
    return seedRoutines2();
  }
}

export function saveRoutines2(routines: Routine2[]): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(LS_ROUTINES, JSON.stringify(routines));
  } catch {
    // ignore
  }
}

export function loadCompletions2(): RoutineCompletions {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(LS_COMPLETIONS);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as RoutineCompletions;
    if (!parsed || typeof parsed !== "object") return {};
    return parsed;
  } catch {
    return {};
  }
}

export function saveCompletions2(map: RoutineCompletions): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(LS_COMPLETIONS, JSON.stringify(map));
  } catch {
    // ignore
  }
}

export function loadActivePerson(): PersonKey {
  if (typeof window === "undefined") return "davinia";
  try {
    const raw = window.localStorage.getItem(LS_ACTIVE_PERSON);
    if (raw === "carlos" || raw === "davinia") return raw;
    return "davinia";
  } catch {
    return "davinia";
  }
}

export function saveActivePerson(p: PersonKey): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(LS_ACTIVE_PERSON, p);
  } catch {
    // ignore
  }
}

export function routineDone(
  completions: RoutineCompletions,
  section: RoutineSection,
  routineId: string,
  dateISO: string
): DoneMeta | null {
  const scope = scopeKeyForToday(section, dateISO);
  const key = completionId(scope, routineId);
  return completions[key] ?? null;
}

export function setRoutineDone(
  completions: RoutineCompletions,
  section: RoutineSection,
  routineId: string,
  dateISO: string,
  doneBy: PersonKey,
  value: boolean
): RoutineCompletions {
  const scope = scopeKeyForToday(section, dateISO);
  const key = completionId(scope, routineId);

  const next: RoutineCompletions = { ...completions };
  if (value) {
    next[key] = { doneBy, doneAt: Date.now() };
  } else {
    delete next[key];
  }
  return next;
}

export function sortRoutines(routines: Routine2[]): Routine2[] {
  return [...routines].sort((a, b) => {
    if (a.section !== b.section) return a.section.localeCompare(b.section);
    if (a.sort !== b.sort) return a.sort - b.sort;
    return a.label.localeCompare(b.label);
  });
}

export function formatAssignees(assignedTo: PersonKey[]): string {
  if (!assignedTo || assignedTo.length === 0) return "Sin asignar";
  const norm = [...assignedTo].sort();
  return norm.map((p) => (p === "carlos" ? "Carlos" : "Davinia")).join(" + ");
}
