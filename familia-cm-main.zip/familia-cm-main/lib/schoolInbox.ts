"use client";

import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";

export type SchoolInboxStatus = "new" | "processed" | "archived";

export type SchoolInboxItem = {
  id: string;
  created_at: string;
  source_message_date: string | null;
  source_chat_title: string | null;
  from_name: string | null;
  text_raw: string | null;
  attachments: any[];
  parsed_importance: "low" | "normal" | "high";
  parsed_category: string | null;
  parsed_summary: string | null;
  parsed_json: any;
  status: SchoolInboxStatus;
};

export type SchoolAction = {
  id?: string;
  inbox_id?: string | null;
  type: "task" | "event";
  title: string;
  details?: string | null;
  due_at?: string | null;
  start_at?: string | null;
  status?: "suggested" | "confirmed" | "dismissed" | "done";
  importance?: "low" | "normal" | "high";
};

export async function listInbox(params?: { status?: SchoolInboxStatus; limit?: number }): Promise<SchoolInboxItem[]> {
  if (!isSupabaseConfigured) return [];

  const status = params?.status;
  const limit = params?.limit ?? 80;

  let q = supabase
    .from("school_inbox_items")
    .select(
      "id,created_at,source_message_date,source_chat_title,from_name,text_raw,attachments,parsed_importance,parsed_category,parsed_summary,parsed_json,status",
    )
    .order("source_message_date", { ascending: false })
    .limit(limit);

  if (status) q = q.eq("status", status);

  const { data, error } = await q;
  if (error) throw error;
  return (data ?? []) as SchoolInboxItem[];
}

export async function countNew(): Promise<number> {
  if (!isSupabaseConfigured) return 0;

  const { count, error } = await supabase
    .from("school_inbox_items")
    .select("id", { count: "exact", head: true })
    .eq("status", "new");

  if (error) throw error;
  return count ?? 0;
}

export async function setStatus(id: string, status: SchoolInboxStatus): Promise<void> {
  if (!isSupabaseConfigured) return;

  const { error } = await supabase
    .from("school_inbox_items")
    .update({ status })
    .eq("id", id);

  if (error) throw error;
}

export async function createAction(action: SchoolAction): Promise<void> {
  if (!isSupabaseConfigured) return;

  const { error } = await supabase.from("school_actions").insert({
    inbox_id: action.inbox_id ?? null,
    type: action.type,
    title: action.title,
    details: action.details ?? null,
    due_at: action.due_at ?? null,
    start_at: action.start_at ?? null,
    status: action.status ?? "suggested",
    importance: action.importance ?? "normal",
  });

  if (error) throw error;
}
