// lib/roles.ts

export type Role = "admin" | "user";

/**
 * Single source of truth for roles.
 * V1 rule: only two roles.
 * - Admin: Carlos (by email match)
 * - User: everyone else (Davinia)
 */
export function getRoleFromEmail(email: string | null | undefined): Role {
  const adminEmail = (process.env.NEXT_PUBLIC_ADMIN_EMAIL ?? "").trim().toLowerCase();
  const e = (email ?? "").trim().toLowerCase();

  // Safe default:
  // - if env is missing, we assume admin to avoid hiding admin tools during setup
  if (!adminEmail) return "admin";
  if (!e) return "user";

  return e === adminEmail ? "admin" : "user";
}

export function roleLabel(role: Role): string {
  return role === "admin" ? "Admin" : "User";
}
