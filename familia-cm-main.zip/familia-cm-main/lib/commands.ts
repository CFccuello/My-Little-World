import { addDays, addWeeks, format, parseISO, startOfDay, startOfWeek } from "date-fns";
import { upsertEventLocal } from "@/lib/eventsStore";
import { lsGet, lsSet } from "@/lib/localStore";
import type { ChecklistItem, ChecklistKey } from "@/lib/types";

type CommandAction =
  | { kind: "none"; message: string }
  | { kind: "task"; listKey: ChecklistKey; dateISO: string; text: string }
  | { kind: "event"; title: string; startISO: string; endISO: string; recur?: { freq: "weekly"; byDay: number; weeks: number } }
  | { kind: "reminder"; text: string; everyHours: number };

const CATEGORY_TO_LIST: Record<string, ChecklistKey> = {
  trabajo: "work",
  work: "work",
  carlos: "carlos",
  casa: "home_family",
  familia: "home_family",
  "casa&familia": "home_family",
  "casa y familia": "home_family",
};

function makeId() {
  try {
    // @ts-ignore
    if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
  } catch {}
  return `id_${Math.random().toString(16).slice(2)}${Date.now().toString(16)}`;
}

function parseTimeHHMM(s: string): { h: number; m: number } | null {
  const m = s.match(/\b(\d{1,2}):(\d{2})\b/);
  if (!m) return null;
  const h = Number(m[1]);
  const mi = Number(m[2]);
  if (h < 0 || h > 23 || mi < 0 || mi > 59) return null;
  return { h, m: mi };
}

function parseTodayTomorrow(text: string, base: Date): Date {
  const t = text.toLowerCase();
  if (t.includes("mañana")) return addDays(base, 1);
  return base;
}

function parseWeekday(text: string, base: Date): number | null {
  const t = text.toLowerCase();
  const map: Record<string, number> = {
    lunes: 1,
    martes: 2,
    miércoles: 3,
    miercoles: 3,
    jueves: 4,
    viernes: 5,
    sábado: 6,
    sabado: 6,
    domingo: 0,
  };
  for (const k of Object.keys(map)) {
    if (t.includes(k)) return map[k];
  }
  return null;
}

function nextWeekday(base: Date, byDay: number): Date {
  // JS: 0 Sunday..6 Saturday. We treat week start Monday for planner.
  const d0 = startOfDay(base);
  const current = d0.getDay();
  let delta = (byDay - current + 7) % 7;
  if (delta === 0) delta = 7; // next occurrence
  return addDays(d0, delta);
}

export function parseCommand(inputRaw: string, now = new Date()): CommandAction {
  const input = inputRaw.trim();
  if (!input) return { kind: "none", message: "Escribe o dicta un comando." };

  const lower = input.toLowerCase();

  // 1) Tarea <Categoria> <fecha> <hora>: <texto>
  // Ej: "Tarea Trabajo hoy 19:00: Informe Zespri"
  if (lower.startsWith("tarea")) {
    const parts = input.split(":");
    const head = parts[0];
    const text = parts.slice(1).join(":").trim();
    if (!text) return { kind: "none", message: "Falta el texto de la tarea (después de ':')." };

    const catMatch = head.match(/^tarea\s+([^\s]+(?:\s*&\s*[^\s]+)?)\s*/i);
    const catRaw = (catMatch?.[1] ?? "casa&familia").toLowerCase();
    const listKey = CATEGORY_TO_LIST[catRaw] ?? "home_family";

    const date = parseTodayTomorrow(head, now);
    const dateISO = format(date, "yyyy-MM-dd");
    return { kind: "task", listKey, dateISO, text };
  }

  // 2) Añade a <Categoria>: <texto>
  if (lower.startsWith("añade") || lower.startsWith("anade")) {
    const parts = input.split(":");
    const head = parts[0];
    const text = parts.slice(1).join(":").trim();
    const m = head.match(/añade\s+a\s+(.+)$/i) || head.match(/anade\s+a\s+(.+)$/i);
    const catRaw = (m?.[1] ?? "casa&familia").toLowerCase();
    const listKey = CATEGORY_TO_LIST[catRaw] ?? "home_family";
    const dateISO = format(now, "yyyy-MM-dd");
    if (!text) return { kind: "none", message: "Falta el texto (después de ':')." };
    return { kind: "task", listKey, dateISO, text };
  }

  // 3) Evento <Categoria> (hoy/mañana/<día>) <hora>: <título>
  // Ej: "Evento Familia hoy 18:10: Kids&Us"
  if (lower.startsWith("evento")) {
    const parts = input.split(":");
    const head = parts[0];
    const title = parts.slice(1).join(":").trim();
    if (!title) return { kind: "none", message: "Falta el título del evento (después de ':')." };

    // recurrencia: "todos los domingos"
    const isEvery = lower.includes("todos los") || lower.includes("todas las");
    const byDay = parseWeekday(lower, now);

    const time = parseTimeHHMM(head) ?? { h: 10, m: 0 };
    let date = parseTodayTomorrow(head, now);
    if (byDay !== null && isEvery) {
      date = nextWeekday(now, byDay);
    } else if (byDay !== null && !lower.includes("hoy") && !lower.includes("mañana")) {
      // "evento ... viernes" -> próximo
      date = nextWeekday(now, byDay);
    }

    const start = new Date(date);
    start.setHours(time.h, time.m, 0, 0);
    const end = new Date(start);
    end.setMinutes(end.getMinutes() + 60);

    return {
      kind: "event",
      title,
      startISO: start.toISOString(),
      endISO: end.toISOString(),
      ...(isEvery && byDay !== null ? { recur: { freq: "weekly" as const, byDay, weeks: 12 } } : {}),
    };
  }

  // 4) Recordatorio Salud cada 8h: medicación
  if (lower.startsWith("recordatorio")) {
    const parts = input.split(":");
    const head = parts[0].toLowerCase();
    const text = parts.slice(1).join(":").trim();
    const m = head.match(/cada\s+(\d+)h/);
    const everyHours = m ? Number(m[1]) : 8;
    if (!text) return { kind: "none", message: "Falta el texto del recordatorio (después de ':')." };
    return { kind: "reminder", text, everyHours };
  }

  return { kind: "none", message: "No lo he entendido. Usa: Tarea…, Evento…, Recordatorio…, Añade a…." };
}

export function applyCommand(cmd: CommandAction): { ok: boolean; message: string } {
  if (cmd.kind === "none") return { ok: false, message: cmd.message };

  if (cmd.kind === "task") {
    const storageKey = `familiaCM:checklist:${cmd.dateISO}:${cmd.listKey}`;
    const items = lsGet(storageKey, [] as ChecklistItem[]);
    const next = [...items, { id: makeId(), text: cmd.text, done: false }];
    lsSet(storageKey, next);
    return { ok: true, message: `Tarea añadida en ${cmd.listKey} (${cmd.dateISO}).` };
  }

  if (cmd.kind === "event") {
    upsertEventLocal({ title: cmd.title, startISO: cmd.startISO, endISO: cmd.endISO });
    if (cmd.recur) {
      // crear ocurrencias futuras (12 semanas) para poder probar semana/mes
      let cursor = parseISO(cmd.startISO);
      for (let i = 0; i < cmd.recur.weeks - 1; i++) {
        cursor = addWeeks(cursor, 1);
        const s = new Date(cursor);
        const e = new Date(cursor);
        e.setTime(parseISO(cmd.endISO).getTime() + (cursor.getTime() - parseISO(cmd.startISO).getTime()));
        upsertEventLocal({ title: cmd.title, startISO: s.toISOString(), endISO: e.toISOString() });
      }
    }
    return { ok: true, message: "Evento guardado." };
  }

  if (cmd.kind === "reminder") {
    // MVP: lo guardamos como tarea en Carlos para hoy
    const dateISO = format(new Date(), "yyyy-MM-dd");
    const storageKey = `familiaCM:checklist:${dateISO}:carlos`;
    const items = lsGet(storageKey, [] as ChecklistItem[]);
    const next = [...items, { id: makeId(), text: `⏱️ Cada ${cmd.everyHours}h: ${cmd.text}`, done: false }];
    lsSet(storageKey, next);
    return { ok: true, message: "Recordatorio guardado (MVP: checklist Carlos)." };
  }

  return { ok: false, message: "Acción no soportada." };
}
