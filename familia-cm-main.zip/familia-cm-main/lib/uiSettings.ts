// Available theme identifiers. Each theme corresponds to a palette defined in
// `app/globals.css`. We simplified the list to the six themes agreed with
// Davinia and Carlos. See `globals.css` for the corresponding CSS variables.
export type ThemeId =
  | "calm-sand"
  | "blue-order"
  | "green-health"
  | "pink-home"
  | "graphite-focus"
  | "lavender-calm";

export type ModeId = "auto" | "light" | "dark";

// Home layout variants. These are visual-only (no business logic changes).
// They exist so Carlos can preview 5 different UI directions and pick the one
// Davinia likes the most.
export type HomeLayoutId = "bento" | "glass" | "story" | "control" | "warm";

export type UiSettings = {
  theme: ThemeId;
  mode: ModeId;
  homeLayout: HomeLayoutId;
  todayChecklists: string[]; // ids
};

const KEY = "nido:ui";

// Default UI settings. The default theme is `calm-sand` and the default mode
// follows the operating system (`auto`). If Davinia uses the app at night
// the dark palette will be applied automatically.
export const DEFAULT_UI: UiSettings = {
  theme: "calm-sand",
  mode: "auto",
  homeLayout: "bento",
  todayChecklists: ["mi-dia", "casa-peques", "rutina"],
};

export function loadUi(): UiSettings {
  if (typeof window === "undefined") return DEFAULT_UI;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_UI;
    const parsed = JSON.parse(raw) as Partial<UiSettings>;
    const homeLayout =
      parsed.homeLayout === "bento" ||
      parsed.homeLayout === "glass" ||
      parsed.homeLayout === "story" ||
      parsed.homeLayout === "control" ||
      parsed.homeLayout === "warm"
        ? parsed.homeLayout
        : DEFAULT_UI.homeLayout;
    return {
      ...DEFAULT_UI,
      ...parsed,
      homeLayout,
      todayChecklists: Array.isArray(parsed.todayChecklists) ? parsed.todayChecklists : DEFAULT_UI.todayChecklists,
    };
  } catch {
    return DEFAULT_UI;
  }
}

export function saveUi(next: UiSettings) {
  if (typeof window === "undefined") return;
  localStorage.setItem(KEY, JSON.stringify(next));
}

export function applyUiToHtml(ui: UiSettings) {
  if (typeof document === "undefined") return;
  const html = document.documentElement;
  html.dataset.theme = ui.theme;
  html.dataset.mode = ui.mode;
  html.dataset.homeLayout = ui.homeLayout;
}
