import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

export const isSupabaseConfigured = Boolean(url && anon);

export const supabase = (() => {
  if (!isSupabaseConfigured) {
    // Demo/offline mode: client still exists but calls will fail.
    return createClient("http://localhost:54321", "anon", { auth: { persistSession: false } });
  }
  // NIDO: keep sessions alive across refreshes / PWA restarts.
  return createClient(url!, anon!, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
  });
})();
