export type Bird = {
  id: string;
  name: string;
  emoji: string;
  note: string;
};

const BIRDS: Bird[] = [
  { id: "petirrojo", name: "Petirrojo", emoji: "🐦", note: "Pequeño, constante." },
  { id: "mirlo", name: "Mirlo", emoji: "🐤", note: "Calma y rutina." },
  { id: "golondrina", name: "Golondrina", emoji: "🕊️", note: "Ligereza." },
  { id: "herrerillo", name: "Herrerillo", emoji: "🐦", note: "Orden simple." },
  { id: "jilguero", name: "Jilguero", emoji: "🐦", note: "Un detalle alegre." },
  { id: "ciguena", name: "Cigüeña", emoji: "🪽", note: "Lo importante llega." },
  { id: "buho", name: "Búho", emoji: "🦉", note: "Claridad." },
  { id: "ruisenor", name: "Ruiseñor", emoji: "🎶", note: "Un momento bonito." },
  { id: "gaviota", name: "Gaviota", emoji: "🌊", note: "Respira." },
  { id: "verderon", name: "Verderón", emoji: "🌿", note: "Salud primero." },
  { id: "urraca", name: "Urraca", emoji: "✨", note: "Lo pequeño cuenta." },
  { id: "carbonero", name: "Carbonero", emoji: "🐦", note: "Paso a paso." },
];

const LS_LAST_SEEN_DATE = "nido:onboarding:bird:last_seen_date";
const LS_LAST_BIRD_ID = "nido:onboarding:bird:ave_id";

export function isoToday(): string {
  const d = new Date();
  return d.toISOString().slice(0, 10);
}

function hashToIndex(input: string, modulo: number): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h) % modulo;
}

export function getBirdOfDay(dateISO: string = isoToday()): Bird {
  const idx = hashToIndex(dateISO, BIRDS.length);
  return BIRDS[idx] || BIRDS[0];
}

export function getBirdOnboardingState(): { lastSeenDate: string | null; lastBirdId: string | null } {
  if (typeof window === "undefined") return { lastSeenDate: null, lastBirdId: null };
  return {
    lastSeenDate: window.localStorage.getItem(LS_LAST_SEEN_DATE),
    lastBirdId: window.localStorage.getItem(LS_LAST_BIRD_ID),
  };
}

export function markBirdSeen(dateISO: string, birdId: string) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(LS_LAST_SEEN_DATE, dateISO);
  window.localStorage.setItem(LS_LAST_BIRD_ID, birdId);
}

export function shouldShowBirdOverlay(dateISO: string = isoToday()): boolean {
  const st = getBirdOnboardingState();
  // Show on first entry and then once per day.
  return st.lastSeenDate !== dateISO;
}
