import type { ScheduleBlock, Settings, ColorKey } from "@/lib/types";

function toMinutes(hhmm: string): number {
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + m;
}
function fromMinutes(mins: number): string {
  const h = Math.floor(mins / 60) % 24;
  const m = mins % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}
function durMin(start: string, end: string): number {
  return Math.max(0, toMinutes(end) - toMinutes(start));
}

export function defaultSettings(): Settings {
  return {
    id: "local",
    tz: "Europe/Madrid",
    work_min_hours: 8,
    dogs_minutes: 60,
    gym_minutes: 60,
    meal_minutes: 30,
    family_start_evening: "17:30",
    dogs_start: "06:00",
    sleep_start: "22:00",
    sleep_end: "05:00"
  };
}

export function buildDefaultSchedule(settings: Settings, dateISO: string): { blocks: ScheduleBlock[]; warnings: string[] } {
  const warnings: string[] = [];

  const dogsStart = settings.dogs_start; // e.g. 06:00
  const dogsEnd = fromMinutes(toMinutes(dogsStart) + settings.dogs_minutes);

  const sleepEnd = settings.sleep_end;   // e.g. 05:00
  const sleepStart = settings.sleep_start; // e.g. 22:00

  // Fixed day blocks (based on Carlos constraints)
  const blocks: ScheduleBlock[] = [];

  const push = (id: string, color: ColorKey, label: string, start: string, end: string, notes?: string) => {
    blocks.push({ id, color, label, start, end, notes });
  };

  // Sueño / desconexión son "Carlos"
  push("sleep", "carlos", "Sueño", sleepStart, "24:00");
  push("sleep2", "carlos", "Sueño", "00:00", sleepEnd);

  // Early work to reach 8h without robar familia
  const earlyWorkStart = sleepEnd;
  const earlyWorkEnd = dogsStart;
  if (durMin(earlyWorkStart, earlyWorkEnd) > 0) {
    push("work-early", "work", "Trabajo (datos/informes) — bloque temprano", earlyWorkStart, earlyWorkEnd, "Objetivo: avanzar el entregable antes de que empiece el día.");
  } else {
    warnings.push("No hay hueco para trabajo temprano (sueño/horarios).");
  }

  // Perros (dentro de Familia)
  push("dogs", "family", "Perros (1h)", dogsStart, dogsEnd);

  // Family morning (assumed)
  push("family-am", "family", "Familia (mañana)", dogsEnd, "08:00");

  // Morning routine turbo (30m)
  push("home-am", "home", "Rutina mañana (modo turbo)", "08:00", "08:30", "Lavavajillas + cocina/comedor + camas + ventanas.");
  // Medication reminder inside health block (3m)
  push("meds", "health", "Medicación (recordatorio)", "08:30", "08:33", "Loniten 0,5 diario. Dutasteride día sí/día no (según pauta).");

  // Work morning deep
  push("work-1", "work", "Trabajo profundo (Prioridad #1)", "08:33", "12:33");

  // Gym
  const gymStart = "12:33";
  const gymEnd = fromMinutes(toMinutes(gymStart) + settings.gym_minutes);
  push("gym", "health", "Gym (1h)", gymStart, gymEnd);

  // Work mid (short)
  push("work-2", "work", "Trabajo (pipeline / validación)", gymEnd, "14:00");

  // Comida con Pareja
  const mealStart = "14:00";
  const mealEnd = fromMinutes(toMinutes(mealStart) + settings.meal_minutes);
  push("meal", "partner", "Comida con Pareja (30m)", mealStart, mealEnd);

  // Buffer + pickup (fixed)
  push("buffer-1", "carlos", "Carlos / transición", mealEnd, "14:40");
  push("pickup", "family", "Recogida niños (1h20)", "14:40", "16:00");

  // Work until family start
  push("work-3", "work", "Trabajo profundo (Prioridad #2/#3)", "16:00", settings.family_start_evening);

  // Family evening
  push("family-pm", "family", "Familia (tarde)", settings.family_start_evening, "20:00");

  // Night routine
  push("home-night", "home", "Rutina noche", "20:00", "20:45",
    "Coche al garaje + cargar + cocina + baberos/botellas + preparar mañana + 5 min check-in en pareja.");

  // Evening work (1h) to reach min 8h
  const eveningWorkStart = "20:45";
  const eveningWorkEnd = fromMinutes(toMinutes(eveningWorkStart) + 60);
  if (toMinutes(eveningWorkEnd) <= toMinutes(sleepStart)) {
    push("work-evening", "work", "Trabajo (cierre)", eveningWorkStart, eveningWorkEnd, "Cerrar y dejar el primer paso de mañana preparado.");
  } else {
    warnings.push("No cabe el bloque de trabajo nocturno antes de la hora de dormir.");
  }

  // Desconexión
  push("winddown", "carlos", "Desconexión", eveningWorkEnd, sleepStart);

  // Validate min hours of work
  const workMinutes = blocks
    .filter(b => b.color === "work")
    .reduce((acc, b) => acc + durMin(b.start, b.end), 0);
  const required = settings.work_min_hours * 60;
  if (workMinutes < required) {
    warnings.push(`Trabajo planificado: ${(workMinutes/60).toFixed(2)}h < ${settings.work_min_hours}h. Para cumplir, habrá que recortar sueño o mover gym/familia.`);
  }

  // Sort blocks by time (simple stable sort using start)
  const norm = (t: string) => (t === "24:00" ? 24*60 : toMinutes(t));
  blocks.sort((a,b) => norm(a.start) - norm(b.start));

  return { blocks, warnings };
}

export function totalsByColor(blocks: ScheduleBlock[]): Record<string, number> {
  const out: Record<string, number> = {};
  for (const b of blocks) {
    const mins = durMin(b.start, b.end);
    out[b.color] = (out[b.color] ?? 0) + mins;
  }
  return out;
}
