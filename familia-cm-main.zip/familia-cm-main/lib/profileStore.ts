import { isSupabaseConfigured, supabase } from "@/lib/supabaseClient";
import { lsGet, lsSet } from "@/lib/localStore";

export type Profile = {
  id: string;
  display_name: string;
  instagram_url: string;
  website_url: string;
  x_url: string;
  linkedin_url: string;
};

const LS_PREFIX = "nido:profile:";

function key(userId: string) {
  return `${LS_PREFIX}${userId}`;
}

function safeNameFromEmail(email?: string | null): string {
  if (!email) return "";
  const left = email.split("@")[0] || "";
  return left.replace(/[^a-z0-9._-]/gi, " ").trim();
}

export function defaultProfile(userId: string, email?: string | null): Profile {
  return {
    id: userId,
    display_name: safeNameFromEmail(email),
    instagram_url: "",
    website_url: "",
    x_url: "",
    linkedin_url: "",
  };
}

export function loadProfileLocal(userId: string, email?: string | null): Profile {
  return lsGet<Profile>(key(userId), defaultProfile(userId, email));
}

export function saveProfileLocal(profile: Profile) {
  lsSet(key(profile.id), profile);
}

/**
 * Load profile from Supabase if available; fallback to localStorage.
 *
 * Expected table:
 *   profiles(id uuid primary key, display_name text, instagram_url text, website_url text, x_url text, linkedin_url text)
 */
export async function loadProfile(userId: string, email?: string | null): Promise<Profile> {
  const local = loadProfileLocal(userId, email);
  if (!isSupabaseConfigured) return local;

  try {
    const { data, error } = await supabase
      .from("profiles")
      .select("id,display_name,instagram_url,website_url,x_url,linkedin_url")
      .eq("id", userId)
      .single();

    if (error || !data) return local;

    const merged: Profile = {
      ...local,
      id: data.id,
      display_name: data.display_name ?? local.display_name,
      instagram_url: data.instagram_url ?? local.instagram_url,
      website_url: data.website_url ?? local.website_url,
      x_url: data.x_url ?? local.x_url,
      linkedin_url: data.linkedin_url ?? local.linkedin_url,
    };

    // Keep a local cache for offline-read.
    saveProfileLocal(merged);
    return merged;
  } catch {
    return local;
  }
}

export async function saveProfile(profile: Profile): Promise<{ ok: boolean; message?: string }> {
  // Always keep local copy for instant UX.
  saveProfileLocal(profile);

  if (!isSupabaseConfigured) return { ok: true, message: "Guardado (local)." };

  try {
    const { error } = await supabase.from("profiles").upsert(
      {
        id: profile.id,
        display_name: profile.display_name,
        instagram_url: profile.instagram_url || null,
        website_url: profile.website_url || null,
        x_url: profile.x_url || null,
        linkedin_url: profile.linkedin_url || null,
      },
      { onConflict: "id" }
    );

    if (error) {
      // Table might not exist yet; still keep local.
      return { ok: false, message: `Guardado local. Supabase: ${error.message}` };
    }

    return { ok: true, message: "Guardado." };
  } catch {
    return { ok: false, message: "Guardado local. Supabase no disponible." };
  }
}
