"use client";

export type MonzonState = {
  lastCheckISO?: string;
  lastOkISO?: string;
  pdfUrl?: string;
  pdfLabel?: string;
  sourceUrl?: string;
};

const KEY = "nido:comedor:monzon3:state";
const UPDATE_EVENT = "nido:comedor:monzon3:update";

function nowISO() {
  return new Date().toISOString();
}

function read(): MonzonState {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return {};
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

function write(next: MonzonState) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    // ignore quota
  }
  window.dispatchEvent(new CustomEvent(UPDATE_EVENT));
}

export function loadComedorMonzonState(): MonzonState {
  return read();
}

export function onComedorMonzonUpdate(handler: () => void) {
  if (typeof window === "undefined") return () => {};
  const fn = () => handler();
  window.addEventListener(UPDATE_EVENT, fn);
  // also react to other tabs
  const onStorage = (e: StorageEvent) => {
    if (e.key === KEY) handler();
  };
  window.addEventListener("storage", onStorage);
  return () => {
    window.removeEventListener(UPDATE_EVENT, fn);
    window.removeEventListener("storage", onStorage);
  };
}

function pickLikelyMonthlyLinks(links: Array<{ url: string; label: string }>) {
  const day = new Date().getDate();
  // Between 28 and 4 (month boundaries), people usually post the new calendar.
  const inWindow = day >= 28 || day <= 4;
  if (!inWindow) return links;

  // Heuristic: keep only links that look like “mes” or “calendario” or “comedor”.
  const preferred = links.filter((l) => {
    const s = `${l.url} ${l.label}`.toLowerCase();
    return s.includes("comedor") || s.includes("menu") || s.includes("menú") || s.includes("calend") || s.includes("mes");
  });
  return preferred.length ? preferred : links;
}

export async function checkComedorMonzon(): Promise<MonzonState> {
  const prev = read();
  const next: MonzonState = { ...prev, lastCheckISO: nowISO() };
  try {
    const r = await fetch("/api/comedor/monzon", { cache: "no-store" });
    const j = await r.json();
    if (!j?.ok) {
      write(next);
      return next;
    }
    const links = Array.isArray(j.links) ? (j.links as any[]) : [];
    const normalized = links
      .filter((x) => x?.url)
      .map((x) => ({ url: String(x.url), label: String(x.label ?? "PDF") }));

    const candidates = pickLikelyMonthlyLinks(normalized);
    const first = candidates[0];
    if (first?.url) {
      next.pdfUrl = first.url;
      next.pdfLabel = first.label;
      next.lastOkISO = nowISO();
      next.sourceUrl = j.sourceUrl ?? prev.sourceUrl;
    }
    write(next);
    return next;
  } catch {
    write(next);
    return next;
  }
}
