import type { ColorKey } from "@/lib/types";

export type CategoryMeta = {
  key: ColorKey;
  label: string;
  icon: string;
  pillClass: string;
  dotClass: string;
};

export const categoryMeta: Record<ColorKey, CategoryMeta> = {
  family: {
    key: "family",
    label: "Familia",
    // Un solo icono por categoría (más limpio en UI)
    icon: "👪",
    pillClass: "bg-blue-50 text-blue-900 border-blue-200",
    dotClass: "bg-blue-400",
  },
  partner: {
    key: "partner",
    label: "Pareja",
    icon: "💗",
    pillClass: "bg-pink-50 text-pink-900 border-pink-200",
    dotClass: "bg-pink-400",
  },
  work: {
    key: "work",
    label: "Trabajo",
    icon: "💻",
    pillClass: "bg-yellow-50 text-yellow-900 border-yellow-200",
    dotClass: "bg-yellow-400",
  },
  health: {
    key: "health",
    label: "Salud",
    // Constantes vitales
    icon: "📈",
    pillClass: "bg-green-50 text-green-900 border-green-200",
    dotClass: "bg-green-500",
  },
  home: {
    key: "home",
    label: "Casa",
    icon: "🏠",
    pillClass: "bg-stone-50 text-stone-900 border-stone-200",
    dotClass: "bg-stone-400",
  },
  carlos: {
    key: "carlos",
    label: "Carlos",
    icon: "👤",
    pillClass: "bg-violet-50 text-violet-900 border-violet-200",
    dotClass: "bg-violet-500",
  },
};

export const legend = (Object.keys(categoryMeta) as ColorKey[])
  .map((k) => categoryMeta[k])
  .sort((a, b) => {
    const order: Record<ColorKey, number> = {
      work: 10,
      family: 20,
      partner: 30,
      health: 40,
      home: 50,
      carlos: 60,
    };
    return (order[a.key] ?? 999) - (order[b.key] ?? 999);
  });

export function pillClassFor(key: ColorKey): string {
  return categoryMeta[key].pillClass;
}

export function dotClassFor(key: ColorKey): string {
  return categoryMeta[key].dotClass;
}
