export type ColorKey =
  | "work" | "family" | "partner" | "health" | "home" | "carlos";

export type ScheduleBlock = {
  id: string;
  color: ColorKey;
  label: string;
  start: string; // "HH:MM"
  end: string;   // "HH:MM"
  notes?: string;
};

export type RoutineType = "morning" | "night";
export type MedKey = "loniten" | "dutasteride";

export type Task = {
  id: string;
  title: string;
  window_start: string; // YYYY-MM-DD
  window_end: string;   // YYYY-MM-DD
  duration_min: number;
  priority: "Alta" | "Media" | "Baja";
  energy: "Baja" | "Media" | "Alta";
  done: boolean;
};

export type DocItem = {
  id: string;
  doc_date: string; // YYYY-MM-DD
  category: "Bancos" | "Médicos" | "Facturas" | "Colegio" | "Seguros" | "Otros";
  entity: string;
  concept: string;
  amount: number | null;
  onedrive_url: string;
  status: "INBOX" | "Archivado" | "Pendiente";
};

export type Settings = {
  id: string; // user_id
  tz: string;
  work_min_hours: number;
  dogs_minutes: number;
  gym_minutes: number;
  meal_minutes: number;
  family_start_evening: string; // "17:30"
  // optional custom times
  dogs_start: string; // "06:00"
  sleep_start: string; // "22:00"
  sleep_end: string; // "05:00"
};

export type ChecklistKey = "work" | "carlos" | "home_family";

export type ChecklistItem = {
  id: string;
  text: string;
  done: boolean;
};

export type CalendarEvent = {
  id: string;
  title: string;
  startISO: string; // ISO string
  endISO: string;   // ISO string
};
