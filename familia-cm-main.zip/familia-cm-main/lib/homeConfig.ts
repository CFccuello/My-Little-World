export type HomeModuleKey =
  | "familia"
  | "comida"
  | "medicacion"
  | "rutinas";

export type HomeModule = {
  key: HomeModuleKey;
  title: string;
  icon: string;
  href: string;
  // Tinta suave (fondo) para diferenciar módulos sin gritar.
  tintClass: string;
};

// Home V1: tarjetas por temas, visual y legible.
// Davinia no edita estructura (decisión cerrada).
export const HOME_MODULES: HomeModule[] = [
  {
    key: "familia",
    title: "Familia",
    icon: "👪",
    href: "/familia",
    tintClass: "bg-sky-50",
  },
  {
    key: "comida",
    title: "Comida",
    icon: "🍽️",
    href: "/comida",
    tintClass: "bg-amber-50",
  },
  {
    key: "medicacion",
    title: "Medicación",
    icon: "💊",
    href: "/medicacion",
    tintClass: "bg-violet-50",
  },
  {
    key: "rutinas",
    title: "Rutinas",
    icon: "✅",
    href: "/today",
    tintClass: "bg-emerald-50",
  },
];

export const HOME_CLAIM = "Tu casa y tu familia, en orden. Sin ruido.";
