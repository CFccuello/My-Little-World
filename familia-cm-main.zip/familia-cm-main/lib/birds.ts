export type BirdId =
  | "chicks"
  | "dodo"
  | "dove"
  | "duck"
  | "eagle"
  | "flamingo"
  | "hummingbird"
  | "owl"
  | "parrot"
  | "penguin"
  | "sparrow"
  | "swan";

export type Bird = {
  id: BirdId;
  /** Friendly name shown in copy */
  name: string;
  /** Emoji (iOS friendly) used as the fallback "illustration" */
  emoji: string;
  /** Optional extra line for onboarding/splash */
  note: string;
  /** Optional local SVG in /public (for the daily splash). */
  image?: string;
};

/**
 * Single source of truth for the “Ave del día”.
 *
 * - Deterministic by date (see birdForDate)
 * - Uses local SVGs (PWA friendly, offline, no external requests)
 */
export const BIRDS: Bird[] = [
  {
    id: "chicks",
    name: "Pollitos",
    emoji: "🪺🐣🐥",
    note: "Hoy el nido va primero.",
    image: "/birds/chicks.svg",
  },
  {
    id: "sparrow",
    name: "Gorriones",
    emoji: "🐦🪺🐦",
    note: "Pequeño, constante. Ya está.",
    image: "/birds/sparrow.svg",
  },
  {
    id: "dove",
    name: "Palomas",
    emoji: "🕊️🪺🕊️",
    note: "Paz. Un paso a la vez.",
    image: "/birds/dove.svg",
  },
  {
    id: "duck",
    name: "Patos",
    emoji: "🦆🪺🦆",
    note: "Sin prisa, sin pausa.",
    image: "/birds/duck.svg",
  },
  {
    id: "penguin",
    name: "Pingüinos",
    emoji: "🐧🪺🐧",
    note: "Equipo nido: juntitos sale.",
    image: "/birds/penguin.svg",
  },
  {
    id: "owl",
    name: "Búhos",
    emoji: "🦉🌙🪺",
    note: "Modo noche: suave.",
    image: "/birds/owl.svg",
  },
  {
    id: "parrot",
    name: "Loros",
    emoji: "🦜🪺🦜",
    note: "Hoy toca lo importante.",
    image: "/birds/parrot.svg",
  },
  {
    id: "hummingbird",
    name: "Colibríes",
    emoji: "🐦✨🪺",
    note: "Piquitos pequeños, avances grandes.",
    image: "/birds/hummingbird.svg",
  },
  {
    id: "flamingo",
    name: "Flamencos",
    emoji: "🦩🪺🦩",
    note: "Un poco de color, pero con calma.",
    image: "/birds/flamingo.svg",
  },
  {
    id: "eagle",
    name: "Águilas",
    emoji: "🦅🪺🦅",
    note: "Vista alta. Tareas pequeñas.",
    image: "/birds/eagle.svg",
  },
  {
    id: "swan",
    name: "Cisnes",
    emoji: "🦢🪺🦢",
    note: "Orden bonito. Sin ruido.",
    image: "/birds/swan.svg",
  },
  {
    id: "dodo",
    name: "Dodos",
    emoji: "🦤🪺🦤",
    note: "Hasta el dodo se organiza. Con cariño.",
    image: "/birds/dodo.svg",
  },
];

function hashStringToInt(input: string): number {
  // Small deterministic hash for “bird of the day”.
  let h = 0;
  for (let i = 0; i < input.length; i++) {
    h = (h * 31 + input.charCodeAt(i)) >>> 0;
  }
  return h;
}

export function birdForDate(dateISO: string): Bird {
  const h = hashStringToInt(dateISO);
  const idx = h % BIRDS.length;
  return BIRDS[idx];
}
