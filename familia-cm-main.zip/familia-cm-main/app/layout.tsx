import "./globals.css";
import "./ios.css";

import type { Metadata, Viewport } from "next";
import Shell from "@/components/Shell";
import UiBoot from "@/components/UiBoot";

export const metadata: Metadata = {
  title: "NIDO",
  description: "Lo importante, hoy.",
  applicationName: "NIDO",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "NIDO",
  },
  formatDetection: {
    telephone: false,
  },
  themeColor: "#0b0f14",
  manifest: "/manifest.webmanifest",
};

export const viewport: Viewport = {
  themeColor: "#0b0f14",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body className="bg-[hsl(var(--background))] text-[hsl(var(--foreground))]">
        <UiBoot />
        <Shell>{children}</Shell>
      </body>
    </html>
  );
}
