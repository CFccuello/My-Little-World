import Protected from "@/components/Protected";
import WeekEventsWidget from "@/components/WeekEventsWidget";

/**
 * Página de la vista semanal. Reemplaza el calendario pesado por una
 * presentación calmada de los eventos importantes de la semana. Se
 * muestra un hero similar al de Inicio y un listado de eventos de
 * la semana usando WeekEventsWidget. El componente WeekEventsWidget
 * muestra los eventos ordenados de la semana y ofrece enlaces para
 * navegar al calendario completo si hace falta.
 */
export default function CalendarPage() {
  return (
    <Protected>
      <div className="space-y-4">
        {/* Hero para la página de semana */}
        <div className="nido-hero">
          <div className="nido-eyebrow">Semana</div>
          <div className="mt-2 text-2xl font-semibold tracking-tight text-[hsl(var(--foreground))]">Lo importante</div>
          <div className="mt-2 text-sm text-[hsl(var(--muted-foreground))]">
            Un vistazo. Sin ruido.
          </div>
        </div>
        {/* Listado de eventos */}
        <WeekEventsWidget />
      </div>
    </Protected>
  );
}