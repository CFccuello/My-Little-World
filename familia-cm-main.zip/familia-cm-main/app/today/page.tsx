import Protected from "@/components/Protected";
import TodayV1Client from "@/components/TodayV1Client";

export default function TodayPage() {
  return (
    <Protected>
      {/* Nueva vista Hoy, versión calmada y simplificada. */}
      <TodayV1Client />
    </Protected>
  );
}
