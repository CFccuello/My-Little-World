import Protected from "@/components/Protected";
import Routines2PageClient from "@/components/Routines2PageClient";

export default function RoutinesPage() {
  return (
    <Protected>
      <div className="space-y-4">
        <div className="nido-hero">
          <div className="nido-eyebrow">Rutinas</div>
          <div className="mt-2 text-2xl font-semibold tracking-tight text-[hsl(var(--foreground))]">
            El nido, en orden
          </div>
          <div className="mt-2 text-sm text-[hsl(var(--muted-foreground))]">
            Check rápido. Sin juicio. Si hoy no sale, mañana se ajusta.
          </div>
        </div>

        <Routines2PageClient />
      </div>
    </Protected>
  );
}
