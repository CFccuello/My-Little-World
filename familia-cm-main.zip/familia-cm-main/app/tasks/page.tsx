import Protected from "@/components/Protected";
import Tasks from "@/components/Tasks";
import PageTitle from "@/components/PageTitle";
import { format } from "date-fns";

export default function TasksPage() {
  const todayISO = format(new Date(), "yyyy-MM-dd");
  return (
    <Protected>
      <PageTitle icon="✅" title="Tareas" subtitle="Ventanas de días, prioridad y energía. Estilo Notion (tabla)." />
      <Tasks todayISO={todayISO} />
    </Protected>
  );
}
