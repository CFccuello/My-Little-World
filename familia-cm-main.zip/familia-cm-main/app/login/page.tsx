import { Suspense } from "react";
import LoginClient from "@/components/LoginClient";

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <div className="mx-auto w-full max-w-md px-4 pt-10">
          <div className="card p-6">
            <div className="text-sm text-[hsl(var(--muted-foreground))]">Cargando…</div>
          </div>
        </div>
      }
    >
      <LoginClient />
    </Suspense>
  );
}
