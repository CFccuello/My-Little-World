"use client";

import Protected from "@/components/Protected";
import PageTitle from "@/components/PageTitle";
import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";
import { useEffect, useMemo, useState } from "react";

type Member = { id: string; name: string; dob: string | null };
type WeightRow = { weight_kg: number; source: string; created_at: string };
type LogRow = { id: string; taken_at: string; medicine: string; concentration_mg_per_ml: number | null; dose_ml: number; reason: string | null; note: string | null };

function yearsOld(dob?: string | null) {
  if (!dob) return null;
  const d = new Date(dob);
  const now = new Date();
  let y = now.getFullYear() - d.getFullYear();
  const m = now.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < d.getDate())) y--;
  return y;
}

/**
 * OJO: aquí usamos una aproximación “normal/delgado, normal/alto” SOLO como propuesta.
 * La app siempre muestra: propuesta + último peso guardado + permite peso manual.
 */
function suggestedWeightKg(ageYears: number) {
  // Propuesta simple para demo operativa (luego la afinamos con tabla oficial exacta que elijas).
  // 2–5: 14–20 | 6–8: 21–27 | 9–12: 28–40
  if (ageYears <= 2) return 12;
  if (ageYears <= 3) return 14;
  if (ageYears <= 4) return 16;
  if (ageYears <= 5) return 18;
  if (ageYears <= 6) return 20;
  if (ageYears <= 7) return 23;
  if (ageYears <= 8) return 26;
  if (ageYears <= 10) return 32;
  return 38;
}

// Concentraciones típicas
const IBU = [
  { label: "Ibuprofeno 20 mg/ml (oral)", mgPerMl: 20 },
  { label: "Ibuprofeno 40 mg/ml (oral)", mgPerMl: 40 },
];

export default function MedicacionPage() {
  const [members, setMembers] = useState<Member[]>([]);
  const [memberId, setMemberId] = useState<string>("");
  const [manualWeight, setManualWeight] = useState<string>("");
  const [lastWeight, setLastWeight] = useState<WeightRow | null>(null);

  const [medicine, setMedicine] = useState<"Paracetamol" | "Ibuprofeno" | "Otro">("Paracetamol");
  const [ibuMgPerMl, setIbuMgPerMl] = useState<number>(20);
  const [doseMl, setDoseMl] = useState<number | null>(null);

  const [reason, setReason] = useState("");
  const [note, setNote] = useState("");
  const [log, setLog] = useState<LogRow[]>([]);

  const member = useMemo(() => members.find(m => m.id === memberId), [members, memberId]);
  const age = useMemo(() => yearsOld(member?.dob), [member?.dob]);
  const suggested = useMemo(() => (age != null ? suggestedWeightKg(age) : null), [age]);
  const effectiveWeight = useMemo(() => {
    const w = parseFloat(manualWeight);
    if (!isNaN(w) && w > 0) return w;
    if (lastWeight?.weight_kg) return lastWeight.weight_kg;
    if (suggested) return suggested;
    return null;
  }, [manualWeight, lastWeight, suggested]);

  async function loadMembers() {
    const { data } = await supabase.from("family_members").select("id,name,dob").order("created_at", { ascending: true });
    setMembers((data ?? []) as any);
    if (!memberId && data && data.length) setMemberId(data[0].id);
  }

  async function loadLastWeight(mid: string) {
    const { data } = await supabase
      .from("member_weights")
      .select("weight_kg,source,created_at")
      .eq("member_id", mid)
      .order("created_at", { ascending: false })
      .limit(1);

    setLastWeight((data?.[0] as any) ?? null);
  }

  async function loadLog(mid: string) {
    const { data } = await supabase
      .from("medication_log")
      .select("id,taken_at,medicine,concentration_mg_per_ml,dose_ml,reason,note")
      .eq("member_id", mid)
      .order("taken_at", { ascending: false })
      .limit(50);

    setLog((data ?? []) as any);
  }

  function calc() {
    if (!effectiveWeight) return;

    if (medicine === "Paracetamol") {
      // regla común: 15 mg/kg por dosis. Concentraciones varían mucho, aquí pedimos ml manual luego si quieres.
      // Para arrancar operativo: mostramos ml suponiendo 24 mg/ml NO (varía). Así que: devolvemos solo recomendación mg.
      // Como tú pediste SIEMPRE ml: lo resolvemos pidiéndote concentración en siguiente iteración.
      // Hoy: dejamos “ml” como campo editable.
      const mg = effectiveWeight * 15;
      // placeholder ml (si fuese 24 mg/ml): mg/24
      setDoseMl(Number((mg / 24).toFixed(2)));
      return;
    }

    if (medicine === "Ibuprofeno") {
      // regla común: 10 mg/kg por dosis
      const mg = effectiveWeight * 10;
      const ml = mg / ibuMgPerMl;
      setDoseMl(Number(ml.toFixed(2)));
      return;
    }

    setDoseMl(null);
  }

  async function saveManualWeight() {
    if (!memberId) return;
    const w = parseFloat(manualWeight);
    if (isNaN(w) || w <= 0) return;

    await supabase.from("member_weights").insert([{
      member_id: memberId,
      weight_kg: w,
      source: "manual",
      note: "Peso introducido manualmente en la app"
    }]);

    await loadLastWeight(memberId);
  }

  async function addLog() {
    if (!memberId) return;
    if (!doseMl || doseMl <= 0) return;

    const user = (await supabase.auth.getUser()).data.user;

    await supabase.from("medication_log").insert([{
      member_id: memberId,
      medicine: medicine === "Otro" ? "Otro" : medicine,
      concentration_mg_per_ml: medicine === "Ibuprofeno" ? ibuMgPerMl : null,
      dose_ml: doseMl,
      reason: reason.trim() || null,
      note: note.trim() || null,
      created_by_email: user?.email ?? null
    }]);

    setReason(""); setNote("");
    await loadLog(memberId);
  }

  useEffect(() => { loadMembers(); }, []);
  useEffect(() => {
    if (!memberId) return;
    loadLastWeight(memberId);
    loadLog(memberId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [memberId]);

  return (
    <Protected>
      <PageTitle icon="💊" title="Medicación" subtitle="Calculadora + histórico por persona + alertas (siguiente commit)." />

      <div className="notion-card space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
          <select className="notion-input" value={memberId} onChange={(e) => setMemberId(e.target.value)}>
            {members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
          </select>

          <div className="notion-card p-3">
            <div className="text-xs text-[hsl(var(--muted-foreground))]">Peso propuesto</div>
            <div className="font-semibold">{suggested ?? "—"} kg</div>
            <div className="text-xs text-[hsl(var(--muted-foreground))]">Según edad (propuesta). Luego afinamos tabla oficial exacta.</div>
          </div>

          <div className="notion-card p-3">
            <div className="text-xs text-[hsl(var(--muted-foreground))]">Último peso guardado</div>
            <div className="font-semibold">{lastWeight?.weight_kg ?? "—"} kg</div>
            <div className="text-xs text-[hsl(var(--muted-foreground))]">
              {lastWeight ? `${lastWeight.source} · ${new Date(lastWeight.created_at).toLocaleDateString()}` : "Sin datos"}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 items-center">
          <input className="notion-input" placeholder="Peso manual (kg)" value={manualWeight} onChange={(e) => setManualWeight(e.target.value)} />
          <button className="notion-btn" onClick={saveManualWeight}>Guardar peso manual</button>
          <div className="text-sm text-[hsl(var(--muted-foreground))]">
            Peso usado ahora: <b>{effectiveWeight ?? "—"} kg</b>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
          <select className="notion-input" value={medicine} onChange={(e) => setMedicine(e.target.value as any)}>
            <option value="Paracetamol">Paracetamol</option>
            <option value="Ibuprofeno">Ibuprofeno</option>
            <option value="Otro">Otro (manual)</option>
          </select>

          {medicine === "Ibuprofeno" ? (
            <select className="notion-input" value={ibuMgPerMl} onChange={(e) => setIbuMgPerMl(Number(e.target.value))}>
              {IBU.map(x => <option key={x.mgPerMl} value={x.mgPerMl}>{x.label}</option>)}
            </select>
          ) : (
            <div className="notion-card p-3 text-sm text-[hsl(var(--muted-foreground))]">Concentración: la cerramos en el próximo commit (paracetamol varía).</div>
          )}

          <button className="notion-btn" onClick={calc}>Calcular dosis (ml)</button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 items-center">
          <input className="notion-input" placeholder="Dosis (ml)" value={doseMl ?? ""} onChange={(e) => setDoseMl(Number(e.target.value))} />
          <input className="notion-input" placeholder="Motivo (tos, garganta…)" value={reason} onChange={(e) => setReason(e.target.value)} />
          <input className="notion-input" placeholder="Nota (opcional)" value={note} onChange={(e) => setNote(e.target.value)} />
        </div>

        <button className="notion-btn" onClick={addLog}>Guardar en histórico</button>
      </div>

      <div className="mt-4 space-y-2">
        <div className="text-sm text-[hsl(var(--muted-foreground))]">Histórico (últimas 50):</div>
        {log.map(r => (
          <div key={r.id} className="notion-card">
            <div className="font-semibold">{r.medicine} · {r.dose_ml} ml</div>
            <div className="text-sm text-[hsl(var(--muted-foreground))]">
              {new Date(r.taken_at).toLocaleString()}
              {r.concentration_mg_per_ml ? ` · ${r.concentration_mg_per_ml} mg/ml` : ""}
              {r.reason ? ` · Motivo: ${r.reason}` : ""}
            </div>
            {r.note ? <div className="text-sm text-[hsl(var(--muted-foreground))] mt-1">{r.note}</div> : null}
          </div>
        ))}
      </div>

      <div className="notion-card mt-4">
        Siguiente commit (lo dejamos cerrado): <b>Alertas</b> (si dices “sí”, pedimos horas), y <b>Excel histórico por persona</b>.
      </div>
    </Protected>
  );
}
