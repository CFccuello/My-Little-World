import Protected from "@/components/Protected";
import Finance from "@/components/Finance";
import PageTitle from "@/components/PageTitle";

export default function FinancePage() {
  return (
    <Protected>
      <PageTitle icon="💶" title="Finanzas" subtitle="CSV del banco → vista previa + totales. El dodo 🦤 hace el orden." />
      <Finance />
    </Protected>
  );
}
