"use client";

import Protected from "@/components/Protected";
import PageTitle from "@/components/PageTitle";
import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";
import { useEffect, useState } from "react";

type Source = { id: string; url: string; title: string | null; note: string | null };

export default function InspiracionPage() {
  const [url, setUrl] = useState("");
  const [note, setNote] = useState("");
  const [items, setItems] = useState<Source[]>([]);

  async function load() {
    const { data } = await supabase.from("inspiration_sources").select("id,url,title,note").order("created_at", { ascending: false });
    setItems((data ?? []) as any);
  }

  async function add() {
    const u = url.trim();
    if (!u) return;
    await supabase.from("inspiration_sources").upsert([{ url: u, note: note.trim() || null }], { onConflict: "url" });
    setUrl(""); setNote("");
    load();
  }

  useEffect(() => { load(); }, []);

  return (
    <Protected>
      <PageTitle icon="✨" title="Inspiración" subtitle="Guarda perfiles/links. Luego los convertimos en cards “bonitas”." />

      <div className="notion-card space-y-3">
        <input className="notion-input" placeholder="Pega URL de Instagram / web" value={url} onChange={(e) => setUrl(e.target.value)} />
        <input className="notion-input" placeholder="Comentario (opcional)" value={note} onChange={(e) => setNote(e.target.value)} />
        <button className="notion-btn" onClick={add}>Añadir</button>
        <div className="text-sm text-slate-600">
          Siguiente paso (cuando quieras): “Compartir → Nido” desde Instagram para que se guarde automático.
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
        {items.map((s) => (
          <a key={s.id} href={s.url} target="_blank" className="notion-card-link">
            <div className="notion-card-title">{s.title ?? "Perfil / enlace"}</div>
            <div className="notion-card-sub break-all">{s.url}</div>
            {s.note ? <div className="text-sm text-slate-600 mt-2">{s.note}</div> : null}
          </a>
        ))}
      </div>
    </Protected>
  );
}
