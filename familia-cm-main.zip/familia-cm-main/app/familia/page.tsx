import Protected from "@/components/Protected";
import Link from "next/link";
import clsx from "clsx";

/**
 * Página de datos de familia. Se adapta al estilo calmado del resto de
 * la app. Muestra un hero con el título y una cuadrícula de tarjetas
 * que enlazan a secciones relevantes (medicación, comida, lavavajillas,
 * inspiración). Cada tarjeta tiene un tinte de color diferente para
 * reforzar la memoria visual.
 */
export default function FamiliaPage() {
  const cards = [
    {
      title: "Comida",
      icon: "🍽️",
      desc: "Menú + asignación + compra.",
      href: "/comida",
      tone: "comida",
    },
    {
      title: "Medicació́n",
      icon: "💊",
      desc: "Calculadora + histórico + alertas.",
      href: "/medicacion",
      tone: "medicacion",
    },
    {
      title: "Lavavajillas",
      icon: "🚫",
      desc: "Lista NO aptos (4–8 cosas).",
      href: "/lavavajillas",
      tone: "rutinas",
    },
    {
      title: "Inspiración",
      icon: "✨",
      desc: "Perfiles/links guardados para Davinia.",
      href: "/inspiracion",
      tone: "familia",
    },
    {
      title: "Electricidad",
      icon: "⚡",
      desc: "Lecturas kWh y notas (V1 local).",
      href: "/electricidad",
      tone: "familia",
    },
  ];
  return (
    <Protected>
      <div className="space-y-4">
        {/* Hero */}
        <div className="nido-hero">
          <div className="nido-eyebrow">Familia</div>
          <div className="mt-2 text-2xl font-semibold tracking-tight text-[hsl(var(--foreground))]">
            Todo a mano, sin buscar
          </div>
          <div className="mt-2 text-sm text-[hsl(var(--muted-foreground))]">
            Accesos rápidos. El resto, sin ruido.
          </div>
        </div>
        {/* Tarjetas */}
        <div className="nido-grid">
          {cards.map((c) => (
            <Link
              key={c.href}
              href={c.href}
              className={clsx("nido-card no-underline", `tone-${c.tone}`, c.title === "Comida" && "is-featured")}
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-2xl leading-none">{c.icon}</div>
                  <div className="mt-2 text-base font-semibold text-[hsl(var(--foreground))]">{c.title}</div>
                  <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">{c.desc}</div>
                </div>
                <div className="text-[hsl(var(--muted-foreground))] opacity-70">›</div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </Protected>
  );
}