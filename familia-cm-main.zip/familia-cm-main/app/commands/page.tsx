import Protected from "@/components/Protected";
import AddV1Client from "@/components/AddV1Client";

/**
 * Página para añadir elementos rápidos (tareas, compras, medicación, notas).
 * Usa el componente AddV1Client que presenta plantillas para cada tipo
 * de entrada y permite guardar rápidamente en localStorage. Por defecto
 * los items se guardan en la lista "later" para ser organizados
 * posteriormente.
 */
export default function CommandsPage() {
  return (
    <Protected>
      <AddV1Client />
    </Protected>
  );
}