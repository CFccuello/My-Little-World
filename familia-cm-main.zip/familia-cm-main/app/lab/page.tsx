import Link from "next/link";
import clsx from "clsx";
import Protected from "@/components/Protected";
import HomeV1Client from "@/components/HomeV1Client";
import type { HomeLayoutId } from "@/lib/uiSettings";

function normalizeLayout(value: unknown): HomeLayoutId {
  if (value === "bento" || value === "glass" || value === "story" || value === "control" || value === "warm") {
    return value;
  }
  return "bento";
}

const OPTIONS: { id: HomeLayoutId; label: string; hint: string }[] = [
  { id: "bento", label: "Bento", hint: "Premium" },
  { id: "glass", label: "Glass", hint: "iOS" },
  { id: "story", label: "Story", hint: "Tarjetas" },
  { id: "control", label: "Control", hint: "Acciones" },
  { id: "warm", label: "Warm", hint: "Emocional" },
];

export default function LabPage({
  searchParams,
}: {
  searchParams?: { layout?: string };
}) {
  const layout = normalizeLayout(searchParams?.layout);

  return (
    <Protected>
      <div className="space-y-4">
        <div className="card p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="font-semibold">Lab de diseño</div>
              <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">
                Cambia de modelo y decide cuál se queda. Para fijarlo de forma permanente:
                <span className="font-semibold"> Ajustes → Personalización → Diseño</span>.
              </div>
            </div>
            <Link href="/settings" className="btn no-underline">
              Ajustes
            </Link>
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            {OPTIONS.map((o) => (
              <Link
                key={o.id}
                href={`/lab?layout=${o.id}`}
                className={clsx(
                  "nido-pill no-underline",
                  layout === o.id && "is-active"
                )}
              >
                <span className="font-semibold">{o.label}</span>
                <span className={clsx("text-xs", layout === o.id ? "text-white/80" : "text-[hsl(var(--muted-foreground))]")}>
                  {o.hint}
                </span>
              </Link>
            ))}
          </div>
        </div>

        <HomeV1Client initialLayout={layout} />
      </div>
    </Protected>
  );
}
