import Protected from "@/components/Protected";
import HomeV1Client from "@/components/HomeV1Client";
import type { HomeLayoutId } from "@/lib/uiSettings";

function normalizeLayout(value: unknown): HomeLayoutId | undefined {
  if (value === "bento" || value === "glass" || value === "story" || value === "control" || value === "warm") {
    return value;
  }
  return undefined;
}

export default function Home({
  searchParams,
}: {
  searchParams?: { layout?: string };
}) {
  const initialLayout = normalizeLayout(searchParams?.layout);
  return (
    <Protected>
      {/* Home V1: hero + hoy + temas + semana + luego */}
      <HomeV1Client initialLayout={initialLayout} />
    </Protected>
  );
}
