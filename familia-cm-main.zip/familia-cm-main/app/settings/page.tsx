import Protected from "@/components/Protected";
import SettingsForm from "@/components/SettingsForm";
import PageTitle from "@/components/PageTitle";

export default function SettingsPage() {
  return (
    <Protected>
      <PageTitle icon="👤" title="Cuenta" subtitle="Mi cuenta y preferencias del nido." />
      <SettingsForm />
    </Protected>
  );
}
