// app/api/integrations/telegram/webhook/route.ts

import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/server/supabaseAdmin";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type TelegramUpdate = {
  update_id: number;
  message?: TelegramMessage;
  channel_post?: TelegramMessage;
};

type TelegramMessage = {
  message_id: number;
  date: number;
  chat: {
    id: number;
    type: string;
    title?: string;
    username?: string;
  };
  from?: {
    id: number;
    is_bot: boolean;
    first_name?: string;
    last_name?: string;
    username?: string;
  };
  author_signature?: string;

  text?: string;
  caption?: string;

  document?: { file_id: string; file_name?: string; mime_type?: string; file_size?: number };
  photo?: Array<{ file_id: string; width?: number; height?: number; file_size?: number }>;
};

function getSecretFromHeader(req: Request): string {
  return req.headers.get("x-telegram-bot-api-secret-token") || "";
}
function getEnvSecret(): string {
  return process.env.TELEGRAM_WEBHOOK_SECRET || "";
}

function allowedChatIdsSet(): Set<string> | null {
  const raw = (process.env.TELEGRAM_ALLOWED_CHAT_IDS || "").trim();
  if (!raw) return null;
  return new Set(raw.split(",").map((s) => s.trim()).filter(Boolean));
}

function senderName(msg: TelegramMessage): string | null {
  if (msg.author_signature) return msg.author_signature;

  if (msg.from) {
    const name = [msg.from.first_name, msg.from.last_name].filter(Boolean).join(" ").trim();
    return name || msg.from.username || null;
  }

  return msg.chat.title || msg.chat.username || null;
}

function extractAttachments(msg: TelegramMessage): any[] {
  const out: any[] = [];

  if (msg.document?.file_id) {
    out.push({
      kind: "document",
      file_id: msg.document.file_id,
      file_name: msg.document.file_name ?? null,
      mime_type: msg.document.mime_type ?? null,
      file_size: msg.document.file_size ?? null,
    });
  }

  if (Array.isArray(msg.photo) && msg.photo.length > 0) {
    const sorted = [...msg.photo].sort((a, b) => (b.file_size ?? 0) - (a.file_size ?? 0));
    const best = sorted[0];
    out.push({
      kind: "photo",
      file_id: best.file_id,
      width: best.width ?? null,
      height: best.height ?? null,
      file_size: best.file_size ?? null,
      variants: sorted.map((p) => ({
        file_id: p.file_id,
        width: p.width ?? null,
        height: p.height ?? null,
        file_size: p.file_size ?? null,
      })),
    });
  }

  return out;
}

export async function GET() {
  return NextResponse.json({ ok: true, method: "GET", hint: "Telegram uses POST here" });
}

export async function POST(req: Request) {
  try {
    const expected = getEnvSecret();
    const provided = getSecretFromHeader(req);

    if (expected && provided !== expected) {
      return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 });
    }

    let update: TelegramUpdate;
    try {
      update = (await req.json()) as TelegramUpdate;
    } catch {
      return NextResponse.json({ ok: false, error: "invalid_json" }, { status: 400 });
    }

    const msg = update.message ?? update.channel_post;
    if (!msg) {
      return NextResponse.json({ ok: true, ignored: true, reason: "no_message" });
    }

    const allowed = allowedChatIdsSet();
    const chatId = msg.chat.id;
    if (allowed && !allowed.has(String(chatId))) {
      return NextResponse.json({ ok: true, ignored: true, reason: "chat_not_allowed" });
    }

    const textRaw = (msg.text || msg.caption || "").trim();

    const payload = {
      // your schema
      source: "telegram",
      source_chat_id: chatId,
      source_chat_title: msg.chat.title || msg.chat.username || null,
      source_message_id: msg.message_id,
      source_message_date: new Date(msg.date * 1000).toISOString(),
      from_name: senderName(msg),
      text_raw: textRaw || null,
      attachments: extractAttachments(msg),

      // NEW: status
      status: "new",
    };

    const { error } = await supabaseAdmin
      .from("school_inbox_items")
      .upsert(payload, { onConflict: "source_chat_id,source_message_id" });

    if (error) {
      return NextResponse.json(
        { ok: false, error: "supabase_insert_failed", detail: error.message },
        { status: 500 },
      );
    }

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: "unhandled_error", detail: e?.message ?? "unknown" },
      { status: 500 },
    );
  }
}
