import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

// Source page with the monthly PDF links.
const MONZON_URL =
  process.env.MONZON_COMEDOR_URL ??
  "https://www.colegioecopiomonzon3.es/comedor";

type PdfLink = { url: string; label: string };

function absUrl(href: string, base: string) {
  try {
    return new URL(href, base).toString();
  } catch {
    return href;
  }
}

function extractPdfLinks(html: string, baseUrl: string): PdfLink[] {
  // Very simple matcher for href="...pdf" or href='...pdf'.
  const re = /href=["']([^"']+?\.pdf)(?:\?[^"']*)?["']/gi;
  const out: PdfLink[] = [];
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const href = m[1];
    const url = absUrl(href, baseUrl);
    out.push({ url, label: href.split("/").pop() || "PDF" });
  }
  // Deduplicate by url.
  const seen = new Set<string>();
  return out.filter((p) => {
    if (seen.has(p.url)) return false;
    seen.add(p.url);
    return true;
  });
}

export async function GET() {
  try {
    const res = await fetch(MONZON_URL, {
      headers: {
        "user-agent": "nido/1.0 (+https://familia-app-5cm.vercel.app)",
      },
      cache: "no-store",
    });
    if (!res.ok) {
      return NextResponse.json(
        { ok: false, status: res.status, error: "No se pudo cargar la página" },
        { status: 200 },
      );
    }
    const html = await res.text();
    const links = extractPdfLinks(html, MONZON_URL);
    return NextResponse.json({ ok: true, links, sourceUrl: MONZON_URL }, { status: 200 });
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e?.message || "error" },
      { status: 200 },
    );
  }
}
