import Protected from "@/components/Protected";
import PageTitle from "@/components/PageTitle";
import SchoolInboxClient from "@/components/SchoolInboxClient";

export default function SchoolPage() {
  return (
    <Protected>
      <PageTitle
        icon="🏫"
        title="Cole"
        subtitle="Inbox común: resumen, ver original, archivar y crear evento/tarea/info."
      />
      <SchoolInboxClient />
    </Protected>
  );
}
