'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabaseClient'

export default function ResetPasswordPage() {
  const router = useRouter()
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const run = async () => {
      setError('')
      setMessage('')

      // Intercambia el "code" del enlace por una sesión (Supabase JS v2)
      const url = new URL(window.location.href)
      const code = url.searchParams.get('code')
      const accessToken = url.searchParams.get('access_token')
      const refreshToken = url.searchParams.get('refresh_token')

      try {
        if (code) {
          const { error } = await supabase.auth.exchangeCodeForSession(code)
          if (error) throw error
        } else if (accessToken && refreshToken) {
          const { error } = await supabase.auth.setSession({
            access_token: accessToken,
            refresh_token: refreshToken
          })
          if (error) throw error
        }
      } catch (e: any) {
        setError(e?.message || 'Enlace no válido o expirado')
        return
      }

      const { data } = await supabase.auth.getSession()
      if (!data.session) {
        setError('Enlace no válido o expirado')
      }
    }

    run()
  }, [])

  const handleReset = async () => {
    setError('')
    setMessage('')

    if (password.length < 6) return setError('La contraseña debe tener al menos 6 caracteres')
    if (password !== confirm) return setError('Las contraseñas no coinciden')

    setLoading(true)
    const { error } = await supabase.auth.updateUser({ password })
    setLoading(false)

    if (error) {
      setError(error.message)
      return
    }

    setMessage('Contraseña actualizada. Ya puedes entrar.')
    setTimeout(() => router.push('/login'), 600)
  }

  return (
    <div className="max-w-md mx-auto mt-20 p-8 border rounded-xl bg-white shadow">
      <h1 className="text-2xl font-semibold mb-2">Crear nueva contraseña</h1>
      <p className="text-sm text-gray-600 mb-6">
        Si el enlace ha caducado, pide otro desde el login.
      </p>

      <div className="space-y-3">
        <div>
          <label className="block text-sm font-medium mb-1">Nueva contraseña</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full border rounded-lg px-3 py-2"
            autoComplete="new-password"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Repetir contraseña</label>
          <input
            type="password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            className="w-full border rounded-lg px-3 py-2"
            autoComplete="new-password"
          />
        </div>

        {error && <p className="text-sm text-red-600">{error}</p>}
        {message && <p className="text-sm text-green-700">{message}</p>}

        <button
          onClick={handleReset}
          disabled={loading}
          className="w-full bg-black text-white rounded-lg py-2 font-medium disabled:opacity-60"
        >
          {loading ? 'Guardando…' : 'Guardar contraseña'}
        </button>
      </div>
    </div>
  )
}
