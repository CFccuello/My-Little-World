"use client";

import clsx from "clsx";
import { format } from "date-fns";
import { useEffect, useMemo, useState } from "react";

import Protected from "@/components/Protected";
import PageTitle from "@/components/PageTitle";
import { onNidoRefresh } from "@/lib/refreshBus";
import { useNidoUser } from "@/lib/useNidoUser";

type ElectricEntry = {
  dateISO: string;
  kwh: number;
  note?: string;
};

const LS_KEY = "nido:electricidad:entries";

function loadEntries(): ElectricEntry[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(LS_KEY);
    if (!raw) return [];
    const v = JSON.parse(raw);
    if (!Array.isArray(v)) return [];
    return v
      .filter((x) => x && typeof x.dateISO === "string" && typeof x.kwh === "number")
      .map((x) => ({ dateISO: x.dateISO, kwh: x.kwh, note: typeof x.note === "string" ? x.note : undefined }));
  } catch {
    return [];
  }
}

function saveEntries(entries: ElectricEntry[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(LS_KEY, JSON.stringify(entries));
  } catch {
    // ignore quota
  }
}

function todayISO() {
  return format(new Date(), "yyyy-MM-dd");
}

export default function ElectricidadPage() {
  const user = useNidoUser();

  const [entries, setEntries] = useState<ElectricEntry[]>([]);
  const [dateISO, setDateISO] = useState(todayISO);
  const [kwh, setKwh] = useState("");
  const [note, setNote] = useState("");
  const [message, setMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  const sortedEntries = useMemo(() => {
    return [...entries].sort((a, b) => (a.dateISO < b.dateISO ? 1 : -1));
  }, [entries]);

  const totalKwh = useMemo(() => {
    return entries.reduce((acc, e) => acc + e.kwh, 0);
  }, [entries]);

  useEffect(() => {
    setEntries(loadEntries());
  }, []);

  useEffect(() => {
    // Pull-to-refresh support
    const off = onNidoRefresh(() => {
      setEntries(loadEntries());
    });
    return () => off();
  }, []);

  function addEntry() {
    setError("");
    setMessage("");

    const parsed = Number(String(kwh).replace(",", "."));
    if (!dateISO) {
      setError("Elige una fecha");
      return;
    }
    if (!Number.isFinite(parsed) || parsed <= 0) {
      setError("kWh debe ser un número mayor que 0");
      return;
    }

    const next: ElectricEntry = {
      dateISO,
      kwh: parsed,
      note: note.trim() ? note.trim() : undefined,
    };

    // Replace if same date exists
    const filtered = entries.filter((e) => e.dateISO !== dateISO);
    const updated = [next, ...filtered];
    setEntries(updated);
    saveEntries(updated);

    setKwh("");
    setNote("");
    setMessage("Guardado. El nido apunta la lectura.");
  }

  function remove(date: string) {
    const updated = entries.filter((e) => e.dateISO !== date);
    setEntries(updated);
    saveEntries(updated);
  }

  return (
    <Protected>
      <PageTitle
        icon="⚡"
        title="Electricidad"
        subtitle="Lecturas manuales en kWh. Simple, local y sin líos."
      />

      <div className="mt-4 nido-callout">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="font-semibold text-[hsl(var(--foreground))]">Modo V1</div>
            <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">
              Guardado en este dispositivo (localStorage). Más adelante lo sincronizamos.
            </div>
          </div>
          <div className="nido-badge">{user.isAdmin ? "Admin" : "User"}</div>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="card p-4 md:col-span-1">
          <div className="font-semibold text-[hsl(var(--foreground))]">Añadir lectura</div>
          <div className="mt-3 space-y-3">
            <div>
              <label className="label">Fecha</label>
              <input
                type="date"
                className="input mt-1"
                value={dateISO}
                onChange={(e) => setDateISO(e.target.value)}
              />
            </div>
            <div>
              <label className="label">kWh</label>
              <input
                type="number"
                inputMode="decimal"
                placeholder="Ej: 1234.5"
                className="input mt-1"
                value={kwh}
                onChange={(e) => setKwh(e.target.value)}
              />
            </div>
            <div>
              <label className="label">Nota (opcional)</label>
              <input
                type="text"
                placeholder="Ej: foto del contador"
                className="input mt-1"
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />
            </div>

            {error ? <div className="text-sm text-amber-700">{error}</div> : null}
            {message ? <div className="text-sm text-emerald-700">{message}</div> : null}

            <button className="btn-primary w-full" onClick={addEntry}>
              Guardar
            </button>
          </div>
        </div>

        <div className="card p-4 md:col-span-2">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="font-semibold text-[hsl(var(--foreground))]">Histórico</div>
              <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">
                {entries.length} lecturas · Total guardado: {totalKwh.toFixed(1)} kWh
              </div>
            </div>
            <button
              className="btn"
              onClick={() => {
                setEntries(loadEntries());
                setMessage("Recargado.");
              }}
            >
              Recargar
            </button>
          </div>

          <div className="mt-3 space-y-2">
            {sortedEntries.length === 0 ? (
              <div className="text-sm text-[hsl(var(--muted-foreground))]">
                Aún no hay lecturas. Cuando apuntes la primera, el dodo 🦤 hará como que entiende de energía.
              </div>
            ) : (
              sortedEntries.map((e) => (
                <div key={e.dateISO} className="card p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-xs text-[hsl(var(--muted-foreground))]">{e.dateISO}</div>
                      <div className="text-base font-semibold text-[hsl(var(--foreground))]">
                        {e.kwh} kWh
                      </div>
                      {e.note ? (
                        <div className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">{e.note}</div>
                      ) : null}
                    </div>
                    <button
                      className={clsx("btn", "text-sm")}
                      onClick={() => {
                        const ok = window.confirm(`¿Borrar lectura del ${e.dateISO}?`);
                        if (ok) remove(e.dateISO);
                      }}
                      title="Borrar"
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </Protected>
  );
}
