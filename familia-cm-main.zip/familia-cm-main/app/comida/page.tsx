"use client";

import clsx from "clsx";
import { addDays, format } from "date-fns";
import { useEffect, useMemo, useState } from "react";

import Protected from "@/components/Protected";
import PageTitle from "@/components/PageTitle";
import ComedorMonzonCard from "@/components/ComedorMonzonCard";

import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";

type MealRow = {
  meal_date: string;
  slot: string;
  member_scope: string;
  title: string;
  note: string | null;
  created_by_email: string | null;
};

const SLOTS = ["desayuno", "almuerzo", "comida", "merienda", "cena"] as const;
const SCOPES = ["family", "greta", "maximo", "roma"] as const;

type Scope = (typeof SCOPES)[number];
type Slot = (typeof SLOTS)[number];

function isoToday() {
  const d = new Date();
  return d.toISOString().slice(0, 10);
}

type Template = {
  id: string;
  label: string;
  title: string;
  note?: string;
  emoji?: string;
};

const TEMPLATES: Template[] = [
  { id: "cole-bocata", label: "Cole: bocata", emoji: "🥪", title: "Bocata + fruta", note: "Agua" },
  { id: "cole-yogur", label: "Cole: yogur", emoji: "🥣", title: "Yogur + fruta", note: "" },
  { id: "cena-ligera", label: "Cena ligera", emoji: "🌙", title: "Crema + tortilla", note: "" },
  { id: "plan-B", label: "Plan B", emoji: "🦤", title: "Pasta + algo de verdura", note: "Sin drama" },
];

export default function ComidaPage() {
  const [date, setDate] = useState<string>(isoToday());
  const [rows, setRows] = useState<MealRow[]>([]);

  const [scope, setScope] = useState<Scope>("family");
  const [slot, setSlot] = useState<Slot>("comida");
  const [title, setTitle] = useState<string>("");
  const [note, setNote] = useState<string>("");

  const [status, setStatus] = useState<"idle" | "loading" | "saving" | "copying" | "demo">("idle");
  const [error, setError] = useState<string>("");
  const [copied, setCopied] = useState<string>("");

  const map = useMemo(() => {
    const m = new Map<string, MealRow>();
    rows.forEach((r) => m.set(`${r.meal_date}|${r.slot}|${r.member_scope}`, r));
    return m;
  }, [rows]);

  const canWrite = isSupabaseConfigured;

  const statusClass = useMemo(() => {
    if (status === "demo") return "nido-callout nido-callout-amber";
    if (status === "loading") return "nido-callout";
    if (status === "saving" || status === "copying") return "nido-callout";
    return "";
  }, [status]);

  async function load() {
    setError("");
    setStatus(isSupabaseConfigured ? "loading" : "demo");
    if (!isSupabaseConfigured) return;

    const { data, error } = await supabase
      .from("meals")
      .select("meal_date,slot,member_scope,title,note,created_by_email")
      .gte("meal_date", date)
      .lte("meal_date", date)
      .order("created_at", { ascending: false });

    if (error) {
      setError(error.message);
      setStatus("idle");
      return;
    }

    setRows((data ?? []) as any);
    setStatus("idle");
  }

  async function upsert() {
    setError("");
    setCopied("");
    if (!canWrite) return;
    if (!title.trim()) return;

    setStatus("saving");
    const user = (await supabase.auth.getUser()).data.user;
    const { error } = await supabase
      .from("meals")
      .upsert(
        [
          {
            meal_date: date,
            slot,
            member_scope: scope,
            title: title.trim(),
            note: note.trim() || null,
            created_by_email: user?.email ?? null,
          },
        ],
        { onConflict: "meal_date,slot,member_scope" },
      );

    setStatus("idle");

    if (error) {
      setError(error.message);
      return;
    }

    setTitle("");
    setNote("");
    await load();
  }

  async function copyDayToDay(fromISO: string, toISO: string) {
    setError("");
    setCopied("");
    if (!canWrite) return;

    setStatus("copying");

    // 1) Read source
    const { data: srcRows, error: readErr } = await supabase
      .from("meals")
      .select("meal_date,slot,member_scope,title,note,created_by_email")
      .eq("meal_date", fromISO);

    if (readErr) {
      setStatus("idle");
      setError(readErr.message);
      return;
    }

    const src = (srcRows ?? []) as MealRow[];
    if (!src.length) {
      setStatus("idle");
      setCopied("No había nada que copiar. El dodo 🦤 se queda quieto.");
      return;
    }

    // 2) Check destination has data
    const { data: dstRows, error: dstErr } = await supabase
      .from("meals")
      .select("meal_date,slot,member_scope")
      .eq("meal_date", toISO);

    if (dstErr) {
      setStatus("idle");
      setError(dstErr.message);
      return;
    }

    const hasDst = (dstRows ?? []).length > 0;
    if (hasDst) {
      const ok = window.confirm(
        `El día destino (${toISO}) ya tiene cosas. ¿Sobrescribimos?`,
      );
      if (!ok) {
        setStatus("idle");
        setCopied("Cancelado. El nido sigue igual.");
        return;
      }
    }

    // 3) Upsert into destination
    const user = (await supabase.auth.getUser()).data.user;
    const payload = src.map((r) => ({
      meal_date: toISO,
      slot: r.slot,
      member_scope: r.member_scope,
      title: r.title,
      note: r.note,
      created_by_email: user?.email ?? r.created_by_email ?? null,
    }));

    const { error: upErr } = await supabase
      .from("meals")
      .upsert(payload, { onConflict: "meal_date,slot,member_scope" });

    setStatus("idle");
    if (upErr) {
      setError(upErr.message);
      return;
    }

    setCopied(`Copiado: ${fromISO} → ${toISO}.`);
    await load();
  }

  function applyTemplate(t: Template) {
    setTitle(t.title);
    setNote(t.note ?? "");
  }

  useEffect(() => {
    void load();

    if (!isSupabaseConfigured) return;

    // “sync” simple: escucha cambios en meals y recarga
    const channel = supabase
      .channel("meals-changes")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "meals" },
        () => void load(),
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date]);

  const tomorrow = useMemo(() => format(addDays(new Date(date), 1), "yyyy-MM-dd"), [date]);

  return (
    <Protected>
      <PageTitle
        icon="🍽️"
        title="Comida"
        subtitle="Slots fijos por día. Plantillas rápidas y copiar día→día para batch cooking."
      />

      <div className="mt-4">
        <ComedorMonzonCard />
      </div>

      <div className={clsx("notion-card space-y-3 mt-4", statusClass)}>
        <div className="flex flex-wrap gap-2 items-center">
          <label className="text-sm text-[hsl(var(--muted-foreground))]">Día</label>
          <input
            className="notion-input"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />

          <button
            className={clsx("btn", (status === "copying" || !canWrite) && "opacity-60 cursor-not-allowed")}
            disabled={status === "copying" || !canWrite}
            onClick={() => void copyDayToDay(date, tomorrow)}
            title="Batch cooking / planes"
          >
            Copiar hoy → mañana
          </button>
        </div>

        {/* Plantillas */}
        <div className="flex flex-wrap gap-2">
          {TEMPLATES.map((t) => (
            <button
              key={t.id}
              type="button"
              className="nido-pill"
              onClick={() => applyTemplate(t)}
              title="Rellena título y nota"
            >
              <span aria-hidden="true">{t.emoji ?? "🐥"}</span>
              <span>{t.label}</span>
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
          <select className="notion-input" value={scope} onChange={(e) => setScope(e.target.value as Scope)}>
            <option value="family">Familia</option>
            <option value="greta">Greta</option>
            <option value="maximo">Máximo</option>
            <option value="roma">Roma</option>
          </select>

          <select className="notion-input" value={slot} onChange={(e) => setSlot(e.target.value as Slot)}>
            {SLOTS.map((s) => (
              <option key={s} value={s}>
                {s.toUpperCase()}
              </option>
            ))}
          </select>

          <input
            className="notion-input"
            placeholder="Menú / plato (del menú mensual o libre)"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>

        <input
          className="notion-input"
          placeholder="Notas (opcional). Ej: 'hidratos + proteína'"
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />

        {error ? <div className="text-sm text-amber-700">{error}</div> : null}
        {copied ? <div className="text-sm text-emerald-700">{copied}</div> : null}

        <button
          className={clsx("notion-btn", (!canWrite || status === "saving") && "opacity-60 cursor-not-allowed")}
          onClick={() => void upsert()}
          disabled={!canWrite || status === "saving"}
        >
          {status === "saving" ? "Guardando…" : "Asignar"}
        </button>

        {!isSupabaseConfigured ? (
          <div className="text-sm text-[hsl(var(--muted-foreground))]">
            Supabase no está configurado: esta pantalla está en modo demo.
          </div>
        ) : null}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
        {SCOPES.map((sc) => (
          <div key={sc} className="notion-card">
            <div className="font-semibold mb-2">
              {sc === "family" ? "Familia" : sc.charAt(0).toUpperCase() + sc.slice(1)}
            </div>

            <div className="space-y-2">
              {SLOTS.map((sl) => {
                const r = map.get(`${date}|${sl}|${sc}`);
                return (
                  <div key={sl} className="card p-3">
                    <div className="text-xs text-[hsl(var(--muted-foreground))]">{sl.toUpperCase()}</div>
                    <div className="font-medium">{r?.title ?? "—"}</div>
                    {r?.created_by_email ? (
                      <div className="text-xs text-[hsl(var(--muted-foreground))] mt-1">
                        Asignado por {r.created_by_email}
                        {r.note ? ` · ${r.note}` : ""}
                      </div>
                    ) : null}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </Protected>
  );
}
