"use client";

import Protected from "@/components/Protected";
import PageTitle from "@/components/PageTitle";
import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";

import { useEffect, useState } from "react";

type Item = { id: string; name: string; note: string | null };

export default function LavavajillasPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [name, setName] = useState("");
  const [note, setNote] = useState("");

  async function load() {
    const { data } = await supabase.from("dishwasher_no").select("id,name,note").order("created_at", { ascending: false });
    setItems((data ?? []) as any);
  }

  async function add() {
    if (!name.trim()) return;
    await supabase.from("dishwasher_no").insert([{ name: name.trim(), note: note.trim() || null }]);
    setName(""); setNote("");
    load();
  }

  useEffect(() => { load(); }, []);

  return (
    <Protected>
      <PageTitle icon="🚫" title="No aptos lavavajillas" subtitle="Añade 4–8 objetos y te olvidas de liarla." />

      <div className="notion-card space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
          <input className="notion-input" placeholder="Objeto (ej: sartén antiadherente)" value={name} onChange={(e) => setName(e.target.value)} />
          <input className="notion-input md:col-span-2" placeholder="Nota (opcional)" value={note} onChange={(e) => setNote(e.target.value)} />
        </div>
        <button className="notion-btn" onClick={add}>Añadir</button>
      </div>

      <div className="space-y-2 mt-4">
        {items.map((it) => (
          <div key={it.id} className="notion-card">
            <div className="font-semibold">{it.name}</div>
            {it.note ? <div className="text-sm text-slate-600">{it.note}</div> : null}
          </div>
        ))}
      </div>
    </Protected>
  );
}
