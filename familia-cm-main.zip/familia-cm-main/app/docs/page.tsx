import Protected from "@/components/Protected";
import PageTitle from "@/components/PageTitle";
import Docs from "@/components/Docs";

export default function DocsPage() {
  return (
    <Protected>
      <PageTitle icon="📎" title="Docs" subtitle="Pega enlaces y el nido los recuerda. Sin buscar, sin ruido." />
      <Docs />
    </Protected>
  );
}
